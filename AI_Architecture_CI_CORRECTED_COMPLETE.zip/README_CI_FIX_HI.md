# AI Architecture — Corrected GitHub CI Bundle

यह ZIP पूरा Android source project और CI workflow एक साथ रखता है। ZIP को extract करके इसकी पूरी सामग्री GitHub repository के root में commit करें। `AI_Architecture/` folder को root पर ही रहने दें।

## इस CI में
- JDK 17 और Gradle 8.11.1
- Android SDK API 35/36 और Build Tools 36.0.0
- Debug APK तथा Android Test APK build
- JVM unit tests और Android Lint
- API 35 Google APIs emulator पर `connectedDebugAndroidTest`
- Emulator ADB/boot/test failure पर diagnostics और logcat artifact
- XML reports और instrumentation execution marker की जाँच

## महत्वपूर्ण
यह CI configuration और source bundle है। वास्तविक GitHub Actions run के बिना Emulator/Instrumentation tests को PASS नहीं कहा जा सकता। इस bundle में ऐप का Kotlin source बदलने के बजाय CI workflow और test execution/reporting को सुधारा गया है।
