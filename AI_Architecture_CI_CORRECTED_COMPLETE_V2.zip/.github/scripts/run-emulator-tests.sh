#!/usr/bin/env bash
set -Eeuo pipefail

: "${PROJECT_ROOT:?PROJECT_ROOT is not set}"
: "${STATUS_DIR:?STATUS_DIR is not set}"
: "${ANDROID_HOME:?ANDROID_HOME is not set}"

mkdir -p "$STATUS_DIR"
ADB="$ANDROID_HOME/platform-tools/adb"
[[ -x "$ADB" ]] || ADB="$(command -v adb || true)"
[[ -n "$ADB" && -x "$ADB" ]] || { echo '::error::adb executable not found'; exit 1; }

mark() { printf '%s\n' "$2" > "$STATUS_DIR/emulator-part-$1.txt"; }
SERIAL="${ANDROID_SERIAL:-}"

collect_diagnostics() {
  local rc=$?
  trap - EXIT
  set +e
  printf 'SCRIPT_EXIT_CODE=%s\nANDROID_SERIAL=%s\n' "$rc" "${SERIAL:-not-detected}" > "$STATUS_DIR/emulator-exit.txt"
  "$ADB" devices -l > "$STATUS_DIR/adb-devices.txt" 2>&1
  if [[ -n "$SERIAL" ]]; then
    "$ADB" -s "$SERIAL" logcat -d -b all -v threadtime > "$STATUS_DIR/emulator-logcat.txt" 2>&1
    "$ADB" -s "$SERIAL" shell dumpsys activity processes > "$STATUS_DIR/activity-processes.txt" 2>&1
    "$ADB" -s "$SERIAL" shell getprop > "$STATUS_DIR/device-getprop.txt" 2>&1
  else
    "$ADB" logcat -d -b all -v threadtime > "$STATUS_DIR/emulator-logcat.txt" 2>&1
  fi
  grep -E -i 'FATAL EXCEPTION|AndroidRuntime|Process .* has died|am_crash|Instrumentation.*(crash|failed)|ANR in ' "$STATUS_DIR/emulator-logcat.txt" > "$STATUS_DIR/crash-summary.txt" 2>&1 || true
  mark 6 DIAGNOSTICS_COLLECTED
  exit "$rc"
}
trap collect_diagnostics EXIT

mark 1 STARTED
for attempt in $(seq 1 120); do
  if [[ -z "$SERIAL" ]]; then
    SERIAL="$("$ADB" devices | awk 'NR > 1 && $1 ~ /^emulator-/ {print $1; exit}')"
  fi
  if [[ -n "$SERIAL" ]]; then
    state="$("$ADB" devices | awk -v serial="$SERIAL" '$1 == serial {print $2; exit}')"
    if [[ "$state" == device ]]; then break; fi
    if [[ "$state" == offline ]]; then "$ADB" reconnect offline >/dev/null 2>&1 || true; fi
  fi
  sleep 5
done
[[ -n "$SERIAL" ]] || { mark 1 FAIL; echo '::error::No emulator serial detected'; exit 1; }
state="$("$ADB" devices | awk -v serial="$SERIAL" '$1 == serial {print $2; exit}')"
[[ "$state" == device ]] || { mark 1 FAIL; echo "::error::Emulator ADB state is $state"; exit 1; }
mark 1 PASS

mark 2 STARTED
booted=0
for attempt in $(seq 1 120); do
  value="$("$ADB" -s "$SERIAL" shell getprop sys.boot_completed 2>/dev/null | tr -d '\r' || true)"
  if [[ "$value" == 1 ]]; then booted=1; break; fi
  sleep 5
done
[[ "$booted" == 1 ]] || { mark 2 FAIL; echo '::error::Emulator boot did not complete'; exit 1; }
api="$("$ADB" -s "$SERIAL" shell getprop ro.build.version.sdk | tr -d '\r')"
[[ "$api" == 35 ]] || { mark 2 FAIL; echo "::error::Expected API 35, got $api"; exit 1; }
mark 2 PASS

mark 3 STARTED
"$ADB" -s "$SERIAL" shell settings put global window_animation_scale 0 || true
"$ADB" -s "$SERIAL" shell settings put global transition_animation_scale 0 || true
"$ADB" -s "$SERIAL" shell settings put global animator_duration_scale 0 || true
cd "$PROJECT_ROOT"
if gradle --no-daemon --stacktrace :app:connectedDebugAndroidTest; then
  mark 3 PASS
  mark 4 PASS
  echo 'CONNECTED_DEBUG_ANDROID_TEST=PASS'
else
  rc=$?
  mark 3 FAIL
  echo "::error::connectedDebugAndroidTest failed with exit code $rc"
  exit "$rc"
fi
