# AI Architecture — Native Android Kotlin Project

**Package:** `com.aiarchitecture.app`  
**Platform:** Native Android  
**Language/UI:** Kotlin + Jetpack Compose + Material 3  
**Local data:** Room / SQLite  
**Canonical geometry:** millimetres  
**Current phase:** Phase 1 source foundation; not a release build.

## Important status

The old developed project source was not recovered. This is a newly authored project, kept separate from the recovery documents. The project has an actual Kotlin/Gradle source tree (36 main Kotlin files), 16 unit-test source files and 5 Android instrumentation-test source files; it includes Room entities/DAOs, canonical parametric model, CPU mesh generation, an OpenGL ES live 3D renderer, a 2D plan canvas, model history, local autosave, JSON checksum backup/restore and vector PDF schedule source. These source areas have not yet passed Android Gradle compilation or phone runtime acceptance. Do not call the APK Build Verified until GitHub Actions passes.

## Build from GitHub on Android phone (ZIP-only upload)

1. Upload `AI_Architecture_Phase1_Source_NOT_FINAL.zip` to the root of a new GitHub repository.
2. In GitHub, choose **Add file → Create new file** and name it `.github/workflows/android-ci.yml`.
3. Copy the complete contents of `MOBILE_GITHUB_BOOTSTRAP_WORKFLOW.yml` (also documented in `docs/MOBILE_GITHUB_UPLOAD_HI.md`) into that workflow file and commit it.
4. Open **Actions** and run **AI Architecture Android CI (ZIP upload)**. The workflow extracts the uploaded ZIP in the cloud, installs Gradle 8.9 and Android SDK API 35/build-tools 35.0.0, runs unit tests/lint, assembles the debug APK and attempts emulator instrumentation tests.
5. Download the `ai-architecture-debug-apk-and-reports` artifact after the run. Install the APK on the phone and perform the acceptance checklist.

The project ZIP itself also contains `.github/workflows/android-ci.yml` for the normal extracted-project upload route. If the ZIP is uploaded as a single file, GitHub does not activate workflows nested inside it; use the separate bootstrap workflow described above. No local PC or preinstalled Gradle wrapper JAR is required for GitHub Actions.

## Source layout

- `app/src/main/java/com/aiarchitecture/app/core/units` — mm canonical unit conversions and dimension provenance.
- `core/geometry` — stable-ID building/floor/element model and parametric mesh generation.
- `core/history` — undo/redo snapshots.
- `data/local` — Room/SQLite entities, DAOs and database.
- `data/repository` — project and geometry persistence.
- `feature/editor` — 2D plan canvas, property editing, element placement, autosave, backup/restore and PDF export actions.
- `feature/renderer` — actual OpenGL ES triangle scene renderer, regenerated from the editable model.
- `feature/backup` — bounded JSON backup and SHA-256 validation.
- `feature/export` — vector dimension schedule PDF.
- `docs/TRACEABILITY_MATRIX.md` — 21-screen/22-section mapping.

## Honest limitations at Phase 1

Advanced selection/transform handles, complete 2D drafting, alignment and measurement UX, 3D object picking, live 3D dimension labels, full component property forms, specialist designer workflows, full localization, real AI provider/model execution, scaled plan sheets in PDF, backup conflict policies, Room migration suite, and phone acceptance remain pending. The current renderer is a real OpenGL ES mesh renderer, but it is an early foundation and is not yet a complete SketchUp-class CAD engine.
