package com.aiarchitecture.app

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.aiarchitecture.app.feature.shell.AppStrings
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AppPreferencesPersistenceTest {
    @Test fun languageAndColdStartDestinationPersistAcrossPreferenceReads() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        context.getSharedPreferences("ai_architecture_preferences", 0).edit().clear().commit()
        assertFalse(AppStrings.hasSavedLanguage(context))
        assertEquals("splash", AppStrings.coldStartDestination(context))
        AppStrings.setLanguage(context, "en")
        assertEquals("en", AppStrings.language(context))
        assertTrue(AppStrings.hasSavedLanguage(context))
        assertEquals("home", AppStrings.coldStartDestination(context))
        AppStrings.setLanguage(context, "hi")
        assertEquals("hi", AppStrings.language(context))
        assertEquals("home", AppStrings.coldStartDestination(context))
    }

    @Test fun darkAndLightThemePreferencesPersist() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        context.getSharedPreferences("ai_architecture_preferences", 0).edit().clear().commit()
        assertFalse(AppStrings.isDark(context))
        AppStrings.setDark(context, true)
        assertTrue(AppStrings.isDark(context))
        AppStrings.setDark(context, false)
        assertFalse(AppStrings.isDark(context))
    }
}
