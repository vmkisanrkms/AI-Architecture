package com.aiarchitecture.app

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.aiarchitecture.app.data.local.AppDatabase
import com.aiarchitecture.app.data.repository.BuildingModelStore
import com.aiarchitecture.app.data.repository.ModelJson
import org.json.JSONObject
import java.security.MessageDigest
import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm
import com.aiarchitecture.app.feature.backup.BackupRestoreManager
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class BackupRestoreIntegrationTest {
    private fun sampleModel(): BuildingModel {
        val floor = BuildingFloor(name = "Ground", elevationMm = 0.0)
        val wall = BuildingElement(
            floorId = floor.id, type = ElementType.WALL, origin = Vec3(100.0, 0.0, 200.0),
            size = Size3(DimensionMm(4200.0), DimensionMm(150.0), DimensionMm(2800.0)),
            openings = listOf(Opening(type = ElementType.DOOR, offsetMm = 500.0, widthMm = 900.0, heightMm = 2100.0))
        )
        return BuildingModel(name = "Backup Test House", floors = listOf(floor.copy(elements = listOf(wall))))
    }

    @Test fun jsonBackupRoundTripsModelAndImageAttachmentsByteForByte() {
        val model = sampleModel()
        val imageA = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0x11, 0x22, 0xFF.toByte(), 0xD9.toByte())
        val imageB = "small-image-payload".toByteArray()
        val bytes = BackupRestoreManager.createBackup(model, mapOf("front.jpg" to imageA, "site.png" to imageB))
        val restored = BackupRestoreManager.restoreBundle(bytes)
        assertEquals(model, restored.model)
        assertArrayEquals(imageA, restored.images["front.jpg"])
        assertArrayEquals(imageB, restored.images["site.png"])
        assertEquals(2, restored.images.size)
    }

    @Test fun corruptedModelPayloadIsRejected() {
        val bytes = BackupRestoreManager.createBackup(sampleModel(), mapOf("photo.jpg" to byteArrayOf(1, 2, 3)))
        val raw = bytes.toString(Charsets.UTF_8)
        val index = raw.indexOf("Backup Test House")
        assertTrue(index >= 0)
        val corrupted = raw.toByteArray(Charsets.UTF_8).also { it[index] = 'X'.code.toByte() }
        try { BackupRestoreManager.restoreBundle(corrupted); fail("Corrupt payload must be rejected") }
        catch (_: IllegalArgumentException) { }
    }

    @Test fun corruptedImageAttachmentIsRejectedByChecksum() {
        val bytes = BackupRestoreManager.createBackup(sampleModel(), mapOf("photo.jpg" to byteArrayOf(10, 20, 30, 40)))
        val raw = bytes.toString(Charsets.UTF_8)
        val index = raw.indexOf("ChQeKA==")
        assertTrue("Expected base64 image payload", index >= 0)
        val corrupted = raw.toByteArray(Charsets.UTF_8).also { it[index] = 'A'.code.toByte() }
        try { BackupRestoreManager.restoreBundle(corrupted); fail("Corrupt image must be rejected") }
        catch (_: IllegalArgumentException) { }
    }

    @Test fun restoreKeepsCompatibilityWithPreviousV1JsonBackups() {
        val model = sampleModel()
        val payload = ModelJson.encode(model)
        val digest = MessageDigest.getInstance("SHA-256").digest(payload.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        val legacy = JSONObject()
            .put("format", "ai-architecture-backup-v1")
            .put("sha256", digest)
            .put("payload", payload)
            .toString().toByteArray(Charsets.UTF_8)
        assertEquals(model, BackupRestoreManager.restore(legacy))
    }

    @Test fun restoredModelCanBeSavedBackIntoLocalRoomDatabase() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        try {
            val model = sampleModel()
            val restored = BackupRestoreManager.restoreBundle(BackupRestoreManager.createBackup(model))
            kotlinx.coroutines.runBlocking {
                val store = BuildingModelStore(db)
                store.save(restored.model)
                assertEquals(model, store.load(model.id))
            }
        } finally { db.close() }
    }

    @Test fun rejectsEmptyBackupInput() {
        try { BackupRestoreManager.restoreBundle(byteArrayOf()); fail("Empty backup must fail") }
        catch (_: IllegalArgumentException) { }
    }
}
