package com.aiarchitecture.app

import android.view.ViewGroup
import android.widget.FrameLayout
import android.os.SystemClock
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.aiarchitecture.app.core.geometry.BuildingModel
import com.aiarchitecture.app.feature.renderer.Building3DView
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class Building3DRenderingTest {
    @Test fun attachesLiveOpenGlSceneAndAcceptsCameraCommands(){ActivityScenario.launch(MainActivity::class.java).use{scenario->scenario.onActivity{activity->val view=Building3DView(activity,BuildingModel.starter());activity.addContentView(view,FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));view.setCameraPreset("isometric");view.setOrthographic(true);view.updateModel(BuildingModel.starter());view.onResume()};SystemClock.sleep(1200)}}
}
