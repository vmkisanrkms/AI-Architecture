package com.aiarchitecture.app

import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm
import com.aiarchitecture.app.feature.export.DimensionedPdfExporter
import java.io.File
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DimensionedPdfExportTest {
    @Test fun generatedDimensionScheduleIsAReadablePdfWithExpectedPageGeometry() {
        val floor = BuildingFloor(name = "Ground Floor", elevationMm = 0.0)
        val wall = BuildingElement(
            floorId = floor.id, type = ElementType.WALL, origin = Vec3(0.0, 0.0, 0.0),
            size = Size3(DimensionMm(4000.0), DimensionMm(150.0), DimensionMm(2800.0))
        )
        val model = BuildingModel(name = "PDF Validation House", floors = listOf(floor.copy(elements = listOf(wall))))
        val bytes = DimensionedPdfExporter.render(model)
        assertTrue("PDF output must contain more than a header", bytes.size > 500)
        assertEquals("%PDF", bytes.copyOfRange(0, 4).toString(Charsets.US_ASCII))
        assertTrue(bytes.copyOfRange(0, bytes.size).toString(Charsets.ISO_8859_1).contains("%%EOF"))

        val file = File.createTempFile("architecture-export-", ".pdf")
        try {
            file.writeBytes(bytes)
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                PdfRenderer(descriptor).use { renderer ->
                    assertEquals(1, renderer.pageCount)
                    renderer.openPage(0).use { page ->
                        assertTrue(page.width >= 500)
                        assertTrue(page.height >= 700)
                    }
                }
            }
        } finally { file.delete() }
    }

    @Test fun multiPageModelProducesAllRequiredPdfPages() {
        val base = BuildingModel.starter()
        val elements = (0 until 90).map { index ->
            BuildingElement(
                floorId = base.floors.first().id, type = ElementType.WALL,
                origin = Vec3(0.0, 0.0, index * 200.0),
                size = Size3(DimensionMm(4000.0), DimensionMm(150.0), DimensionMm(2800.0))
            )
        }
        val model = base.copy(floors = listOf(base.floors.first().copy(elements = elements)))
        val bytes = DimensionedPdfExporter.render(model)
        val file = File.createTempFile("architecture-multipage-", ".pdf")
        try {
            file.writeBytes(bytes)
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                PdfRenderer(descriptor).use { renderer -> assertTrue("Large schedule should paginate", renderer.pageCount >= 2) }
            }
        } finally { file.delete() }
    }
}
