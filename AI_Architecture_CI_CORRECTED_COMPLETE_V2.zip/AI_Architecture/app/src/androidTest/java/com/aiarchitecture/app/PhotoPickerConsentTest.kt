package com.aiarchitecture.app

import android.net.Uri
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.aiarchitecture.app.feature.photo.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PhotoPickerConsentTest {
    @Test fun requiresExplicitConsent(){val consent=PhotoUploadConsent(false,"design analysis",null);try{PhotoConsentPolicy.validate(Uri.parse("content://images/1"),"image/jpeg",100,consent);fail("Consent must be required")}catch(_:IllegalArgumentException){}}
    @Test fun acceptsConsentedSupportedImage(){PhotoConsentPolicy.validate(Uri.parse("content://images/1"),"image/jpeg",100,PhotoUploadConsent(true,"design analysis",1L))}
}
