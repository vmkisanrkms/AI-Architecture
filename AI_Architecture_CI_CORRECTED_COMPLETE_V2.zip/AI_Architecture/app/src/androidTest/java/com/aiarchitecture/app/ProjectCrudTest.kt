package com.aiarchitecture.app

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.aiarchitecture.app.data.local.AppDatabase
import com.aiarchitecture.app.data.local.ElementEntity
import com.aiarchitecture.app.data.local.FloorEntity
import com.aiarchitecture.app.data.repository.ProjectRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ProjectCrudTest {
    @Test fun createRenameDeleteProject()= runBlocking {
        val context=ApplicationProvider.getApplicationContext<android.content.Context>()
        val db=Room.inMemoryDatabaseBuilder(context,AppDatabase::class.java).allowMainThreadQueries().build()
        try { val repo=ProjectRepository(db);val id=repo.createProject("House");assertEquals("House",db.projects().getProject(id)?.name);assertEquals(1,db.floors().floors(id).size);repo.renameProject(id,"Farm House");assertEquals("Farm House",db.projects().getProject(id)?.name);repo.deleteProject(id);assertNull(db.projects().getProject(id)) } finally { db.close() }
    }
    @Test fun duplicateProjectCopiesFloorsAndElementsWithNewIdsAndRemappedFloorReferences() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        try {
            val repo = ProjectRepository(db)
            val sourceId = repo.createProject("Two Floor House")
            val sourceFloors = db.floors().floors(sourceId)
            val ground = sourceFloors.single()
            val upper = FloorEntity("source-upper-floor", sourceId, "First Floor", 3000.0)
            db.floors().upsertAll(listOf(upper))
            val sourceElements = listOf(
                ElementEntity("source-wall-ground", sourceId, ground.id, "WALL", 0.0, 0.0, 0.0, 4000.0, 150.0, 2800.0, "Brick", "[]", 1),
                ElementEntity("source-window-upper", sourceId, upper.id, "WINDOW", 500.0, 0.0, 0.0, 1200.0, 100.0, 1200.0, "Glass", "[]", 2)
            )
            db.elements().upsertAll(sourceElements)

            val copyId = repo.duplicateProject(sourceId)
            val original = db.projects().getProject(sourceId)!!
            val copy = db.projects().getProject(copyId)!!
            assertNotEquals(original.id, copy.id)
            assertEquals("Two Floor House (Copy)", copy.name)

            val copiedFloors = db.floors().floors(copyId)
            assertEquals(2, copiedFloors.size)
            assertTrue(copiedFloors.none { it.id == ground.id || it.id == upper.id })
            val copiedElements = db.elements().elements(copyId)
            assertEquals(2, copiedElements.size)
            assertTrue(copiedElements.none { it.id in sourceElements.map { source -> source.id } })
            val copiedFloorIds = copiedFloors.map { it.id }.toSet()
            assertTrue(copiedElements.all { it.floorId in copiedFloorIds })
            assertEquals(setOf("WALL", "WINDOW"), copiedElements.map { it.type }.toSet())
            assertEquals(1, copiedElements.single { it.type == "WALL" }.revision)
            assertEquals(2, copiedElements.single { it.type == "WINDOW" }.revision)
        } finally { db.close() }
    }

}
