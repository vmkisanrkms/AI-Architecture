package com.aiarchitecture.app

import androidx.compose.runtime.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import com.aiarchitecture.app.feature.shell.ScreenCatalog
import com.aiarchitecture.app.navigation.AppNavHost
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.runner.RunWith
import org.junit.Rule
import org.junit.Test

@RunWith(AndroidJUnit4::class)
class ScreenRouteNavigationTest {
    @get:Rule val composeRule = createAndroidComposeRule<MainActivity>()

    @Test fun allTwentyOneCatalogRoutesOpenTheirOwnRegisteredDestination() {
        lateinit var chooseStart: (String) -> Unit
        composeRule.setContent {
            var startRoute by remember { mutableStateOf("splash") }
            SideEffect { chooseStart = { startRoute = it } }
            key(startRoute) {
                val start = if (startRoute in setOf("splash", "language", "home")) startRoute else "screen/$startRoute"
                AppNavHost(startDestinationOverride = start)
            }
        }

        ScreenCatalog.all.forEach { screen ->
            composeRule.runOnIdle { chooseStart(screen.route) }
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("destination-${screen.route}", useUnmergedTree = true).assertExists()
        }
    }
}
