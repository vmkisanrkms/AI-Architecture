package com.aiarchitecture.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import com.aiarchitecture.app.navigation.AppNavHost
import com.aiarchitecture.app.ui.theme.AIArchitectureTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val darkTheme = getSharedPreferences("ai_architecture_preferences", MODE_PRIVATE).getBoolean("dark_theme", false)
        setContent {
            AIArchitectureTheme(darkTheme = darkTheme) {
                Surface(color = MaterialTheme.colorScheme.background) { AppNavHost() }
            }
        }
    }
}
