package com.aiarchitecture.app.core.geometry

import com.aiarchitecture.app.core.units.DimensionMm
import com.aiarchitecture.app.core.units.DimensionProvenance
import java.util.UUID

data class Vec2(val x: Double, val y: Double)
data class Vec3(val x: Double, val y: Double, val z: Double)
data class Size3(val length: DimensionMm, val width: DimensionMm, val height: DimensionMm)
enum class ElementType { WALL, FLOOR, ROOM, DOOR, WINDOW, STAIR, GATE, ARCH, PILLAR, GLASS_RAILING, STEEL_RAILING, BALCONY_RAILING, KITCHEN_CABINET, COUNTERTOP, SINK, TOILET, SHOWER, FURNITURE }

data class Opening(val id: String = UUID.randomUUID().toString(), val type: ElementType, val offsetMm: Double, val widthMm: Double, val heightMm: Double, val sillMm: Double = 0.0, val provenance: DimensionProvenance = DimensionProvenance.USER_ENTERED) {
    init { require(type == ElementType.DOOR || type == ElementType.WINDOW); require(offsetMm >= 0 && widthMm > 0 && heightMm > 0 && sillMm >= 0) }
}

data class BuildingElement(
    val id: String = UUID.randomUUID().toString(),
    val floorId: String,
    val type: ElementType,
    val origin: Vec3,
    val size: Size3,
    val material: String = "Default",
    val openings: List<Opening> = emptyList(),
    val revision: Long = 0,
    val yawDegrees: Double = 0.0
) {
    init {
        require(size.length.value > 0 && size.width.value > 0 && size.height.value > 0)
        if (type != ElementType.WALL) require(openings.isEmpty())
        openings.forEach { require(it.offsetMm + it.widthMm <= size.length.value + 1e-6); require(it.sillMm + it.heightMm <= size.height.value + 1e-6) }
        openings.sortedBy { it.offsetMm }.zipWithNext().forEach { (a,b) -> require(a.offsetMm + a.widthMm <= b.offsetMm + 1e-6) { "Wall openings must not overlap" } }
    }
    fun resized(newSize: Size3): BuildingElement = copy(size = newSize, revision = revision + 1)
    fun containsPlanPoint(point:Vec2):Boolean {
        val cx=origin.x+size.length.value/2.0;val cz=origin.z+size.width.value/2.0
        val dx=point.x-cx;val dz=point.y-cz;val angle=Math.toRadians(-yawDegrees)
        val localX=cx+dx*kotlin.math.cos(angle)-dz*kotlin.math.sin(angle)
        val localZ=cz+dx*kotlin.math.sin(angle)+dz*kotlin.math.cos(angle)
        return localX>=origin.x&&localX<=origin.x+size.length.value&&localZ>=origin.z&&localZ<=origin.z+size.width.value
    }
}

data class BuildingFloor(val id: String = UUID.randomUUID().toString(), val name: String, val elevationMm: Double, val elements: List<BuildingElement> = emptyList())
data class BuildingModel(val id: String = UUID.randomUUID().toString(), val name: String, val floors: List<BuildingFloor>) {
    fun replaceElement(updated: BuildingElement): BuildingModel = copy(floors = floors.map { floor ->
        if (floor.id != updated.floorId) floor else floor.copy(elements = floor.elements.map { if (it.id == updated.id) updated else it })
    })
    fun addFloor(name:String,elevationMm:Double):BuildingModel { require(name.isNotBlank()&&elevationMm>=0);return copy(floors=floors+BuildingFloor(name=name,elevationMm=elevationMm)) }
    fun addElement(element: BuildingElement): BuildingModel {
        require(floors.any { it.id == element.floorId })
        return copy(floors = floors.map { if (it.id == element.floorId) it.copy(elements = it.elements + element) else it })
    }
    fun removeElement(elementId: String): BuildingModel = copy(floors = floors.map { it.copy(elements = it.elements.filterNot { e -> e.id == elementId }) })
    companion object {
        fun starter(): BuildingModel {
            val floor = BuildingFloor(name = "Ground Floor", elevationMm = 0.0)
            return BuildingModel(name = "Untitled Project", floors = listOf(floor))
        }
    }
}
