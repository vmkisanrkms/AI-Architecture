package com.aiarchitecture.app.core.geometry

import com.aiarchitecture.app.core.units.DimensionProvenance

enum class DimensionAxis { LENGTH, WIDTH, HEIGHT, OPENING_OFFSET }
data class DimensionAnnotation(val elementId:String,val label:String,val valueMm:Double,val axis:DimensionAxis,val provenance:DimensionProvenance)
object DimensionEngine {
    fun annotations(model:BuildingModel):List<DimensionAnnotation> = buildList {
        model.floors.forEach{floor->floor.elements.forEach{e->
            add(DimensionAnnotation(e.id,"${e.type} length",e.size.length.value,DimensionAxis.LENGTH,e.size.length.provenance))
            add(DimensionAnnotation(e.id,"${e.type} width",e.size.width.value,DimensionAxis.WIDTH,e.size.width.provenance))
            add(DimensionAnnotation(e.id,"${e.type} height",e.size.height.value,DimensionAxis.HEIGHT,e.size.height.provenance))
            e.openings.forEach{o->
                add(DimensionAnnotation(e.id,"${o.type} width",o.widthMm,DimensionAxis.LENGTH,o.provenance))
                add(DimensionAnnotation(e.id,"${o.type} height",o.heightMm,DimensionAxis.HEIGHT,o.provenance))
                add(DimensionAnnotation(e.id,"${o.type} offset",o.offsetMm,DimensionAxis.OPENING_OFFSET,o.provenance))
            }
        }}
    }
    fun visibleLabel(annotation:DimensionAnnotation,unitFactorMm:Double=1.0,unit:String="mm",decimals:Int=1):String {
        require(unitFactorMm>0&&decimals in 0..5)
        val value=annotation.valueMm/unitFactorMm
        val estimate=if(annotation.provenance==DimensionProvenance.ESTIMATED) "Estimated " else ""
        return "$estimate${"%.${decimals}f".format(java.util.Locale.ROOT,value)} $unit"
    }
}
