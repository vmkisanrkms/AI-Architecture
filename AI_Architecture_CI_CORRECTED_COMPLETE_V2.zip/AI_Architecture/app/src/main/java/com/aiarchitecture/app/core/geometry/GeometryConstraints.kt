package com.aiarchitecture.app.core.geometry

import com.aiarchitecture.app.core.units.DimensionMm
import kotlin.math.abs

object GeometryConstraints {
    fun resizeProportionally(element:BuildingElement,newLengthMm:Double):BuildingElement {
        require(newLengthMm>0)
        val ratio=newLengthMm/element.size.length.value
        val scaledOpenings=element.openings.map{it.copy(offsetMm=it.offsetMm*ratio,widthMm=it.widthMm*ratio)}
        val updated=element.copy(size=element.size.copy(length=DimensionMm(newLengthMm),width=DimensionMm(element.size.width.value*ratio,element.size.width.provenance)),openings=scaledOpenings,revision=element.revision+1)
        require(updated.openings.all{it.offsetMm+it.widthMm<=newLengthMm+1e-6}){"Resize would move an opening outside its host wall"}
        return updated
    }
    fun alignStart(element:BuildingElement,target:Vec3):BuildingElement=element.copy(origin=target,revision=element.revision+1)
    fun isDimensionPreserved(before:BuildingElement,after:BuildingElement,toleranceMm:Double=0.01):Boolean=abs(before.size.height.value-after.size.height.value)<=toleranceMm
}
