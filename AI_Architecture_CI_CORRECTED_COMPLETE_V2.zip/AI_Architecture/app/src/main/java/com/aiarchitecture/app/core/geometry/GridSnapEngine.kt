package com.aiarchitecture.app.core.geometry

import kotlin.math.abs
import kotlin.math.round

data class SnapResult(val point:Vec2,val snappedTo:String?)
object GridSnapEngine {
    fun snap(point:Vec2,gridMm:Double,targets:List<Vec2> = emptyList(),toleranceMm:Double=80.0):SnapResult {
        require(gridMm>0&&toleranceMm>=0)
        val nearest=targets.minByOrNull{distance(point,it)}
        if(nearest!=null&&distance(point,nearest)<=toleranceMm)return SnapResult(nearest,"geometry")
        val grid=Vec2(round(point.x/gridMm)*gridMm,round(point.y/gridMm)*gridMm)
        return if(distance(point,grid)<=toleranceMm)SnapResult(grid,"grid") else SnapResult(point,null)
    }
    fun snapToGrid(point:Vec2,gridMm:Double):Vec2 { require(gridMm>0);return Vec2(round(point.x/gridMm)*gridMm,round(point.y/gridMm)*gridMm) }
    fun alignedCoordinate(value:Double,reference:Double,toleranceMm:Double=20.0):Double?=if(abs(value-reference)<=toleranceMm)reference else null
    private fun distance(a:Vec2,b:Vec2)=kotlin.math.hypot(a.x-b.x,a.y-b.y)
}
