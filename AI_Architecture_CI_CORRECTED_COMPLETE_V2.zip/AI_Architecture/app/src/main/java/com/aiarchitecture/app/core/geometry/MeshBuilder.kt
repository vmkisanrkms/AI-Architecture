package com.aiarchitecture.app.core.geometry

/** CPU-side triangle mesh generated from editable parametric elements. Coordinates are metres for GLES. */
data class MeshData(val vertices: FloatArray, val colors: FloatArray, val vertexCount: Int)
object MeshBuilder {
    fun build(model: BuildingModel): MeshData {
        val positions = ArrayList<Float>(); val colors = ArrayList<Float>()
        model.floors.forEach { floor -> floor.elements.forEach { element ->
            val localPositions = ArrayList<Float>(); val localColors = ArrayList<Float>()
            val y = (element.origin.y + floor.elevationMm) / 1000.0
            val l = element.size.length.value / 1000.0; val w = element.size.width.value / 1000.0; val h = element.size.height.value / 1000.0
            when (element.type) {
                ElementType.WALL -> addWallWithOpenings(localPositions, localColors, 0.0,y,0.0,l,w,h,element.openings)
                ElementType.PILLAR -> box(localPositions,localColors,0.0,y,0.0,w,h,l,0.72f,0.72f,0.76f)
                ElementType.FLOOR, ElementType.ROOM -> box(localPositions,localColors,0.0,y,0.0,l,0.06,w,0.68f,0.66f,0.60f)
                ElementType.DOOR -> box(localPositions,localColors,0.0,y,0.0,l,h,w,0.45f,0.25f,0.12f)
                ElementType.WINDOW -> box(localPositions,localColors,0.0,y,0.0,l,h,w,0.25f,0.65f,0.82f)
                ElementType.STAIR -> { val count = 8; for (i in 0 until count) box(localPositions,localColors,i*l/count,y+h*(i+1)/count,0.0,w,h*(i+1)/count,l/count,0.58f,0.58f,0.60f) }
                ElementType.GATE -> { val post=l*0.06; box(localPositions,localColors,0.0,y,0.0,post,h,w,0.25f,0.25f,0.28f); box(localPositions,localColors,l-post,y,0.0,post,h,w,0.25f,0.25f,0.28f); box(localPositions,localColors,0.0,y+h*0.88,0.0,l,h*0.12,w,0.30f,0.30f,0.34f) }
                ElementType.ARCH -> arch(localPositions,localColors,0.0,y,0.0,l,w,h,element.material)
                ElementType.GLASS_RAILING -> box(localPositions,localColors,0.0,y,0.0,l,h,w,0.40f,0.75f,0.88f)
                ElementType.KITCHEN_CABINET -> box(localPositions,localColors,0.0,y,0.0,l,h,w,0.62f,0.42f,0.28f)
                ElementType.COUNTERTOP -> box(localPositions,localColors,0.0,y,0.0,l,h,w,0.42f,0.42f,0.45f)
                ElementType.SINK -> box(localPositions,localColors,0.0,y,0.0,l,h,w,0.72f,0.78f,0.82f)
                ElementType.TOILET, ElementType.SHOWER, ElementType.FURNITURE -> box(localPositions,localColors,0.0,y,0.0,l,h,w,0.78f,0.80f,0.82f)
                ElementType.STEEL_RAILING, ElementType.BALCONY_RAILING -> { box(localPositions,localColors,0.0,y,0.0,l,0.04,w,0.25f,0.25f,0.28f); box(localPositions,localColors,0.0,y+h-0.04,0.0,l,0.04,w,0.25f,0.25f,0.28f); for(i in 0..5) box(localPositions,localColors,l*i/5,y,0.0,0.025,h,w,0.25f,0.25f,0.28f) }
            }
            val angle=Math.toRadians(element.yawDegrees);val cos=kotlin.math.cos(angle);val sin=kotlin.math.sin(angle)
            val ox=element.origin.x/1000.0;val oz=element.origin.z/1000.0
            for(i in localPositions.indices step 3){val lx=localPositions[i].toDouble();val ly=localPositions[i+1];val lz=localPositions[i+2].toDouble();positions.add((ox+lx*cos+lz*sin).toFloat());positions.add(ly);positions.add((oz-lx*sin+lz*cos).toFloat())}
            colors.addAll(localColors)
        } }
        return MeshData(positions.toFloatArray(),colors.toFloatArray(),positions.size/3)
    }
    private fun addWallWithOpenings(p:MutableList<Float>,c:MutableList<Float>,x:Double,y:Double,z:Double,l:Double,w:Double,h:Double, openings:List<Opening>) {
        val sorted=openings.sortedBy{it.offsetMm}; var cursor=0.0
        sorted.forEach { o -> val a=o.offsetMm/1000.0; val b=(o.offsetMm+o.widthMm)/1000.0
            if(a>cursor) box(p,c,x+cursor,y,z,a-cursor,h,w,0.78f,0.77f,0.72f)
            val sill=o.sillMm/1000.0; val top=(o.sillMm+o.heightMm)/1000.0
            if(sill>0) box(p,c,x+a,y,z,b-a,sill,w,0.78f,0.77f,0.72f)
            if(h>top) box(p,c,x+a,y+top,z,b-a,h-top,w,0.78f,0.77f,0.72f)
            // Opening is a true void in the wall; frame and leaf/glazing are separate geometry.
            val frame = 0.04
            box(p,c,x+a,y+sill,z,frame,h,w,0.42f,0.30f,0.18f)
            box(p,c,x+b-frame,y+sill,z,frame,h,w,0.42f,0.30f,0.18f)
            box(p,c,x+a,y+top-frame,z,b-a,frame,w,0.42f,0.30f,0.18f)
            if (o.type == ElementType.DOOR) {
                box(p,c,x+a+frame,y+sill,z+w*0.38,b-a-2*frame,h-sill,w*0.18,0.58f,0.38f,0.22f)
            } else {
                box(p,c,x+a+frame,y+sill+frame,z+w*0.43,b-a-2*frame,h-sill-2*frame,w*0.08,0.30f,0.68f,0.82f)
                box(p,c,x+a+frame,y+sill,z,b-a-2*frame,frame,w,0.42f,0.30f,0.18f)
            }
            cursor=b
        }
        if(cursor<l) box(p,c,x+cursor,y,z,l-cursor,h,w,0.78f,0.77f,0.72f)
    }
    private fun arch(p:MutableList<Float>,c:MutableList<Float>,x:Double,y:Double,z:Double,l:Double,w:Double,h:Double,profile:String) {
        val post=l*0.15
        box(p,c,x,y,z,post,h*0.75,w,0.72f,0.68f,0.60f); box(p,c,x+l-post,y,z,post,h*0.75,w,0.72f,0.68f,0.60f)
        val points=ArrayList<Pair<Double,Double>>()
        when(profile.uppercase()) {
            "SEGMENTAL" -> { for(i in 0..16){val t=i/16.0;val px=x+post+(l-2*post)*t;val py=y+h*0.78+Math.sin(Math.PI*t)*h*0.17;points.add(px to py)} }
            "POINTED" -> { for(i in 0..16){val t=i/16.0;val px=x+post+(l-2*post)*t;val rise=(1.0-kotlin.math.abs(2*t-1))*h*0.25;val py=y+h*0.75+rise;points.add(px to py)} }
            else -> { for(i in 0..16){val a=Math.PI-i*Math.PI/16.0;val px=x+l/2+Math.cos(a)*(l-2*post)/2;val py=y+h*0.75+Math.sin(a)*h*0.25;points.add(px to py)} }
        }
        for(i in 0 until points.lastIndex){val a=points[i];val b=points[i+1];prism(p,c,a.first,a.second,z,b.first,b.second,w*0.15,w,0.72f,0.68f,0.60f)}
    }
    private fun prism(p:MutableList<Float>,c:MutableList<Float>,x1:Double,y1:Double,z:Double,x2:Double,y2:Double,t:Double,depth:Double,r:Float,g:Float,b:Float){
        val dx=x2-x1; val dy=y2-y1; val len=kotlin.math.sqrt(dx*dx+dy*dy); if(len<1e-9)return
        val nx=-dy/len*t/2; val ny=dx/len*t/2
        val v=arrayOf(
            doubleArrayOf(x1+nx,y1+ny,z),doubleArrayOf(x2+nx,y2+ny,z),doubleArrayOf(x2-nx,y2-ny,z),doubleArrayOf(x1-nx,y1-ny,z),
            doubleArrayOf(x1+nx,y1+ny,z+depth),doubleArrayOf(x2+nx,y2+ny,z+depth),doubleArrayOf(x2-nx,y2-ny,z+depth),doubleArrayOf(x1-nx,y1-ny,z+depth)
        )
        val faces=arrayOf(intArrayOf(0,1,2,0,2,3),intArrayOf(5,4,7,5,7,6),intArrayOf(4,0,3,4,3,7),intArrayOf(1,5,6,1,6,2),intArrayOf(3,2,6,3,6,7),intArrayOf(4,5,1,4,1,0))
        faces.forEach{face->face.forEach{idx->p.add(v[idx][0].toFloat());p.add(v[idx][1].toFloat());p.add(v[idx][2].toFloat());c.add(r);c.add(g);c.add(b);c.add(1f)}}
    }
    private fun box(p:MutableList<Float>,c:MutableList<Float>,x:Double,y:Double,z:Double,l:Double,h:Double,w:Double,r:Float,g:Float,b:Float){
        val x0=x; val x1=x+l; val y0=y; val y1=y+h; val z0=z; val z1=z+w
        val v= arrayOf(
            doubleArrayOf(x0,y0,z0),doubleArrayOf(x1,y0,z0),doubleArrayOf(x1,y1,z0),doubleArrayOf(x0,y1,z0),
            doubleArrayOf(x0,y0,z1),doubleArrayOf(x1,y0,z1),doubleArrayOf(x1,y1,z1),doubleArrayOf(x0,y1,z1))
        val faces=arrayOf(intArrayOf(0,1,2,0,2,3),intArrayOf(5,4,7,5,7,6),intArrayOf(4,0,3,4,3,7),intArrayOf(1,5,6,1,6,2),intArrayOf(3,2,6,3,6,7),intArrayOf(4,5,1,4,1,0))
        faces.forEach { face -> face.forEach { idx -> p.add(v[idx][0].toFloat());p.add(v[idx][1].toFloat());p.add(v[idx][2].toFloat());c.add(r);c.add(g);c.add(b);c.add(1f) } }
    }
}
