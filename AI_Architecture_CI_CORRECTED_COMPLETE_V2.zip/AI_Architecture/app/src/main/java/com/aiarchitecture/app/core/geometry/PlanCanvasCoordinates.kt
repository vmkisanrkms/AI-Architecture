package com.aiarchitecture.app.core.geometry

/**
 * Converts pointer coordinates from the Compose Canvas (pixels) into the
 * canonical millimetre coordinate system used by the 2D plan model.
 *
 * Canvas coordinates and scale are Float because Compose drawing uses pixels;
 * model geometry is Double so the conversion is explicit at this boundary.
 */
data class PlanCanvasTransform(
    val scale: Float,
    val originX: Float = 30f,
    val originY: Float = 30f
) {
    init {
        require(scale.isFinite() && scale > 0f) { "Canvas scale must be finite and positive" }
        require(originX.isFinite() && originY.isFinite()) { "Canvas origin must be finite" }
    }

    fun toModelPoint(canvasX: Float, canvasY: Float): Vec2 {
        require(canvasX.isFinite() && canvasY.isFinite()) { "Canvas point must be finite" }
        val scalePixelsPerMm = scale.toDouble()
        return Vec2(
            (canvasX - originX).toDouble() / scalePixelsPerMm,
            (canvasY - originY).toDouble() / scalePixelsPerMm
        )
    }
}
