package com.aiarchitecture.app.core.history

/** Immutable snapshots make undo/redo deterministic and preserve geometry + properties together. */
class ModelHistory<T>(initial: T, private val capacity: Int = 100) {
    private val undo = mutableListOf(initial)
    private val redo = mutableListOf<T>()
    val current: T get() = undo.last()
    fun commit(next: T) { if (next == current) return; undo.add(next); while (undo.size > capacity) undo.removeAt(0); redo.clear() }
    fun undo(): T { if (undo.size > 1) redo.add(undo.removeAt(undo.lastIndex)); return current }
    fun redo(): T { if (redo.isNotEmpty()) undo.add(redo.removeAt(redo.lastIndex)); return current }
    val canUndo: Boolean get() = undo.size > 1
    val canRedo: Boolean get() = redo.isNotEmpty()
}
