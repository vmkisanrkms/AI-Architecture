package com.aiarchitecture.app.core.units

/** All model lengths are stored as millimetres. Conversion never uses rounded display text. */
enum class LengthUnit(val millimetresPerUnit: Double, val symbol: String) {
    MILLIMETRE(1.0, "mm"), METRE(1000.0, "m"), INCH(25.4, "in"), FOOT(304.8, "ft")
}

object Units {
    fun toMillimetres(value: Double, unit: LengthUnit): Double {
        require(value.isFinite() && value >= 0.0) { "Length must be finite and non-negative" }
        return value * unit.millimetresPerUnit
    }
    fun fromMillimetres(mm: Double, unit: LengthUnit): Double {
        require(mm.isFinite() && mm >= 0.0) { "Length must be finite and non-negative" }
        return mm / unit.millimetresPerUnit
    }
    fun format(mm: Double, unit: LengthUnit, decimals: Int = 2): String {
        require(decimals in 0..6)
        return "% .${decimals}f %s".format(java.util.Locale.ROOT, fromMillimetres(mm, unit), unit.symbol).trim()
    }
}

enum class DimensionProvenance { USER_ENTERED, DERIVED, ESTIMATED }
data class DimensionMm(val value: Double, val provenance: DimensionProvenance = DimensionProvenance.USER_ENTERED) {
    init { require(value.isFinite() && value >= 0.0) }
    val label: String get() = if (provenance == DimensionProvenance.ESTIMATED) "Estimated" else ""
}
