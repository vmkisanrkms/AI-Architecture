package com.aiarchitecture.app.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC") fun observeProjects(): Flow<List<ProjectEntity>>
    @Query("SELECT * FROM projects WHERE id=:id LIMIT 1") suspend fun getProject(id:String):ProjectEntity?
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC LIMIT 1") suspend fun latestProject():ProjectEntity?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsert(project:ProjectEntity)
    @Query("DELETE FROM projects WHERE id=:id") suspend fun delete(id:String)
}
@Dao interface FloorDao {
    @Query("SELECT * FROM floors WHERE projectId=:projectId ORDER BY elevationMm") suspend fun floors(projectId:String):List<FloorEntity>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<FloorEntity>)
    @Query("DELETE FROM floors WHERE projectId=:projectId") suspend fun deleteForProject(projectId:String)
}
@Dao interface ElementDao {
    @Query("SELECT * FROM building_elements WHERE projectId=:projectId") suspend fun elements(projectId:String):List<ElementEntity>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<ElementEntity>)
    @Query("DELETE FROM building_elements WHERE projectId=:projectId") suspend fun deleteForProject(projectId:String)
}
@Dao interface HistoryDao {
    @Insert suspend fun add(item:EditHistoryEntity)
    @Query("SELECT * FROM edit_history WHERE projectId=:projectId ORDER BY sequence DESC LIMIT 100") suspend fun recent(projectId:String):List<EditHistoryEntity>
    @Query("DELETE FROM edit_history WHERE projectId=:projectId") suspend fun clear(projectId:String)
}
@Database(entities=[ProjectEntity::class,FloorEntity::class,ElementEntity::class,EditHistoryEntity::class],version=1,exportSchema=true)
abstract class AppDatabase:RoomDatabase(){ abstract fun projects():ProjectDao; abstract fun floors():FloorDao; abstract fun elements():ElementDao; abstract fun history():HistoryDao }
