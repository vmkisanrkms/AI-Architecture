package com.aiarchitecture.app.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName="projects")
data class ProjectEntity(@PrimaryKey val id:String, val name:String, val createdAt:Long, val updatedAt:Long)
@Entity(tableName="floors", indices=[Index(value=["projectId"])])
data class FloorEntity(@PrimaryKey val id:String, val projectId:String, val name:String, val elevationMm:Double)
@Entity(tableName="building_elements", indices=[Index(value=["floorId"]),Index(value=["projectId"])])
data class ElementEntity(@PrimaryKey val id:String, val projectId:String, val floorId:String, val type:String, val xMm:Double, val yMm:Double, val zMm:Double, val lengthMm:Double, val widthMm:Double, val heightMm:Double, val material:String, val openingsJson:String, val revision:Long, val lengthProvenance:String="USER_ENTERED", val widthProvenance:String="USER_ENTERED", val heightProvenance:String="USER_ENTERED", val yawDegrees:Double=0.0 )
@Entity(tableName="edit_history", indices=[Index(value=["projectId"])])
data class EditHistoryEntity(@PrimaryKey(autoGenerate=true) val sequence:Long=0, val projectId:String, val snapshotJson:String, val createdAt:Long)
