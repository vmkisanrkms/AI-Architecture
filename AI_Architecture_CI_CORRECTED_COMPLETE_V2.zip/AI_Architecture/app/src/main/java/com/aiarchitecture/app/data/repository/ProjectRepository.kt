package com.aiarchitecture.app.data.repository

import androidx.room.withTransaction
import com.aiarchitecture.app.data.local.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class ProjectRepository(private val db:AppDatabase) {
    fun observeProjects():Flow<List<ProjectEntity>> = db.projects().observeProjects()
    suspend fun createProject(name:String):String { require(name.isNotBlank()); val id=UUID.randomUUID().toString(); val now=System.currentTimeMillis(); db.withTransaction { db.projects().upsert(ProjectEntity(id,name.trim(),now,now)); db.floors().upsertAll(listOf(FloorEntity(UUID.randomUUID().toString(),id,"Ground Floor",0.0))) }; return id }
    suspend fun renameProject(id:String,name:String){ require(name.isNotBlank()); val old=db.projects().getProject(id)?:error("Project not found"); db.projects().upsert(old.copy(name=name.trim(),updatedAt=System.currentTimeMillis())) }
    suspend fun duplicateProject(id:String):String {
        val original = db.projects().getProject(id) ?: error("Project not found")
        val newId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        db.withTransaction {
            db.projects().upsert(original.copy(id = newId, name = "${original.name} (Copy)", createdAt = now, updatedAt = now))
            val floorMap = db.floors().floors(id).associate { it.id to UUID.randomUUID().toString() }
            db.floors().upsertAll(db.floors().floors(id).map { it.copy(id = floorMap.getValue(it.id), projectId = newId) })
            db.elements().upsertAll(db.elements().elements(id).map { element -> element.copy(id = UUID.randomUUID().toString(), projectId = newId, floorId = floorMap[element.floorId] ?: error("Floor reference missing")) })
        }
        return newId
    }
    suspend fun deleteProject(id:String){ db.withTransaction { db.elements().deleteForProject(id); db.floors().deleteForProject(id); db.history().clear(id); db.projects().delete(id) } }
}
