package com.aiarchitecture.app.feature.ai

/** Network AI is optional; credentials must live on a consented backend, never in the APK. */
enum class AiProviderKind { OPENAI_COMPATIBLE, GEMINI_COMPATIBLE, SELF_HOSTED }
data class AiProviderConfiguration(val kind:AiProviderKind,val endpoint:String,val userConsent:Boolean,val apiKeyEmbeddedInApp:Boolean=false)
object AiProviderPolicy {
    fun validate(config:AiProviderConfiguration):List<String> = buildList {
        if(!config.userConsent)add("User consent is required before sending a design brief")
        if(!config.endpoint.startsWith("https://",ignoreCase=true))add("AI endpoint must use HTTPS")
        if(config.apiKeyEmbeddedInApp)add("Provider API keys must not be embedded in the APK")
    }
}
