package com.aiarchitecture.app.feature.ai

data class DesignBrief(val buildingType:String,val plotLengthMm:Double?,val plotWidthMm:Double?,val floors:Int,val rooms:Int,val style:String,val notes:String)
object DesignBriefValidator {
    fun validate(brief:DesignBrief):List<String> = buildList {
        if(brief.buildingType.isBlank()) add("Building type is required")
        if(brief.plotLengthMm!=null&&brief.plotLengthMm<=0) add("Plot length must be positive")
        if(brief.plotWidthMm!=null&&brief.plotWidthMm<=0) add("Plot width must be positive")
        if(brief.floors !in 1..20) add("Floor count must be between 1 and 20")
        if(brief.rooms !in 0..200) add("Room count is outside supported range")
        if(brief.notes.length>4000) add("Notes are too long")
    }
}
/** No fake result is generated locally. A real provider must be configured and consented before use. */
interface AiDesignProvider { suspend fun generate(brief:DesignBrief):Result<String> }
