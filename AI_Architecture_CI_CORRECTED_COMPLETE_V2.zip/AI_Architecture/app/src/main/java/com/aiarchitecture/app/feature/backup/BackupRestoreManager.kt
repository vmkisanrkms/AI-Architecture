package com.aiarchitecture.app.feature.backup

import com.aiarchitecture.app.core.geometry.BuildingModel
import com.aiarchitecture.app.data.repository.ModelJson
import org.json.JSONObject
import java.security.MessageDigest

data class RestoredBackup(
    val model: BuildingModel,
    /** Original attachment name -> exact original bytes. */
    val images: Map<String, ByteArray>
)

/** Portable, bounded JSON backup with SHA-256 integrity check and optional image attachments. */
object BackupRestoreManager {
    const val MAX_BACKUP_BYTES = 80L * 1024L * 1024L
    private const val FORMAT_V1 = "ai-architecture-backup-v1"
    private const val FORMAT_V2 = "ai-architecture-backup-v2"

    /** Keeps the original API and v1-compatible behavior for callers that do not include images. */
    fun createBackup(model: BuildingModel): ByteArray = createBackup(model, emptyMap())

    /**
     * Creates a JSON archive containing the canonical model plus optional image bytes.
     * Image entries are base64 encoded; the checksum covers model JSON and sorted image names/data.
     */
    fun createBackup(model: BuildingModel, images: Map<String, ByteArray>): ByteArray {
        require(images.keys.none { it.isBlank() || it.contains('/') || it.contains('\\') || it == "." || it == ".." }) {
            "Image attachment names must be safe file names"
        }
        val totalImageBytes = images.values.sumOf { it.size.toLong() }
        require(totalImageBytes <= MAX_BACKUP_BYTES) { "Image attachments exceed backup size limit" }
        val payload = ModelJson.encode(model)
        val encodedImages = JSONObject()
        images.toSortedMap().forEach { (name, bytes) ->
            encodedImages.put(name, java.util.Base64.getEncoder().encodeToString(bytes))
        }
        val digest = sha256(checksumInput(payload, images))
        val result = JSONObject()
            .put("format", FORMAT_V2)
            .put("sha256", digest)
            .put("payload", payload)
            .put("images", encodedImages)
            .toString()
            .toByteArray(Charsets.UTF_8)
        require(result.size.toLong() <= MAX_BACKUP_BYTES) { "Backup size is invalid" }
        return result
    }

    /** Backward-compatible model-only restore. Image-capable callers should use restoreBundle. */
    fun restore(bytes: ByteArray): BuildingModel = restoreBundle(bytes).model

    fun restoreBundle(bytes: ByteArray): RestoredBackup {
        require(bytes.isNotEmpty() && bytes.size.toLong() <= MAX_BACKUP_BYTES) { "Backup size is invalid" }
        val envelope = JSONObject(bytes.toString(Charsets.UTF_8))
        val format = envelope.getString("format")
        val payload = envelope.getString("payload")
        val expectedDigest = envelope.getString("sha256")
        val images = linkedMapOf<String, ByteArray>()
        when (format) {
            FORMAT_V1 -> {
                require(sha256(payload.toByteArray(Charsets.UTF_8)) == expectedDigest) { "Backup checksum mismatch" }
            }
            FORMAT_V2 -> {
                val encoded = envelope.getJSONObject("images")
                val keys = encoded.keys()
                while (keys.hasNext()) {
                    val name = keys.next()
                    require(name.isNotBlank() && !name.contains('/') && !name.contains('\\') && name != "." && name != "..") {
                        "Unsafe image attachment name"
                    }
                    val value = java.util.Base64.getDecoder().decode(encoded.getString(name))
                    images[name] = value
                }
                require(images.values.sumOf { it.size.toLong() } <= MAX_BACKUP_BYTES) { "Image attachments exceed backup size limit" }
                require(sha256(checksumInput(payload, images)) == expectedDigest) { "Backup checksum mismatch" }
            }
            else -> throw IllegalArgumentException("Unsupported backup format")
        }
        return RestoredBackup(ModelJson.decode(payload), images)
    }

    private fun checksumInput(payload: String, images: Map<String, ByteArray>): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        out.write(payload.toByteArray(Charsets.UTF_8))
        images.toSortedMap().forEach { (name, bytes) ->
            out.write(0)
            out.write(name.toByteArray(Charsets.UTF_8))
            out.write(0)
            out.write(bytes)
        }
        return out.toByteArray()
    }

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}
