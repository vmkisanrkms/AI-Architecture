package com.aiarchitecture.app.feature.backup

import java.io.InputStream

fun InputStream.readBounded(maxBytes:Long):ByteArray {
    require(maxBytes>0)
    val out=java.io.ByteArrayOutputStream();val buffer=ByteArray(8192);var total=0L
    while(true){val n=read(buffer);if(n<0)break;total+=n;require(total<=maxBytes){"Input exceeds size limit"};out.write(buffer,0,n)}
    return out.toByteArray()
}
