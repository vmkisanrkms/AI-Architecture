package com.aiarchitecture.app.feature.bathroom

import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm

object BathroomLayout {
    fun fixture(floorId:String,type:ElementType,origin:Vec3,lengthMm:Double,widthMm:Double,heightMm:Double):BuildingElement { require(type in setOf(ElementType.SINK,ElementType.TOILET,ElementType.SHOWER));return BuildingElement(floorId=floorId,type=type,origin=origin,size=Size3(DimensionMm(lengthMm),DimensionMm(widthMm),DimensionMm(heightMm)),material="Sanitaryware") }
}
