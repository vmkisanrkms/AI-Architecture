package com.aiarchitecture.app.feature.boundary

import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm

object BoundaryWall {
    fun wall(floorId:String,origin:Vec3,lengthMm:Double,heightMm:Double,thicknessMm:Double)=BuildingElement(floorId=floorId,type=ElementType.WALL,origin=origin,size=Size3(DimensionMm(lengthMm),DimensionMm(thicknessMm),DimensionMm(heightMm)),material="Boundary masonry")
    fun pillar(floorId:String,origin:Vec3,widthMm:Double,depthMm:Double,heightMm:Double)=BuildingElement(floorId=floorId,type=ElementType.PILLAR,origin=origin,size=Size3(DimensionMm(widthMm),DimensionMm(depthMm),DimensionMm(heightMm)),material="Boundary pillar")
}
