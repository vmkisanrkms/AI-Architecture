package com.aiarchitecture.app.feature.calculator

import kotlin.math.ceil

data class MaterialEstimate(val quantity:Double,val unit:String,val notes:String)
object MaterialCalculations {
    fun wallVolume(lengthMm:Double,heightMm:Double,thicknessMm:Double,openingAreaSqM:Double=0.0):Double {
        require(listOf(lengthMm,heightMm,thicknessMm,openingAreaSqM).all{it>=0});val gross=lengthMm/1000*heightMm/1000*thicknessMm/1000;return (gross-openingAreaSqM*thicknessMm/1000).coerceAtLeast(0.0)
    }
    fun bricks(wallVolumeM3:Double,brickLengthMm:Double=190.0,brickWidthMm:Double=90.0,brickHeightMm:Double=90.0,mortarFactor:Double=1.0):MaterialEstimate {
        require(wallVolumeM3>=0&&brickLengthMm>0&&brickWidthMm>0&&brickHeightMm>0&&mortarFactor>0)
        val brickVolume=(brickLengthMm/1000)*(brickWidthMm/1000)*(brickHeightMm/1000);return MaterialEstimate(ceil(wallVolumeM3/brickVolume*mortarFactor),"bricks","Approximate count; joint/bond allowance must be selected")
    }
    fun concreteVolume(lengthMm:Double,widthMm:Double,depthMm:Double)=wallVolume(lengthMm,widthMm,depthMm)
    fun plasterArea(lengthMm:Double,heightMm:Double,openingsSqM:Double=0.0)=((lengthMm/1000)*(heightMm/1000)-openingsSqM).coerceAtLeast(0.0)
    fun paintLitres(areaSqM:Double,coverageSqMPerLitre:Double,coats:Int):Double { require(areaSqM>=0&&coverageSqMPerLitre>0&&coats>0);return areaSqM*coats/coverageSqMPerLitre }
    fun tileCount(areaSqM:Double,tileLengthMm:Double,tileWidthMm:Double,wastagePercent:Double=5.0):Long { require(areaSqM>=0&&tileLengthMm>0&&tileWidthMm>0&&wastagePercent>=0);val tileArea=tileLengthMm/1000*tileWidthMm/1000;return ceil(areaSqM*(1+wastagePercent/100)/tileArea).toLong() }
}
