package com.aiarchitecture.app.feature.components

import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm

object ArchComponent { fun create(floorId:String,origin:Vec3,spanMm:Double,depthMm:Double,heightMm:Double,profile:ArchProfile)=ArchitecturalComponents.instantiate("arch",floorId,origin).copy(size=Size3(DimensionMm(spanMm),DimensionMm(depthMm),DimensionMm(heightMm)),material=profile.name) }
enum class ArchProfile { SEMICIRCULAR, SEGMENTAL, POINTED }
