package com.aiarchitecture.app.feature.components

import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm

/** Parametric component catalog; each entry creates editable model geometry, not a preview bitmap. */
data class ComponentDefinition(val key:String,val label:String,val type:ElementType,val defaultLengthMm:Double,val defaultWidthMm:Double,val defaultHeightMm:Double,val material:String)
object ArchitecturalComponents {
    val catalog=listOf(
        ComponentDefinition("gate","Gate",ElementType.GATE,3000.0,150.0,2400.0,"Steel"),
        ComponentDefinition("arch","Arch",ElementType.ARCH,1800.0,300.0,2400.0,"Masonry"),
        ComponentDefinition("pillar","Pillar",ElementType.PILLAR,300.0,300.0,2800.0,"Concrete"),
        ComponentDefinition("glass-railing","Glass Railing",ElementType.GLASS_RAILING,2500.0,50.0,1000.0,"Tempered glass"),
        ComponentDefinition("steel-railing","Steel Railing",ElementType.STEEL_RAILING,2500.0,50.0,1000.0,"Steel"),
        ComponentDefinition("balcony-railing","Balcony Railing",ElementType.BALCONY_RAILING,3000.0,50.0,1050.0,"Steel"),
        ComponentDefinition("stair","Stair",ElementType.STAIR,2800.0,1000.0,1800.0,"Concrete"),
        ComponentDefinition("door","Door",ElementType.DOOR,900.0,100.0,2100.0,"Timber"),
        ComponentDefinition("window","Window",ElementType.WINDOW,1200.0,100.0,1200.0,"Aluminium / Glass")
    )
    fun instantiate(key:String,floorId:String,origin:Vec3):BuildingElement{
        val d=catalog.firstOrNull{it.key==key}?:error("Unknown component: $key")
        return BuildingElement(floorId=floorId,type=d.type,origin=origin,size=Size3(DimensionMm(d.defaultLengthMm),DimensionMm(d.defaultWidthMm),DimensionMm(d.defaultHeightMm)),material=d.material)
    }
}
