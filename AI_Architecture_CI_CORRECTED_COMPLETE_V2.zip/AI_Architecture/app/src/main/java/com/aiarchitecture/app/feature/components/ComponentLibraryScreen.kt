package com.aiarchitecture.app.feature.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable fun ComponentLibraryScreen(onInsert:(String)->Unit){
    Column(Modifier.fillMaxWidth().heightIn(max=380.dp).verticalScroll(rememberScrollState())){
        Text("Choose a parametric component to insert into the active floor.")
        ArchitecturalComponents.catalog.forEach{item->
            Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){
                Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){Text(item.label,style=MaterialTheme.typography.titleMedium);Text("${item.defaultLengthMm} × ${item.defaultWidthMm} × ${item.defaultHeightMm} mm",style=MaterialTheme.typography.bodySmall)}
                    Button(onClick={onInsert(item.key)}){Text("Insert")}
                }
            }
        }
    }
}
