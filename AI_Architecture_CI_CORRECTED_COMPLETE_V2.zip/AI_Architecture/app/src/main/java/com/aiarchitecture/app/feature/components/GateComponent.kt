package com.aiarchitecture.app.feature.components

import com.aiarchitecture.app.core.geometry.*

object GateComponent { fun create(floorId:String,origin:Vec3,widthMm:Double,heightMm:Double,depthMm:Double)=ArchitecturalComponents.instantiate("gate",floorId,origin).copy(size=Size3(com.aiarchitecture.app.core.units.DimensionMm(widthMm),com.aiarchitecture.app.core.units.DimensionMm(depthMm),com.aiarchitecture.app.core.units.DimensionMm(heightMm))) }
