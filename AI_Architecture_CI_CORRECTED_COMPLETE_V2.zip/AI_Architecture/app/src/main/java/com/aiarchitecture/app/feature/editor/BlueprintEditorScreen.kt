package com.aiarchitecture.app.feature.editor

import android.content.Intent
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.room.Room
import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.history.ModelHistory
import com.aiarchitecture.app.core.units.DimensionMm
import com.aiarchitecture.app.data.local.AppDatabase
import com.aiarchitecture.app.data.repository.BuildingModelStore
import com.aiarchitecture.app.feature.backup.BackupRestoreManager
import com.aiarchitecture.app.feature.backup.readBounded
import com.aiarchitecture.app.feature.export.DimensionedPdfExporter
import com.aiarchitecture.app.feature.renderer.Building3DView
import com.aiarchitecture.app.feature.components.ComponentLibraryScreen
import com.aiarchitecture.app.feature.components.ArchitecturalComponents
import kotlinx.coroutines.delay
import java.util.UUID

@Composable
fun BlueprintEditorScreen(projectId:String?=null) {
    val context=LocalContext.current
    val db=remember{Room.databaseBuilder(context,AppDatabase::class.java,"ai_architecture.db").build()}
    val store=remember{BuildingModelStore(db)}
    val initial=remember{BuildingModel.starter()}
    var history by remember{mutableStateOf(ModelHistory(initial))}
    var model by remember{mutableStateOf(initial)}
    var view by remember{mutableStateOf("2D")}
    var selectedId by remember{mutableStateOf<String?>(null)}
    var activeFloorId by remember{mutableStateOf(initial.floors.first().id)}
    var floorMenu by remember{mutableStateOf(false)}
    var lengthInput by remember{mutableStateOf("")}
    var widthInput by remember{mutableStateOf("")}
    var heightInput by remember{mutableStateOf("")}
    var saveState by remember{mutableStateOf("Local autosave ready")}
    var storageReady by remember{mutableStateOf(false)}
    var rendererView by remember{mutableStateOf<Building3DView?>(null)}
    var orthographic by remember{mutableStateOf(false)}
    var showLibrary by remember{mutableStateOf(false)}
    val backupExport=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->uri?.let{runCatching{requireNotNull(context.contentResolver.openOutputStream(it)).use{out->out.write(BackupRestoreManager.createBackup(model))}}.onSuccess{saveState="Backup exported"}.onFailure{saveState="Backup failed: ${it.message}"}}}
    val backupImport=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->uri?.let{runCatching{context.contentResolver.openInputStream(it)!!.use{input->BackupRestoreManager.restore(input.readBounded(BackupRestoreManager.MAX_BACKUP_BYTES))}}.onSuccess{restored->history.commit(restored);model=restored;activeFloorId=restored.floors.firstOrNull()?.id?:activeFloorId;selectedId=null;saveState="Backup restored"}.onFailure{saveState="Restore rejected: ${it.message}"}}}
    val pdfExport=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){uri->uri?.let{runCatching{requireNotNull(context.contentResolver.openOutputStream(it)).use{out->out.write(DimensionedPdfExporter.render(model))}}.onSuccess{saveState="Dimensioned PDF exported"}.onFailure{saveState="PDF export failed: ${it.message}"}}}
    LaunchedEffect(projectId){runCatching{if(projectId==null)store.loadLatest() else store.load(projectId)}.getOrNull()?.let{loaded->model=loaded;history=ModelHistory(loaded);activeFloorId=loaded.floors.firstOrNull()?.id?:activeFloorId};storageReady=true}
    LaunchedEffect(model,storageReady){if(storageReady){delay(650);runCatching{store.save(model)}.onSuccess{saveState="Saved locally"}.onFailure{saveState="Save error: ${it.message}"}}}
    fun commit(next:BuildingModel){history.commit(next);model=next}
    fun add(type:ElementType){val floor=model.floors.firstOrNull{it.id==activeFloorId}?:model.floors.first();val count=floor.elements.size;val size=when(type){ElementType.WALL->Size3(DimensionMm(4000.0),DimensionMm(150.0),DimensionMm(2800.0));ElementType.PILLAR->Size3(DimensionMm(300.0),DimensionMm(300.0),DimensionMm(2800.0));ElementType.STAIR->Size3(DimensionMm(2800.0),DimensionMm(1000.0),DimensionMm(1800.0));ElementType.GATE->Size3(DimensionMm(3000.0),DimensionMm(150.0),DimensionMm(2400.0));ElementType.ARCH->Size3(DimensionMm(1800.0),DimensionMm(300.0),DimensionMm(2400.0));ElementType.GLASS_RAILING,ElementType.STEEL_RAILING,ElementType.BALCONY_RAILING->Size3(DimensionMm(2500.0),DimensionMm(50.0),DimensionMm(1000.0));else->Size3(DimensionMm(900.0),DimensionMm(100.0),DimensionMm(2100.0))};val snapped=GridSnapEngine.snapToGrid(Vec2(count*350.0,count*250.0),500.0);val e=BuildingElement(floorId=floor.id,type=type,origin=Vec3(snapped.x,0.0,snapped.y),size=size);commit(model.addElement(e));selectedId=e.id;lengthInput=e.size.length.value.toString();widthInput=e.size.width.value.toString();heightInput=e.size.height.value.toString()}
    val selected=model.floors.flatMap{it.elements}.firstOrNull{it.id==selectedId}
    Column(Modifier.fillMaxSize().background(Color(0xFFF5F6F8)).padding(12.dp)){
        Text("AI Architecture — Building Editor",style=MaterialTheme.typography.titleLarge)
        Text(saveState,style=MaterialTheme.typography.labelSmall,color=Color(0xFF52616B))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(selected=view=="2D",onClick={view="2D"},label={Text("2D Blueprint")});FilterChip(selected=view=="3D",onClick={view="3D"},label={Text("Live 3D Model")})}
        Box(Modifier.weight(1f).fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp)).padding(6.dp)){
            if(view=="2D") PlanCanvas(model,activeFloorId,selectedId){id->selectedId=id;model.floors.flatMap{it.elements}.firstOrNull{e->e.id==id}?.let{e->lengthInput=e.size.length.value.toString();widthInput=e.size.width.value.toString();heightInput=e.size.height.value.toString()}}
            else AndroidView(factory={ctx->Building3DView(ctx,model).apply{rendererView=this;layoutParams=ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)}},update={it.updateModel(model)},modifier=Modifier.fillMaxSize())
        }
        Text("Elements: ${model.floors.sumOf{it.elements.size}} | Canonical unit: mm",style=MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment= androidx.compose.ui.Alignment.CenterVertically){
            Box{OutlinedButton(onClick={floorMenu=true}){Text(model.floors.firstOrNull{it.id==activeFloorId}?.name?:"Select floor")};DropdownMenu(expanded=floorMenu,onDismissRequest={floorMenu=false}){model.floors.forEach{floor->DropdownMenuItem(text={Text("${floor.name} — ${floor.elevationMm} mm")},onClick={activeFloorId=floor.id;selectedId=null;floorMenu=false})}}}
            OutlinedButton(onClick={val elevation=(model.floors.maxOfOrNull{it.elevationMm}?:0.0)+3000.0;val next=model.addFloor("Floor ${model.floors.size+1}",elevation);commit(next);activeFloorId=next.floors.last().id;selectedId=null}){Text("+ Add Floor")}
        }
        if(view=="3D"){
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                listOf("Front","Back","Left","Right","Top","Iso").forEach{preset->TextButton(onClick={rendererView?.setCameraPreset(preset)}){Text(preset)}}
                FilterChip(selected=orthographic,onClick={orthographic=!orthographic;rendererView?.setOrthographic(orthographic)},label={Text("Orthographic")})
            }
            Text("3D controls: drag to orbit, pinch to zoom, two-finger drag to pan.",style=MaterialTheme.typography.labelSmall)
        }
        if(selected!=null){
            Text("Properties: ${selected.type}  |  ${selected.id.take(8)}",style=MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp),verticalAlignment= androidx.compose.ui.Alignment.CenterVertically){
                OutlinedTextField(value=lengthInput,onValueChange={lengthInput=it},label={Text("L mm")},modifier=Modifier.weight(1f),singleLine=true)
                OutlinedTextField(value=widthInput,onValueChange={widthInput=it},label={Text("W mm")},modifier=Modifier.weight(1f),singleLine=true)
                OutlinedTextField(value=heightInput,onValueChange={heightInput=it},label={Text("H mm")},modifier=Modifier.weight(1f),singleLine=true)
                Button(onClick={val l=lengthInput.toDoubleOrNull();val w=widthInput.toDoubleOrNull();val h=heightInput.toDoubleOrNull();if(l!=null&&w!=null&&h!=null&&l>0&&w>0&&h>0){val updated=selected.copy(size=Size3(DimensionMm(l),DimensionMm(w),DimensionMm(h)),revision=selected.revision+1);commit(model.replaceElement(updated));saveState="Geometry dimensions updated"}else saveState="All dimensions must be positive"}){Text("Apply")}
                OutlinedButton(onClick={commit(model.removeElement(selected.id));selectedId=null}){Text("Delete")}
            }
            Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){
                OutlinedButton(onClick={commit(model.replaceElement(selected.copy(origin=selected.origin.copy(x=selected.origin.x-100),revision=selected.revision+1)))}){Text("← 100")}
                OutlinedButton(onClick={commit(model.replaceElement(selected.copy(origin=selected.origin.copy(x=selected.origin.x+100),revision=selected.revision+1)))}){Text("100 →")}
                OutlinedButton(onClick={commit(model.replaceElement(selected.copy(origin=selected.origin.copy(z=selected.origin.z-100),revision=selected.revision+1)))}){Text("↑ 100")}
                OutlinedButton(onClick={commit(model.replaceElement(selected.copy(origin=selected.origin.copy(z=selected.origin.z+100),revision=selected.revision+1)))}){Text("↓ 100")}
            }
            Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){
                OutlinedButton(onClick={commit(model.replaceElement(selected.copy(yawDegrees=selected.yawDegrees-15.0,revision=selected.revision+1)))}){Text("Rotate −15°")}
                OutlinedButton(onClick={commit(model.replaceElement(selected.copy(yawDegrees=selected.yawDegrees+15.0,revision=selected.revision+1)))}){Text("Rotate +15°")}
            }
            OutlinedButton(onClick={val point=GridSnapEngine.snapToGrid(Vec2(selected.origin.x,selected.origin.z),500.0);commit(model.replaceElement(selected.copy(origin=selected.origin.copy(x=point.x,z=point.y),revision=selected.revision+1)))}){Text("Snap to 500 mm grid")}
            if(selected.type==ElementType.WALL){Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                OutlinedButton(onClick={val o=Opening(type=ElementType.DOOR,offsetMm=600.0,widthMm=900.0,heightMm=2100.0);runCatching{commit(model.replaceElement(selected.copy(openings=selected.openings+o,revision=selected.revision+1)))}.onFailure{saveState="Opening does not fit: ${it.message}"}}){Text("Add Door Opening")}
                OutlinedButton(onClick={val o=Opening(type=ElementType.WINDOW,offsetMm=1800.0,widthMm=1000.0,heightMm=1200.0,sillMm=900.0);runCatching{commit(model.replaceElement(selected.copy(openings=selected.openings+o,revision=selected.revision+1)))}.onFailure{saveState="Opening does not fit: ${it.message}"}}){Text("Add Window")}
            }}
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){
            Button(onClick={add(ElementType.WALL)}){Text("+ Wall")}
            OutlinedButton(onClick={showLibrary=true}){Text("Component Library")}
            OutlinedButton(onClick={add(ElementType.PILLAR)}){Text("Pillar")}
            OutlinedButton(onClick={add(ElementType.STAIR)}){Text("Stairs")}
            OutlinedButton(onClick={add(ElementType.GATE)}){Text("Gate")}
            OutlinedButton(onClick={add(ElementType.ARCH)}){Text("Arch")}
            OutlinedButton(onClick={add(ElementType.GLASS_RAILING)}){Text("Glass Rail")}
            OutlinedButton(onClick={add(ElementType.STEEL_RAILING)}){Text("Steel Rail")}
            OutlinedButton(onClick={if(history.canUndo)model=history.undo()}){Text("Undo")}
            OutlinedButton(onClick={if(history.canRedo)model=history.redo()}){Text("Redo")}
        }
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
            TextButton(onClick={backupExport.launch("AI_Architecture_Backup.json")}){Text("Backup")}
            TextButton(onClick={backupImport.launch(arrayOf("application/json"))}){Text("Restore")}
            TextButton(onClick={pdfExport.launch("AI_Architecture_Dimensions.pdf")}){Text("Dimensioned PDF")}
        }
        Text("Phase 1 foundation: editable parametric elements, wall openings, local Room autosave, undo/redo, JSON backup and dimension schedule. Advanced tools remain pending.",style=MaterialTheme.typography.labelSmall)
    }
    if(showLibrary) AlertDialog(onDismissRequest={showLibrary=false},title={Text("Architecture Component Library")},text={ComponentLibraryScreen{key->val floor=model.floors.firstOrNull{it.id==activeFloorId}?:model.floors.first();val component=ArchitecturalComponents.instantiate(key,floor.id,Vec3(0.0,0.0,0.0));commit(model.addElement(component));selectedId=component.id;lengthInput=component.size.length.value.toString();widthInput=component.size.width.value.toString();heightInput=component.size.height.value.toString();showLibrary=false}},confirmButton={TextButton(onClick={showLibrary=false}){Text("Close")}})
}

@Composable private fun PlanCanvas(model:BuildingModel,activeFloorId:String,selectedId:String?,onSelect:(String?)->Unit){
    Canvas(Modifier.fillMaxSize().background(Color(0xFFFCFCFD)).pointerInput(model){detectTapGestures{point->
        val scale=minOf(size.width/7000f,size.height/5000f).coerceAtLeast(0.01f)
        val modelPoint=PlanCanvasTransform(scale).toModelPoint(point.x,point.y);val hit=model.floors.firstOrNull{it.id==activeFloorId}?.elements.orEmpty().lastOrNull{e->e.containsPlanPoint(modelPoint)}
        onSelect(hit?.id)
    }}){
        val scale=minOf(size.width/7000f,size.height/5000f).coerceAtLeast(0.01f);val origin=Offset(30f,30f)
        for(i in 0..14)drawLine(Color(0xFFE8EBEF),Offset(origin.x+i*500*scale,origin.y),Offset(origin.x+i*500*scale,origin.y+5000*scale),1f)
        for(i in 0..10)drawLine(Color(0xFFE8EBEF),Offset(origin.x,origin.y+i*500*scale),Offset(origin.x+7000*scale,origin.y+i*500*scale),1f)
        model.floors.filter{it.id==activeFloorId}.forEach{floor->floor.elements.forEach{e->val left=origin.x+e.origin.x.toFloat()*scale;val top=origin.y+e.origin.z.toFloat()*scale;val width=e.size.length.value.toFloat()*scale;val depth=e.size.width.value.toFloat()*scale
            val elementColor=when(e.type){ElementType.WALL->Color(0xFF586575);ElementType.PILLAR->Color(0xFF9A7654);ElementType.STAIR->Color(0xFF4F8C83);ElementType.GATE->Color(0xFF8A6D3B);ElementType.ARCH->Color(0xFF9C805B);else->Color(0xFF6688AA)}
            rotate(e.yawDegrees.toFloat(),Offset(left+width/2,top+depth/2)) {
                drawRect(elementColor,Offset(left,top),androidx.compose.ui.geometry.Size(width.coerceAtLeast(5f),depth.coerceAtLeast(5f)))
                e.openings.forEach{o->drawRect(Color.White,Offset(left+o.offsetMm.toFloat()*scale,top),androidx.compose.ui.geometry.Size(o.widthMm.toFloat()*scale,depth.coerceAtLeast(5f)))}
                drawRect(if(e.id==selectedId)Color(0xFFFF8A00) else Color.Black.copy(alpha=.35f),Offset(left,top),androidx.compose.ui.geometry.Size(width.coerceAtLeast(5f),depth.coerceAtLeast(5f)),style=Stroke(if(e.id==selectedId)3f else 1f))
            }
            val lLabel=DimensionEngine.visibleLabel(DimensionAnnotation(e.id,"length",e.size.length.value,DimensionAxis.LENGTH,e.size.length.provenance))
            val wLabel=DimensionEngine.visibleLabel(DimensionAnnotation(e.id,"width",e.size.width.value,DimensionAxis.WIDTH,e.size.width.provenance))
            val hLabel=DimensionEngine.visibleLabel(DimensionAnnotation(e.id,"height",e.size.height.value,DimensionAxis.HEIGHT,e.size.height.provenance))
            drawContext.canvas.nativeCanvas.drawText("${e.type} L $lLabel W $wLabel H $hLabel",left,top-4f,android.graphics.Paint().apply{this.color=android.graphics.Color.DKGRAY;textSize=18f})
            e.openings.forEach{o->val estimated=if(o.provenance==com.aiarchitecture.app.core.units.DimensionProvenance.ESTIMATED) "Estimated " else "";drawContext.canvas.nativeCanvas.drawText("$estimated${o.type} ${o.widthMm.toInt()}×${o.heightMm.toInt()} mm",left+o.offsetMm.toFloat()*scale,top+depth+18f,android.graphics.Paint().apply{this.color=android.graphics.Color.DKGRAY;textSize=16f})}
        }}
    }
}
