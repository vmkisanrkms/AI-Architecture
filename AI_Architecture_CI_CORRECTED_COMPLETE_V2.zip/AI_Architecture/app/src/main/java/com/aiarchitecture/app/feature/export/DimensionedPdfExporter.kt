package com.aiarchitecture.app.feature.export

import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import com.aiarchitecture.app.core.geometry.BuildingModel
import com.aiarchitecture.app.core.units.DimensionMm
import com.aiarchitecture.app.core.units.DimensionProvenance
import java.io.ByteArrayOutputStream

/** Multi-page vector schedule generated directly from canonical dimensions. */
object DimensionedPdfExporter {
    fun render(model: BuildingModel): ByteArray {
        val document=PdfDocument();var pageNumber=0;var page= newPage(document,++pageNumber,model.name);var y=page.second
        val body=Paint(Paint.ANTI_ALIAS_FLAG).apply{textSize=10f;color=android.graphics.Color.DKGRAY}
        val heading=Paint(Paint.ANTI_ALIAS_FLAG).apply{textSize=13f;color=android.graphics.Color.BLACK;isFakeBoldText=true}
        val line=Paint(Paint.ANTI_ALIAS_FLAG).apply{strokeWidth=0.7f;color=android.graphics.Color.LTGRAY}
        model.floors.forEach{floor->
            if(y>790f){document.finishPage(page.first);page=newPage(document,++pageNumber,model.name);y=page.second}
            page.first.canvas.drawText("Floor: ${floor.name} | Elevation: ${floor.elevationMm} mm",36f,y,heading);y+=22f
            floor.elements.forEach{e->
                if(y>790f){document.finishPage(page.first);page=newPage(document,++pageNumber,model.name);y=page.second;page.first.canvas.drawText("Floor continued: ${floor.name}",36f,y,heading);y+=22f}
                val l=dimension(e.size.length);val w=dimension(e.size.width);val h=dimension(e.size.height)
                page.first.canvas.drawText("${e.type} | L $l mm × W $w mm × H $h mm",48f,y,body)
                page.first.canvas.drawLine(48f,y+5f,555f,y+5f,line);y+=18f
                e.openings.forEach{o->
                    if(y>790f){document.finishPage(page.first);page=newPage(document,++pageNumber,model.name);y=page.second}
                    val estimated=if(o.provenance==DimensionProvenance.ESTIMATED) "Estimated — " else ""
                    page.first.canvas.drawText("  $estimated${o.type} opening | offset ${o.offsetMm} mm | width ${o.widthMm} mm | height ${o.heightMm} mm | sill ${o.sillMm} mm",58f,y,body);y+=16f
                }
            }
            y+=12f
        }
        document.finishPage(page.first);val out=ByteArrayOutputStream();document.writeTo(out);document.close();return out.toByteArray()
    }
    private fun dimension(d:DimensionMm):String=if(d.provenance==DimensionProvenance.ESTIMATED) "${d.value} (Estimated)" else d.value.toString()
    private fun newPage(doc:PdfDocument,number:Int,project:String):Pair<PdfDocument.Page,Float>{
        val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,number).create());val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{textSize=19f;color=android.graphics.Color.BLACK;isFakeBoldText=true};val small=Paint(Paint.ANTI_ALIAS_FLAG).apply{textSize=9f;color=android.graphics.Color.DKGRAY}
        page.canvas.drawText("AI Architecture — Dimensioned Drawing Schedule",36f,38f,p);page.canvas.drawText("Project: $project | Page $number | Canonical unit: mm",36f,58f,small);page.canvas.drawText("Dimensions are sourced from the editable model; Estimated values are labelled.",36f,73f,small)
        return page to 100f
    }
}
