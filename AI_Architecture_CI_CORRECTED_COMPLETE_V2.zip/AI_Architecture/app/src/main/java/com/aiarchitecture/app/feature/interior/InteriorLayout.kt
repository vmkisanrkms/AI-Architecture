package com.aiarchitecture.app.feature.interior

import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm

object InteriorLayout {
    fun furniture(floorId:String,origin:Vec3,lengthMm:Double,widthMm:Double,heightMm:Double)=BuildingElement(floorId=floorId,type=ElementType.FURNITURE,origin=origin,size=Size3(DimensionMm(lengthMm),DimensionMm(widthMm),DimensionMm(heightMm)),material="Furniture")
}
