package com.aiarchitecture.app.feature.kitchen

import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm

object KitchenLayout {
    fun cabinet(floorId:String,origin:Vec3,lengthMm:Double=600.0,depthMm:Double=600.0,heightMm:Double=900.0)=BuildingElement(floorId=floorId,type=ElementType.KITCHEN_CABINET,origin=origin,size=Size3(DimensionMm(lengthMm),DimensionMm(depthMm),DimensionMm(heightMm)),material="Cabinet")
    fun countertop(floorId:String,origin:Vec3,lengthMm:Double,depthMm:Double,thicknessMm:Double=40.0)=BuildingElement(floorId=floorId,type=ElementType.COUNTERTOP,origin=origin,size=Size3(DimensionMm(lengthMm),DimensionMm(depthMm),DimensionMm(thicknessMm)),material="Stone")
}
