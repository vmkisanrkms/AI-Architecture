package com.aiarchitecture.app.feature.language

enum class LanguageChoice(val tag:String){HINDI("hi"),ENGLISH("en")}
object LanguageSettings { fun parse(tag:String)=LanguageChoice.values().firstOrNull{it.tag==tag}?:LanguageChoice.HINDI }
