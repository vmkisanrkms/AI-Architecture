package com.aiarchitecture.app.feature.offline

import java.io.File
import java.security.MessageDigest

data class LocalModelInfo(val file:File,val expectedSha256:String,val requiredAbi:String="arm64-v8a")
object OfflineModelManager {
    fun validate(info:LocalModelInfo,deviceAbi:String,minimumFreeBytes:Long):List<String> = buildList {
        if(!info.file.isFile) add("Model file is missing")
        if(deviceAbi!=info.requiredAbi) add("Unsupported CPU ABI: $deviceAbi")
        if(info.file.isFile&&info.file.length()<8) add("Model file is too small")
        if(info.file.isFile&&info.file.length()>=4){val header=info.file.inputStream().use{ByteArray(4).also{b->it.read(b)}};if(!header.contentEquals("GGUF".toByteArray()))add("Model is not a GGUF file")}
        if(info.file.parentFile?.usableSpace?.let{it<minimumFreeBytes}==true)add("Insufficient free storage")
        if(info.file.isFile&&info.expectedSha256.isNotBlank()&&sha256(info.file)!=info.expectedSha256.lowercase())add("Model checksum mismatch")
    }
    private fun sha256(file:File):String{val digest=MessageDigest.getInstance("SHA-256");file.inputStream().use{input->val b=ByteArray(64*1024);while(true){val n=input.read(b);if(n<0)break;digest.update(b,0,n)}};return digest.digest().joinToString(""){"%02x".format(it)}}
}
