package com.aiarchitecture.app.feature.photo

import android.net.Uri

 data class PhotoUploadConsent(val userAccepted:Boolean,val purpose:String,val acceptedAtEpochMs:Long?)
object PhotoConsentPolicy {
    fun validate(uri:Uri,mimeType:String?,byteCount:Long,consent:PhotoUploadConsent){
        require(consent.userAccepted&&consent.acceptedAtEpochMs!=null){"Explicit photo upload consent is required"}
        require(consent.purpose.isNotBlank())
        require(mimeType in setOf("image/jpeg","image/png","image/webp")){"Unsupported image type"}
        require(byteCount in 1..(20L*1024*1024)){"Image must be between 1 byte and 20 MB"}
        require(uri.scheme=="content"||uri.scheme=="file")
    }
}
