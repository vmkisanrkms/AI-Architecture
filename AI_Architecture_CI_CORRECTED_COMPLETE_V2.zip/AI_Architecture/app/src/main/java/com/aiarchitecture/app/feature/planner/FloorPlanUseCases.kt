package com.aiarchitecture.app.feature.planner

import com.aiarchitecture.app.core.geometry.*
import kotlin.math.hypot
import kotlin.math.round

object FloorPlanUseCases {
    fun snap(valueMm:Double,gridMm:Double):Double { require(gridMm>0); return round(valueMm/gridMm)*gridMm }
    fun distanceMm(a:Vec2,b:Vec2):Double=hypot(b.x-a.x,b.y-a.y)
    fun move(element:BuildingElement,dxMm:Double,dzMm:Double)=element.copy(origin=element.origin.copy(x=element.origin.x+dxMm,z=element.origin.z+dzMm),revision=element.revision+1)
    fun resizeLength(element:BuildingElement,lengthMm:Double):BuildingElement { require(lengthMm>0);return element.copy(size=element.size.copy(length=com.aiarchitecture.app.core.units.DimensionMm(lengthMm)),revision=element.revision+1) }
}
