package com.aiarchitecture.app.feature.projects

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.aiarchitecture.app.data.local.ProjectEntity
import com.aiarchitecture.app.data.repository.ProjectRepository
import kotlinx.coroutines.launch

@Composable
fun ProjectsScreen(repository: ProjectRepository, onOpen: (String) -> Unit) {
    val projects by repository.observeProjects().collectAsState(initial = emptyList())
    var name by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var pendingDelete by remember { mutableStateOf<ProjectEntity?>(null) }
    val scope = rememberCoroutineScope()
    val visibleProjects = remember(projects, query) { projects.filter { it.name.contains(query.trim(), ignoreCase = true) } }

    Column(Modifier.fillMaxSize().padding(16.dp).testTag("destination-projects-gallery"), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("My Architecture Projects", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(value = name, onValueChange = { name = it; error = null }, label = { Text("New project name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = {
            scope.launch {
                runCatching { repository.createProject(name) }
                    .onSuccess { id -> name = ""; error = null; onOpen(id) }
                    .onFailure { error = it.message ?: "Could not create project" }
            }
        }, enabled = name.isNotBlank()) { Text("Create Project") }
        OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search projects") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (visibleProjects.isEmpty()) Text(if (query.isBlank()) "No projects yet. Create your first project." else "No matching projects.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(visibleProjects, key = { it.id }) { project ->
                ProjectRow(
                    project = project,
                    onOpen = { onOpen(project.id) },
                    onRename = { newName -> scope.launch { runCatching { repository.renameProject(project.id, newName) }.onFailure { error = it.message } } },
                    onDuplicate = { scope.launch { runCatching { repository.duplicateProject(project.id) }.onSuccess(onOpen).onFailure { error = it.message } } },
                    onDelete = { pendingDelete = project }
                )
            }
        }
    }
    pendingDelete?.let { project ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete project?") },
            text = { Text("${project.name} and its local floors, elements and edit history will be deleted.") },
            confirmButton = { TextButton(onClick = { pendingDelete = null; scope.launch { repository.deleteProject(project.id) } }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ProjectRow(project: ProjectEntity, onOpen: () -> Unit, onRename: (String) -> Unit, onDuplicate: () -> Unit, onDelete: () -> Unit) {
    var editing by remember(project.name) { mutableStateOf(false) }
    var name by remember(project.name) { mutableStateOf(project.name) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (editing) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Rename project") }, singleLine = true)
                Row {
                    TextButton(onClick = { onRename(name); editing = false }, enabled = name.isNotBlank()) { Text("Save") }
                    TextButton(onClick = { name = project.name; editing = false }) { Text("Cancel") }
                }
            } else Text(project.name, style = MaterialTheme.typography.titleMedium)
            Text("Updated ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(project.updatedAt))}", style = MaterialTheme.typography.labelSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                TextButton(onClick = onOpen) { Text("Open") }
                TextButton(onClick = { editing = true }) { Text("Rename") }
                TextButton(onClick = onDuplicate) { Text("Duplicate") }
                TextButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}
