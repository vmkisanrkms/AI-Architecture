package com.aiarchitecture.app.feature.renderer

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import com.aiarchitecture.app.core.geometry.BuildingModel
import com.aiarchitecture.app.core.geometry.MeshBuilder
import com.aiarchitecture.app.core.geometry.MeshData
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Real OpenGL ES scene renderer. Geometry is rebuilt from editable model data, never a bitmap. */
class Building3DView(context:Context, initial:BuildingModel):GLSurfaceView(context){
    private val scene=BuildingRenderer(initial)
    private var lastX=0f; private var lastY=0f
    private val scaleDetector=ScaleGestureDetector(context,object:ScaleGestureDetector.SimpleOnScaleGestureListener(){override fun onScale(detector:ScaleGestureDetector):Boolean{scene.zoom(detector.scaleFactor);requestRender();return true}})
    init { setEGLContextClientVersion(2); setRenderer(scene); renderMode=RENDERMODE_WHEN_DIRTY }
    fun updateModel(model:BuildingModel){ scene.update(model); requestRender() }
    fun setCameraPreset(name:String){scene.setPreset(name);requestRender()}
    fun setOrthographic(enabled:Boolean){scene.setOrthographic(enabled);requestRender()}
    override fun onTouchEvent(event:MotionEvent):Boolean {
        scaleDetector.onTouchEvent(event)
        when(event.action){ MotionEvent.ACTION_DOWN->{lastX=event.x;lastY=event.y;return true}; MotionEvent.ACTION_MOVE->{val dx=event.x-lastX;val dy=event.y-lastY;if(event.pointerCount>=2)scene.pan(dx,dy) else if(!scaleDetector.isInProgress)scene.rotate(dx,dy);lastX=event.x;lastY=event.y;requestRender();return true} }
        return true
    }
}
private class BuildingRenderer(model:BuildingModel):GLSurfaceView.Renderer{
    @Volatile private var mesh:MeshData=MeshBuilder.build(model)
    private var vertexBuffer:FloatBuffer?=null; private var colorBuffer:FloatBuffer?=null
    private var program=0; private var count=0; @Volatile private var meshDirty=true; private var angleX=25f; private var angleY=-35f; private var distance=6.0f; private var panX=0f; private var panY=0f; private var orthographic=false; private var aspect=1f
    private val projection=FloatArray(16); private val view=FloatArray(16); private val modelMatrix=FloatArray(16); private val mvp=FloatArray(16)
    fun update(model:BuildingModel){mesh=MeshBuilder.build(model);meshDirty=true}
    fun rotate(dx:Float,dy:Float){angleY+=dx*0.6f;angleX=(angleX+dy*0.6f).coerceIn(-89f,89f)}
    fun zoom(factor:Float){if(factor.isFinite()&&factor>0f)distance=(distance/factor).coerceIn(2.0f,30.0f)}
    fun pan(dx:Float,dy:Float){panX-=dx*0.004f;panY+=dy*0.004f}
    fun setOrthographic(enabled:Boolean){orthographic=enabled;updateProjection()}
    fun setPreset(name:String){when(name.lowercase()){ "front"->{angleX=0f;angleY=0f};"back"->{angleX=0f;angleY=180f};"left"->{angleX=0f;angleY=90f};"right"->{angleX=0f;angleY=-90f};"top"->{angleX=88f;angleY=0f};else->{angleX=30f;angleY=-45f}}}
    override fun onSurfaceCreated(gl:GL10?,config:EGLConfig?){ GLES20.glClearColor(0.94f,0.95f,0.97f,1f);GLES20.glEnable(GLES20.GL_DEPTH_TEST);program=linkProgram(VS,FS);upload() }
    override fun onSurfaceChanged(gl:GL10?,width:Int,height:Int){GLES20.glViewport(0,0,width,height);aspect=width.toFloat()/height.coerceAtLeast(1);updateProjection()}
    private fun updateProjection(){if(orthographic)Matrix.orthoM(projection,0,-5f*aspect,5f*aspect,-5f,5f,0.1f,200f)else Matrix.perspectiveM(projection,0,45f,aspect,0.1f,200f)}
    override fun onDrawFrame(gl:GL10?){GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT);if(vertexBuffer==null || meshDirty){upload();meshDirty=false};val p=program;GLES20.glUseProgram(p)
        Matrix.setLookAtM(view,0,panX,2.4f+panY,distance,panX,0.8f+panY,0f,0f,1f,0f);Matrix.setIdentityM(modelMatrix,0);Matrix.translateM(modelMatrix,0,-2f,-1f,-0.5f);Matrix.rotateM(modelMatrix,0,angleX,1f,0f,0f);Matrix.rotateM(modelMatrix,0,angleY,0f,1f,0f);Matrix.multiplyMM(mvp,0,view,0,modelMatrix,0);Matrix.multiplyMM(mvp,0,projection,0,mvp,0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(p,"uMvp"),1,false,mvp,0)
        val pos=GLES20.glGetAttribLocation(p,"aPosition");val col=GLES20.glGetAttribLocation(p,"aColor")
        vertexBuffer?.position(0);GLES20.glEnableVertexAttribArray(pos);GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,0,vertexBuffer)
        colorBuffer?.position(0);GLES20.glEnableVertexAttribArray(col);GLES20.glVertexAttribPointer(col,4,GLES20.GL_FLOAT,false,0,colorBuffer)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,count);GLES20.glDisableVertexAttribArray(pos);GLES20.glDisableVertexAttribArray(col)
    }
    private fun upload(){val data=mesh;count=data.vertexCount;vertexBuffer=ByteBuffer.allocateDirect(data.vertices.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply{put(data.vertices);position(0)};colorBuffer=ByteBuffer.allocateDirect(data.colors.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply{put(data.colors);position(0)}}
    private fun compile(type:Int,source:String):Int{val s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,source);GLES20.glCompileShader(s);val ok=IntArray(1);GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,ok,0);check(ok[0]==GLES20.GL_TRUE){GLES20.glGetShaderInfoLog(s)};return s}
    private fun linkProgram(v:String,f:String):Int{val p=GLES20.glCreateProgram();GLES20.glAttachShader(p,compile(GLES20.GL_VERTEX_SHADER,v));GLES20.glAttachShader(p,compile(GLES20.GL_FRAGMENT_SHADER,f));GLES20.glLinkProgram(p);val ok=IntArray(1);GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,ok,0);check(ok[0]==GLES20.GL_TRUE){GLES20.glGetProgramInfoLog(p)};return p}
    companion object {private const val VS="attribute vec4 aPosition; attribute vec4 aColor; uniform mat4 uMvp; varying vec4 vColor; void main(){gl_Position=uMvp*aPosition;vColor=aColor;}";private const val FS="precision mediump float; varying vec4 vColor; void main(){gl_FragColor=vColor;}"}
}
