package com.aiarchitecture.app.feature.settings

enum class AppThemeMode { LIGHT, DARK, SYSTEM }
enum class AppLanguage { HINDI, ENGLISH }
data class AppSettings(val theme:AppThemeMode=AppThemeMode.SYSTEM,val language:AppLanguage=AppLanguage.HINDI,val displayUnit:String="mm",val decimalPlaces:Int=1,val gridSpacingMm:Double=100.0,val autosaveEnabled:Boolean=true){init{require(displayUnit in setOf("mm","m","in","ft"));require(decimalPlaces in 0..4);require(gridSpacingMm>0)}}
