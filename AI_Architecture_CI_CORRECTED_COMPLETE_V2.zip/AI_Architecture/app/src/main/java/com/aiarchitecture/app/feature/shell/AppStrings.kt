package com.aiarchitecture.app.feature.shell

import android.content.Context

object AppStrings {
    private const val PREFS = "ai_architecture_preferences"
    fun hasSavedLanguage(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains("language")
    fun coldStartDestination(context: Context): String = if (hasSavedLanguage(context)) "home" else "splash"
    fun language(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("language", "hi") ?: "hi"
    fun setLanguage(context: Context, tag: String) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("language", if (tag == "en") "en" else "hi").apply() }
    fun isDark(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("dark_theme", false)
    fun setDark(context: Context, value: Boolean) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("dark_theme", value).apply() }
    fun title(screen: AppScreen, language: String) = if (language == "en") screen.titleEn else screen.titleHi
    fun description(screen: AppScreen, language: String) = if (language == "en") screen.descriptionEn else screen.descriptionHi
    fun text(language: String, en: String, hi: String) = if (language == "en") en else hi
}
