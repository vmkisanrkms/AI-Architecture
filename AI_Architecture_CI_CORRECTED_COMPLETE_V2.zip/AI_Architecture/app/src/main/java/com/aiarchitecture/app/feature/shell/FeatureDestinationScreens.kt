package com.aiarchitecture.app.feature.shell

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.room.Room
import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm
import com.aiarchitecture.app.data.local.AppDatabase
import com.aiarchitecture.app.data.repository.BuildingModelStore
import com.aiarchitecture.app.feature.ai.DesignBrief
import com.aiarchitecture.app.feature.ai.DesignBriefValidator
import com.aiarchitecture.app.feature.calculator.MaterialCalculations
import com.aiarchitecture.app.feature.components.ComponentLibraryScreen
import com.aiarchitecture.app.feature.components.ArchitecturalComponents
import com.aiarchitecture.app.feature.offline.LocalModelInfo
import com.aiarchitecture.app.feature.offline.OfflineModelManager
import com.aiarchitecture.app.feature.photo.PhotoConsentPolicy
import com.aiarchitecture.app.feature.photo.PhotoUploadConsent
import com.aiarchitecture.app.feature.renderer.Building3DView
import java.io.File

private fun routeTag(route: String) = "destination-$route"

@Composable
fun AiDesignGeneratorDestination() {
    var type by remember { mutableStateOf("House") }
    var length by remember { mutableStateOf("12000") }
    var width by remember { mutableStateOf("9000") }
    var floors by remember { mutableStateOf("1") }
    var rooms by remember { mutableStateOf("3") }
    var notes by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Enter a brief. No AI output is fabricated without a configured provider.") }
    Column(Modifier.fillMaxSize().padding(16.dp).testTag(routeTag("ai-generator")), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("AI Design Generator", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(type, { type = it }, label = { Text("Building type") })
        OutlinedTextField(length, { length = it }, label = { Text("Plot length (mm)") })
        OutlinedTextField(width, { width = it }, label = { Text("Plot width (mm)") })
        OutlinedTextField(floors, { floors = it }, label = { Text("Floors") })
        OutlinedTextField(rooms, { rooms = it }, label = { Text("Rooms") })
        OutlinedTextField(notes, { notes = it }, label = { Text("Requirements") })
        Button(onClick = {
            val brief = DesignBrief(type, length.toDoubleOrNull(), width.toDoubleOrNull(), floors.toIntOrNull() ?: 0, rooms.toIntOrNull() ?: -1, "User defined", notes)
            val errors = DesignBriefValidator.validate(brief)
            status = if (errors.isEmpty()) "Brief validated. Connect a real AI provider to generate a design." else errors.joinToString()
        }) { Text("Validate Design Brief") }
        Text(status)
    }
}

@Composable
fun PhotoAnalysisDestination() {
    val context = LocalContext.current
    var consent by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<android.net.Uri?>(null) }
    var status by remember { mutableStateOf("Select a photo only after granting consent. No upload is performed here.") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { selected = it; status = if (it == null) "No photo selected" else "Photo selected locally; upload requires a separately configured provider." }
    Column(Modifier.fillMaxSize().padding(16.dp).testTag(routeTag("photo-analysis")), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Photo Upload and Analysis", style = MaterialTheme.typography.headlineSmall)
        Row { Checkbox(consent, { consent = it }); Text("I consent to local photo selection for design analysis") }
        Button(onClick = { if (consent) picker.launch("image/*") else status = "Explicit consent is required" }) { Text("Choose Photo") }
        selected?.let { uri ->
            Button(onClick = {
                runCatching {
                    val mime = context.contentResolver.getType(uri)
                    val size = context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
                    PhotoConsentPolicy.validate(uri, mime, size, PhotoUploadConsent(true, "design analysis", System.currentTimeMillis()))
                }.onSuccess { status = "Photo consent and file validation passed. No network upload was started." }
                    .onFailure { status = "Photo validation failed: ${it.message}" }
            }) { Text("Validate Selected Photo") }
        }
        Text(status)
    }
}

@Composable
fun FloorPlannerDestination(onProjects: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp).testTag(routeTag("floor-planner")), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("House Floor Planner", style = MaterialTheme.typography.headlineSmall)
        Text("Create or open a locally stored project before adding floors and editing the shared building model.")
        Button(onClick = onProjects) { Text("Open / Create Project") }
    }
}

@Composable
fun ThreeDDesignerDestination() {
    val context = LocalContext.current
    val db = remember { Room.databaseBuilder(context, AppDatabase::class.java, "ai_architecture.db").build() }
    val store = remember { BuildingModelStore(db) }
    var model by remember { mutableStateOf(BuildingModel.starter()) }
    var view by remember { mutableStateOf<Building3DView?>(null) }
    LaunchedEffect(Unit) { model = runCatching { store.loadLatest() }.getOrNull() ?: BuildingModel.starter() }
    Column(Modifier.fillMaxSize().padding(12.dp).testTag(routeTag("3d-designer")), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("3D House Designer", style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("Front", "Back", "Left", "Right", "Top", "Iso").forEach { preset ->
                TextButton(onClick = { view?.setCameraPreset(preset) }) { Text(preset) }
            }
        }
        AndroidView(
            factory = { ctx -> Building3DView(ctx, model).also { view = it } },
            update = { it.updateModel(model) },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
        Text("Live OpenGL geometry from the shared Room-backed model. Drag to orbit; pinch to zoom.")
    }
}

@Composable
private fun ParametricComponentDestination(route: String, title: String, elementType: ElementType) {
    val context = LocalContext.current
    val db = remember { Room.databaseBuilder(context, AppDatabase::class.java, "ai_architecture.db").build() }
    val store = remember { BuildingModelStore(db) }
    var length by remember { mutableStateOf("3000") }
    var width by remember { mutableStateOf("150") }
    var height by remember { mutableStateOf("2400") }
    var status by remember { mutableStateOf("Dimensions are in millimetres. Save inserts real editable geometry into the current project.") }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp).testTag(routeTag(route)), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(length, { length = it }, label = { Text("Length (mm)") })
        OutlinedTextField(width, { width = it }, label = { Text("Width / thickness (mm)") })
        OutlinedTextField(height, { height = it }, label = { Text("Height (mm)") })
        Button(onClick = {
            val l = length.toDoubleOrNull(); val w = width.toDoubleOrNull(); val h = height.toDoubleOrNull()
            if (l == null || w == null || h == null || l <= 0 || w <= 0 || h <= 0) status = "All three dimensions must be positive numbers."
            else {
                status = "Saving editable geometry…"
                scope.launch {
                    runCatching {
                        val current = store.loadLatest() ?: BuildingModel.starter()
                        val floor = current.floors.firstOrNull() ?: error("Project has no floor")
                        val item = BuildingElement(
                            floorId = floor.id, type = elementType, origin = Vec3(0.0, 0.0, 0.0),
                            size = Size3(DimensionMm(l), DimensionMm(w), DimensionMm(h))
                        )
                        store.save(current.addElement(item))
                    }.onSuccess { status = "Saved as editable ${elementType.name} geometry in the local project." }
                        .onFailure { status = "Could not save geometry: ${it.message}" }
                }
            }
        }) { Text("Add to Current Project") }
        Text(status)
    }
}

@Composable fun GateDesignerDestination() = ParametricComponentDestination("gate-designer", "Gate Designer", ElementType.GATE)
@Composable fun ArchDesignerDestination() = ParametricComponentDestination("arch-designer", "Arch Designer", ElementType.ARCH)
@Composable fun InteriorDesignerDestination() = ParametricComponentDestination("interior-designer", "Interior Designer", ElementType.FURNITURE)
@Composable fun KitchenDesignerDestination() = ParametricComponentDestination("kitchen-designer", "Kitchen Designer", ElementType.KITCHEN_CABINET)
@Composable fun BathroomDesignerDestination() = ParametricComponentDestination("bathroom-designer", "Bathroom Designer", ElementType.SINK)
@Composable fun BoundaryWallDestination() = ParametricComponentDestination("boundary-wall", "Boundary Wall Designer", ElementType.WALL)

@Composable
fun MaterialCalculatorDestination() {
    var length by remember { mutableStateOf("4000") }
    var height by remember { mutableStateOf("2800") }
    var thickness by remember { mutableStateOf("150") }
    var result by remember { mutableStateOf("Enter wall dimensions to calculate masonry volume and brick estimate.") }
    Column(Modifier.fillMaxSize().padding(16.dp).testTag(routeTag("material-calculator")), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Material Calculator", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(length, { length = it }, label = { Text("Wall length (mm)") })
        OutlinedTextField(height, { height = it }, label = { Text("Wall height (mm)") })
        OutlinedTextField(thickness, { thickness = it }, label = { Text("Wall thickness (mm)") })
        Button(onClick = {
            val l = length.toDoubleOrNull(); val h = height.toDoubleOrNull(); val t = thickness.toDoubleOrNull()
            result = if (l != null && h != null && t != null && l > 0 && h > 0 && t > 0) {
                val volume = MaterialCalculations.wallVolume(l, h, t)
                val bricks = MaterialCalculations.bricks(volume)
                "Masonry volume: %.3f m³ • Estimated bricks: %d".format(volume, bricks.quantity.toLong())
            } else "Enter positive numeric dimensions."
        }) { Text("Calculate") }
        Text(result)
    }
}

@Composable
fun OfflineModelManagerDestination() {
    val context = LocalContext.current
    var status by remember { mutableStateOf("Choose a local GGUF model file to validate. No download or inference is started.") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val target = File(context.filesDir, "offline-model.gguf")
            requireNotNull(context.contentResolver.openInputStream(uri)).use { input -> target.outputStream().use { input.copyTo(it) } }
            val problems = OfflineModelManager.validate(LocalModelInfo(target, ""), android.os.Build.SUPPORTED_ABIS.firstOrNull().orEmpty(), 0)
            require(problems.isEmpty()) { problems.joinToString() }
        }.onSuccess { status = "Local GGUF file format and device ABI checks passed." }
            .onFailure { status = "Model validation failed: ${it.message}" }
    }
    Column(Modifier.fillMaxSize().padding(16.dp).testTag(routeTag("offline-model-manager")), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Offline AI Model Manager", style = MaterialTheme.typography.headlineSmall)
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Select Local GGUF Model") }
        Text(status)
        Text("Inference remains unavailable until a compatible licensed runtime is configured.")
    }
}

@Composable
fun ComponentLibraryDestination(onEditor: () -> Unit = {}) {
    val context = LocalContext.current
    val db = remember { Room.databaseBuilder(context, AppDatabase::class.java, "ai_architecture.db").build() }
    val store = remember { BuildingModelStore(db) }
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("Choose a component to insert into the current editable model.") }
    Column(Modifier.fillMaxSize().padding(12.dp).testTag(routeTag("component-library")), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Architecture Component Library", style = MaterialTheme.typography.headlineSmall)
        Text(status)
        ComponentLibraryScreen(onInsert = { key ->
            scope.launch {
                runCatching {
                    val model = store.loadLatest() ?: BuildingModel.starter()
                    val floor = model.floors.firstOrNull() ?: error("Project has no floor")
                    val component = ArchitecturalComponents.instantiate(key, floor.id, Vec3(0.0, 0.0, 0.0))
                    store.save(model.addElement(component))
                }.onSuccess { status = "Inserted $key as editable geometry."; onEditor() }
                    .onFailure { status = "Insert failed: ${it.message}" }
            }
        })
    }
}
