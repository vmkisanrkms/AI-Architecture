package com.aiarchitecture.app.feature.shell

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.testTag
import kotlin.math.ceil

@Composable
fun SplashScreen(language: String, onContinue: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp).testTag("destination-splash"), verticalArrangement = Arrangement.Center) {
        Text("AI Architecture", style = MaterialTheme.typography.headlineLarge)
        Text(AppStrings.text(language, "Design with exact dimensions. Build with editable geometry.", "सही माप के साथ डिज़ाइन करें। संपादन योग्य ज्योमेट्री बनाएं।"))
        Spacer(Modifier.height(24.dp))
        Button(onClick = onContinue) { Text(AppStrings.text(language, "Continue", "आगे बढ़ें")) }
    }
}

@Composable
fun LanguageScreen(current: String, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp).testTag("destination-language"), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("भाषा / Language", style = MaterialTheme.typography.headlineSmall)
        Button(onClick = { onSelect("hi") }, modifier = Modifier.fillMaxWidth()) { Text("हिंदी") }
        OutlinedButton(onClick = { onSelect("en") }, modifier = Modifier.fillMaxWidth()) { Text("English") }
        Text(if (current == "hi") "वर्तमान भाषा: हिंदी" else "Current language: English")
    }
}

@Composable
fun HomeDashboard(language: String, onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp).testTag("destination-home"), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("AI Architecture", style = MaterialTheme.typography.headlineMedium)
        Text(AppStrings.text(language, "Native architectural design workspace", "आर्किटेक्चर डिज़ाइन वर्कस्पेस"))
        ScreenCatalog.all.filter { it.id !in listOf(1, 2, 3) }.forEach { screen ->
            Card(onClick = { onOpen(screen.route) }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text("${screen.id}. ${AppStrings.title(screen, language)}", style = MaterialTheme.typography.titleMedium)
                    Text(AppStrings.description(screen, language), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun ModuleWorkspaceScreen(screen: AppScreen, language: String, onEditor: () -> Unit, onProjects: () -> Unit, onPdf: () -> Unit, onBackup: () -> Unit, onComponents: () -> Unit, onSettings: () -> Unit) {
    var first by remember(screen.route) { mutableStateOf("") }
    var second by remember(screen.route) { mutableStateOf("") }
    var third by remember(screen.route) { mutableStateOf("") }
    var result by remember(screen.route) { mutableStateOf<String?>(null) }
    val en = language == "en"
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(AppStrings.title(screen, language), style = MaterialTheme.typography.headlineSmall)
        Text(AppStrings.description(screen, language))
        when (screen.route) {
            "ai-generator" -> {
                OutlinedTextField(first, { first = it }, label = { Text(if (en) "Building type" else "भवन का प्रकार") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(second, { second = it }, label = { Text(if (en) "Rooms / requirements" else "कमरे / आवश्यकताएं") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(third, { third = it }, label = { Text(if (en) "Style and notes" else "शैली और जानकारी") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { result = if (first.isBlank()) (if (en) "Enter a building type first." else "पहले भवन का प्रकार लिखें।") else (if (en) "Design brief saved in this session. No AI result is fabricated." else "डिज़ाइन विवरण इस सत्र में तैयार है। कोई नकली AI परिणाम नहीं दिखाया गया।") }) { Text(if (en) "Validate brief" else "विवरण जाँचें") }
            }
            "photo-analysis" -> {
                Text(if (en) "Photos are not sent anywhere from this screen. Select an image only after explicit consent and a configured provider are available." else "इस स्क्रीन से फोटो कहीं नहीं भेजी जाती। स्पष्ट अनुमति और कॉन्फ़िगर प्रदाता उपलब्ध होने पर ही फोटो चुनें।")
                var consent by remember { mutableStateOf(false) }
                Row { Checkbox(checked = consent, onCheckedChange = { consent = it }); Text(if (en) "I consent to processing after provider setup" else "प्रदाता सेटअप के बाद प्रोसेसिंग की अनुमति देता/देती हूँ") }
                Button(onClick = { result = if (consent) (if (en) "Consent recorded for this session; upload is not started." else "इस सत्र के लिए अनुमति दर्ज है; अपलोड शुरू नहीं हुआ।") else (if (en) "Consent is required." else "अनुमति आवश्यक है।") }) { Text(if (en) "Confirm consent" else "अनुमति की पुष्टि") }
            }
            "gate-designer", "arch-designer", "interior-designer", "kitchen-designer", "bathroom-designer", "boundary-wall" -> {
                OutlinedTextField(first, { first = it }, label = { Text(if (en) "Length (mm)" else "लंबाई (mm)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(second, { second = it }, label = { Text(if (en) "Width / thickness (mm)" else "चौड़ाई / मोटाई (mm)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(third, { third = it }, label = { Text(if (en) "Height (mm)" else "ऊंचाई (mm)") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val l = first.toDoubleOrNull(); val w = second.toDoubleOrNull(); val h = third.toDoubleOrNull()
                    result = if (l != null && w != null && h != null && l > 0 && w > 0 && h > 0) "${l} × ${w} × ${h} mm — ${if (en) "valid dimension specification" else "माप सही है"}" else if (en) "Enter three positive dimensions in millimetres." else "तीनों माप mm में शून्य से अधिक दर्ज करें।"
                }) { Text(if (en) "Validate dimensions" else "माप जाँचें") }
            }
            "material-calculator" -> {
                OutlinedTextField(first, { first = it }, label = { Text(if (en) "Length (m)" else "लंबाई (मीटर)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(second, { second = it }, label = { Text(if (en) "Width (m)" else "चौड़ाई (मीटर)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(third, { third = it }, label = { Text(if (en) "Thickness (mm)" else "मोटाई (mm)") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { val l=first.toDoubleOrNull(); val w=second.toDoubleOrNull(); val t=third.toDoubleOrNull(); result=if(l!=null&&w!=null&&t!=null&&l>0&&w>0&&t>0) "${"%.3f".format(l*w*t/1000.0)} m³" else if(en) "Enter positive numeric values." else "सही धनात्मक माप दर्ज करें।" }) { Text(if (en) "Calculate volume" else "आयतन निकालें") }
            }
            "offline-model-manager" -> Text(if (en) "Local inference requires a compatible, licensed model file and device capability checks. No model is downloaded by this Phase 2 screen." else "लोकल AI चलाने के लिए संगत लाइसेंस वाला मॉडल और डिवाइस जाँच आवश्यक है। Phase 2 स्क्रीन कोई मॉडल डाउनलोड नहीं करती।")
            "settings" -> Text(if (en) "Use the language selector on the dashboard. Appearance preferences are stored on this device." else "डैशबोर्ड पर भाषा चुनें। डिस्प्ले प्राथमिकताएं इसी फोन में सेव होती हैं।")
            else -> Text(if (en) "Choose an action below to continue with the native project workflow." else "आगे बढ़ने के लिए नीचे दिए विकल्प चुनें।")
        }
        result?.let { Card(Modifier.fillMaxWidth()) { Text(it, Modifier.padding(12.dp)) } }
        when (screen.route) {
            "floor-planner", "projects-gallery" -> Button(onClick = onProjects, modifier = Modifier.fillMaxWidth()) { Text(if (en) "Open local projects" else "लोकल प्रोजेक्ट खोलें") }
            "blueprint-editor", "3d-designer" -> Button(onClick = onEditor, modifier = Modifier.fillMaxWidth()) { Text(if (en) "Open editable building editor" else "एडिटेबल बिल्डिंग एडिटर खोलें") }
            "pdf-reports" -> Button(onClick = onPdf, modifier = Modifier.fillMaxWidth()) { Text(if (en) "Export dimensioned PDF" else "माप सहित PDF बनाएं") }
            "backup-restore" -> Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Text(if (en) "Open editor backup tools" else "एडिटर बैकअप टूल खोलें") }
            "component-library" -> Button(onClick = onComponents, modifier = Modifier.fillMaxWidth()) { Text(if (en) "Open component library" else "कंपोनेंट लाइब्रेरी खोलें") }
            "settings" -> Button(onClick = onSettings, modifier = Modifier.fillMaxWidth()) { Text(if (en) "Open language and appearance" else "भाषा और डिस्प्ले सेटिंग खोलें") }
            else -> Unit
        }
    }
}

@Composable
fun SettingsScreen(language: String, onLanguage: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var dark by remember { mutableStateOf(AppStrings.isDark(context)) }
    Column(Modifier.fillMaxSize().padding(20.dp).testTag("destination-settings"), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(AppStrings.text(language, "Appearance and language", "डिस्प्ले और भाषा"), style = MaterialTheme.typography.headlineSmall)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(AppStrings.text(language, "Dark theme", "डार्क थीम"))
            Switch(checked = dark, onCheckedChange = { enabled ->
                dark = enabled
                AppStrings.setDark(context, enabled)
                (context as? android.app.Activity)?.recreate()
            })
        }
        Text(AppStrings.text(language, "Language", "भाषा"))
        OutlinedButton(onClick = onLanguage) { Text(AppStrings.text(language, "Change language", "भाषा बदलें")) }
        Text(AppStrings.text(language, "Project geometry and project records are stored locally in the Room database. This app does not request internet permission in this offline CAD build.", "प्रोजेक्ट की ज्योमेट्री और रिकॉर्ड फोन के लोकल Room डेटाबेस में सेव होते हैं। इस ऑफलाइन CAD बिल्ड में इंटरनेट अनुमति नहीं मांगी जाती।"), style = MaterialTheme.typography.bodySmall)
    }
}
