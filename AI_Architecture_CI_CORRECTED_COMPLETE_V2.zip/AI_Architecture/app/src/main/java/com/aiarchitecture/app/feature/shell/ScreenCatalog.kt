package com.aiarchitecture.app.feature.shell

data class AppScreen(val id: Int, val route: String, val titleEn: String, val titleHi: String, val descriptionEn: String, val descriptionHi: String)

enum class ScreenDestination {
    SPLASH, LANGUAGE, HOME, AI_GENERATOR, PHOTO_ANALYSIS, FLOOR_PLANNER, BLUEPRINT_EDITOR,
    THREE_D_DESIGNER, GATE_DESIGNER, ARCH_DESIGNER, INTERIOR_DESIGNER, KITCHEN_DESIGNER,
    BATHROOM_DESIGNER, BOUNDARY_WALL, MATERIAL_CALCULATOR, PROJECTS_GALLERY, PDF_EXPORT,
    SETTINGS, BACKUP_RESTORE, OFFLINE_MODEL_MANAGER, COMPONENT_LIBRARY
}

object ScreenCatalog {
    val all = listOf(
        AppScreen(1,"splash","Splash Screen","प्रारंभ स्क्रीन","Application entry and startup","ऐप का प्रारंभ और स्वागत"),
        AppScreen(2,"language","Language Selection","भाषा चुनें","Choose Hindi or English","हिंदी या अंग्रेज़ी चुनें"),
        AppScreen(3,"home","Home Dashboard","मुख्य डैशबोर्ड","Open architecture tools and projects","आर्किटेक्चर टूल और प्रोजेक्ट खोलें"),
        AppScreen(4,"ai-generator","AI Design Generator","AI डिज़ाइन जनरेटर","Prepare a validated design brief","डिज़ाइन की जानकारी तैयार करें"),
        AppScreen(5,"photo-analysis","Photo Upload and Analysis","फोटो अपलोड और विश्लेषण","Review photo consent and source","फोटो की अनुमति और स्रोत जाँचें"),
        AppScreen(6,"floor-planner","House Floor Planner","घर का फ्लोर प्लानर","Create a project and start a floor plan","प्रोजेक्ट बनाकर नक्शा शुरू करें"),
        AppScreen(7,"blueprint-editor","2D Blueprint Editor","2D नक्शा एडिटर","Draw and edit the canonical building model","नक्शा बनाएं और संपादित करें"),
        AppScreen(8,"3d-designer","3D House Designer","3D घर डिज़ाइनर","Inspect editable 3D geometry","संपादन योग्य 3D मॉडल देखें"),
        AppScreen(9,"gate-designer","Gate Designer","गेट डिज़ाइनर","Specify gate dimensions","गेट की माप दर्ज करें"),
        AppScreen(10,"arch-designer","Arch Designer","मेहराब डिज़ाइनर","Specify arch dimensions and profile","मेहराब की माप और आकार दर्ज करें"),
        AppScreen(11,"interior-designer","Interior Designer","इंटीरियर डिज़ाइनर","Plan interior spaces","कमरे का इंटीरियर प्लान करें"),
        AppScreen(12,"kitchen-designer","Kitchen Designer","किचन डिज़ाइनर","Plan kitchen dimensions and layout","रसोई की माप और लेआउट बनाएं"),
        AppScreen(13,"bathroom-designer","Bathroom Designer","बाथरूम डिज़ाइनर","Plan bathroom dimensions and fixtures","बाथरूम की माप और फिटिंग प्लान करें"),
        AppScreen(14,"boundary-wall","Boundary Wall Designer","बाउंड्री वॉल डिज़ाइनर","Specify boundary wall and pillars","बाउंड्री वॉल और पिलर की माप दर्ज करें"),
        AppScreen(15,"material-calculator","Material Calculator","मटेरियल कैलकुलेटर","Calculate construction quantities","निर्माण सामग्री की गणना करें"),
        AppScreen(16,"projects-gallery","My Projects and Gallery","मेरे प्रोजेक्ट और गैलरी","Manage locally stored projects","फोन में सेव प्रोजेक्ट संभालें"),
        AppScreen(17,"pdf-reports","PDF Export and Reports","PDF और रिपोर्ट","Export a dimensioned drawing report","माप सहित PDF रिपोर्ट बनाएं"),
        AppScreen(18,"settings","Settings","सेटिंग्स","Manage language and appearance","भाषा और डिस्प्ले सेट करें"),
        AppScreen(19,"backup-restore","Backup and Restore","बैकअप और रिस्टोर","Open local backup tools","लोकल बैकअप टूल खोलें"),
        AppScreen(20,"offline-model-manager","Offline AI Model Manager","ऑफलाइन AI मॉडल मैनेजर","Review local model requirements","लोकल मॉडल की जानकारी देखें"),
        AppScreen(21,"component-library","Architecture Component Library","आर्किटेक्चर कंपोनेंट लाइब्रेरी","Insert reusable architectural components","तैयार आर्किटेक्चर कंपोनेंट जोड़ें")
    )
    fun byRoute(route: String): AppScreen? = all.firstOrNull { it.route == route }

    /** Exhaustive, one-to-one route binding. A route can never silently fall through to a generic module. */
    fun destination(route: String): ScreenDestination? = when (route) {
        "splash" -> ScreenDestination.SPLASH
        "language" -> ScreenDestination.LANGUAGE
        "home" -> ScreenDestination.HOME
        "ai-generator" -> ScreenDestination.AI_GENERATOR
        "photo-analysis" -> ScreenDestination.PHOTO_ANALYSIS
        "floor-planner" -> ScreenDestination.FLOOR_PLANNER
        "blueprint-editor" -> ScreenDestination.BLUEPRINT_EDITOR
        "3d-designer" -> ScreenDestination.THREE_D_DESIGNER
        "gate-designer" -> ScreenDestination.GATE_DESIGNER
        "arch-designer" -> ScreenDestination.ARCH_DESIGNER
        "interior-designer" -> ScreenDestination.INTERIOR_DESIGNER
        "kitchen-designer" -> ScreenDestination.KITCHEN_DESIGNER
        "bathroom-designer" -> ScreenDestination.BATHROOM_DESIGNER
        "boundary-wall" -> ScreenDestination.BOUNDARY_WALL
        "material-calculator" -> ScreenDestination.MATERIAL_CALCULATOR
        "projects-gallery" -> ScreenDestination.PROJECTS_GALLERY
        "pdf-reports" -> ScreenDestination.PDF_EXPORT
        "settings" -> ScreenDestination.SETTINGS
        "backup-restore" -> ScreenDestination.BACKUP_RESTORE
        "offline-model-manager" -> ScreenDestination.OFFLINE_MODEL_MANAGER
        "component-library" -> ScreenDestination.COMPONENT_LIBRARY
        else -> null
    }
}
