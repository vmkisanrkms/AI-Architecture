package com.aiarchitecture.app.core

import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm
import com.aiarchitecture.app.core.units.DimensionProvenance
import com.aiarchitecture.app.feature.backup.BackupRestoreManager
import com.aiarchitecture.app.feature.backup.readBounded
import java.io.ByteArrayInputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BackupTest {
    @Test fun backupRoundTripPreservesProjectFloorsGeometryAndOpenings() {
        val base = BuildingModel.starter()
        val floor = base.floors.first()
        val wall = BuildingElement(
            floorId = floor.id,
            type = ElementType.WALL,
            origin = Vec3(125.0, 0.0, 250.0),
            size = Size3(
                DimensionMm(4000.0, DimensionProvenance.USER_ENTERED),
                DimensionMm(150.0),
                DimensionMm(2800.0, DimensionProvenance.ESTIMATED)
            ),
            openings = listOf(
                Opening(type = ElementType.DOOR, offsetMm = 900.0, widthMm = 900.0, heightMm = 2100.0)
            ),
            yawDegrees = 15.0
        )
        val model = base.addElement(wall)

        val restored = BackupRestoreManager.restore(BackupRestoreManager.createBackup(model))

        assertEquals(model.id, restored.id)
        assertEquals(model.name, restored.name)
        assertEquals(1, restored.floors.size)
        val restoredWall = restored.floors.single().elements.single()
        assertEquals(wall.id, restoredWall.id)
        assertEquals(4000.0, restoredWall.size.length.value, 0.0)
        assertEquals(DimensionProvenance.ESTIMATED, restoredWall.size.height.provenance)
        assertEquals(15.0, restoredWall.yawDegrees, 0.0)
        assertEquals(wall.openings, restoredWall.openings)
    }

    @Test fun boundedReadAcceptsWithinLimit() {
        val data = byteArrayOf(1, 2, 3)
        assertEquals(3, ByteArrayInputStream(data).readBounded(3).size)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsTamperedBackup() {
        val bytes = BackupRestoreManager.createBackup(BuildingModel.starter())
        val raw = bytes.toString(Charsets.UTF_8)
        val marker = raw.indexOf("\"payload\":\"") + 11
        assertTrue("Backup payload marker must exist", marker >= 11)
        bytes[marker] = if (bytes[marker].toInt() == 65) 66 else 65
        BackupRestoreManager.restore(bytes)
    }
}
