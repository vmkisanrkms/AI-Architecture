package com.aiarchitecture.app.core
import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.feature.bathroom.BathroomLayout
import org.junit.Assert.assertEquals
import org.junit.Test
class BathroomLayoutTest{@Test fun bathroomFixturesAreTypedGeometry(){val e=BathroomLayout.fixture("f",ElementType.SINK,Vec3(0.0,0.0,0.0),600.0,500.0,200.0);assertEquals(ElementType.SINK,e.type)}}
