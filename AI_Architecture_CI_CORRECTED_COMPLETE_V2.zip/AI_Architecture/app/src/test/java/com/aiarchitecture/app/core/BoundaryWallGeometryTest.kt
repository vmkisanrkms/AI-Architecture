package com.aiarchitecture.app.core
import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.feature.boundary.BoundaryWall
import org.junit.Assert.assertEquals
import org.junit.Test
class BoundaryWallGeometryTest{@Test fun boundaryWallAndPillarHaveExactDimensions(){val wall=BoundaryWall.wall("f",Vec3(0.0,0.0,0.0),12000.0,2400.0,230.0);val pillar=BoundaryWall.pillar("f",Vec3(0.0,0.0,0.0),450.0,450.0,2600.0);assertEquals(12000.0,wall.size.length.value,0.0);assertEquals(ElementType.PILLAR,pillar.type)}}
