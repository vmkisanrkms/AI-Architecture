package com.aiarchitecture.app.core

import com.aiarchitecture.app.core.geometry.Vec3
import com.aiarchitecture.app.feature.components.ArchitecturalComponents
import org.junit.Assert.*
import org.junit.Test

class ComponentFactoryTest {
    @Test fun catalogHasRequiredReusableComponents(){val keys=ArchitecturalComponents.catalog.map{it.key};listOf("gate","arch","pillar","glass-railing","steel-railing","balcony-railing","stair","door","window").forEach{assertTrue(keys.contains(it))}}
    @Test fun componentInstanceHasRealEditableDimensions(){val e=ArchitecturalComponents.instantiate("gate","ground",Vec3(0.0,0.0,0.0));assertEquals(3000.0,e.size.length.value,0.0);assertEquals("Steel",e.material)}
}
