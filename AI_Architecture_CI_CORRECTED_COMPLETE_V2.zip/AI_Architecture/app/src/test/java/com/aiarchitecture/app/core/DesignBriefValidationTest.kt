package com.aiarchitecture.app.core
import com.aiarchitecture.app.feature.ai.*
import org.junit.Assert.*
import org.junit.Test
class DesignBriefValidationTest{@Test fun acceptsValidBrief(){val b=DesignBrief("House",12000.0,9000.0,2,4,"Modern","Open courtyard");assertTrue(DesignBriefValidator.validate(b).isEmpty())};@Test fun rejectsInvalidDimensions(){val b=DesignBrief("",-2.0,0.0,0,300,"","x".repeat(5000));assertTrue(DesignBriefValidator.validate(b).size>=5)}}
