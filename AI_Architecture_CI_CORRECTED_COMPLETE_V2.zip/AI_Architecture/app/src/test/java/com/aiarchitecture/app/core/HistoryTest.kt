package com.aiarchitecture.app.core

import com.aiarchitecture.app.core.history.ModelHistory
import org.junit.Assert.*
import org.junit.Test

class HistoryTest{@Test fun undoRedoRestoresSnapshots(){val h=ModelHistory(1);h.commit(2);h.commit(3);assertEquals(3,h.current);assertEquals(2,h.undo());assertEquals(3,h.redo())}}
