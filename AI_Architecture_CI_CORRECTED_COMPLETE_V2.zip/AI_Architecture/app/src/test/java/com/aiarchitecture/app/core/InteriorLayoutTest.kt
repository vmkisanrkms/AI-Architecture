package com.aiarchitecture.app.core
import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.feature.interior.InteriorLayout
import org.junit.Assert.assertEquals
import org.junit.Test
class InteriorLayoutTest{@Test fun furnitureIsEditableGeometry(){val e=InteriorLayout.furniture("f",Vec3(0.0,0.0,0.0),2000.0,900.0,750.0);assertEquals(ElementType.FURNITURE,e.type);assertEquals(2000.0,e.size.length.value,0.0)}}
