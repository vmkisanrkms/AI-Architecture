package com.aiarchitecture.app.core
import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.feature.kitchen.KitchenLayout
import org.junit.Assert.assertEquals
import org.junit.Test
class KitchenLayoutTest{@Test fun cabinetAndCountertopHaveParametricDimensions(){val c=KitchenLayout.cabinet("f",Vec3(0.0,0.0,0.0));val top=KitchenLayout.countertop("f",Vec3(0.0,900.0,0.0),1800.0,600.0);assertEquals(ElementType.KITCHEN_CABINET,c.type);assertEquals(1800.0,top.size.length.value,0.0)}}
