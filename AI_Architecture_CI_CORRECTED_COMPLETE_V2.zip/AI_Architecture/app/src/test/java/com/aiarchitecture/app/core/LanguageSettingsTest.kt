package com.aiarchitecture.app.core
import com.aiarchitecture.app.feature.language.*
import org.junit.Assert.assertEquals
import org.junit.Test
class LanguageSettingsTest{@Test fun parsesHindiAndEnglish(){assertEquals(LanguageChoice.HINDI,LanguageSettings.parse("hi"));assertEquals(LanguageChoice.ENGLISH,LanguageSettings.parse("en"));assertEquals(LanguageChoice.HINDI,LanguageSettings.parse("unknown"))}}
