package com.aiarchitecture.app.core

import com.aiarchitecture.app.feature.calculator.MaterialCalculations
import org.junit.Assert.*
import org.junit.Test

class MaterialCalculationsTest {
    @Test fun wallVolumeDeductsOpening(){assertEquals(1.5,MaterialCalculations.wallVolume(4000.0,3000.0,150.0,2.0),1e-9)}
    @Test fun concreteAndPlasterAreas(){assertEquals(1.0,MaterialCalculations.concreteVolume(1000.0,1000.0,1000.0),1e-9);assertEquals(10.0,MaterialCalculations.plasterArea(5000.0,2400.0,2.0),1e-9)}
    @Test fun paintAndTiles(){assertEquals(4.0,MaterialCalculations.paintLitres(20.0,10.0,2),1e-9);assertEquals(11L,MaterialCalculations.tileCount(10.0,1000.0,1000.0,5.0))}
}
