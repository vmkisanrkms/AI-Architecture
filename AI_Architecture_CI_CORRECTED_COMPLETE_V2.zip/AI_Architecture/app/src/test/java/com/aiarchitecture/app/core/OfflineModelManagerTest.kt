package com.aiarchitecture.app.core
import com.aiarchitecture.app.feature.offline.*
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
class OfflineModelManagerTest{@Test fun rejectsMissingModel(){val result=OfflineModelManager.validate(LocalModelInfo(File("/path/not/here.gguf"),""),"arm64-v8a",1);assertTrue(result.any{it.contains("missing")})}}
