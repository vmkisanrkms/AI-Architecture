package com.aiarchitecture.app.core

import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm
import com.aiarchitecture.app.feature.planner.FloorPlanUseCases
import org.junit.Assert.*
import org.junit.Test

class PlannerUseCasesTest {
    @Test fun snapAndMeasure(){assertEquals(1000.0,FloorPlanUseCases.snap(960.0,100.0),0.0);assertEquals(500.0,FloorPlanUseCases.distanceMm(Vec2(0.0,0.0),Vec2(300.0,400.0)),0.0)}
    @Test fun moveAndResizeKeepStableIdentity(){val e=BuildingElement(floorId="f",type=ElementType.WALL,origin=Vec3(0.0,0.0,0.0),size=Size3(DimensionMm(1000.0),DimensionMm(150.0),DimensionMm(2500.0)));val moved=FloorPlanUseCases.move(e,100.0,200.0);val resized=FloorPlanUseCases.resizeLength(moved,2000.0);assertEquals(e.id,resized.id);assertEquals(100.0,resized.origin.x,0.0);assertEquals(2000.0,resized.size.length.value,0.0)}
}
