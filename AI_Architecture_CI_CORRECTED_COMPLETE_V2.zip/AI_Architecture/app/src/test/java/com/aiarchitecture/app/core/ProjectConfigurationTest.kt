package com.aiarchitecture.app.core
import com.aiarchitecture.app.feature.settings.*
import org.junit.Assert.assertEquals
import org.junit.Test
class ProjectConfigurationTest{@Test fun validatesSettingsDefaults(){val settings=AppSettings();assertEquals("mm",settings.displayUnit);assertEquals(AppThemeMode.SYSTEM,settings.theme);assertEquals(AppLanguage.HINDI,settings.language)}}
