package com.aiarchitecture.app.core

import com.aiarchitecture.app.feature.shell.ScreenCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ScreenCatalogTest {
    @Test fun exactlyTwentyOneScreensRemainMapped() {
        assertEquals(21, ScreenCatalog.all.size)
        assertEquals((1..21).toList(), ScreenCatalog.all.map { it.id })
    }
    @Test fun allRoutesAreUniqueAndResolvable() {
        val routes = ScreenCatalog.all.map { it.route }
        assertEquals(routes.size, routes.toSet().size)
        routes.forEach { assertNotNull(ScreenCatalog.byRoute(it)) }
    }
    @Test fun everyCatalogRouteMapsToItsOwnDistinctNavigationDestination() {
        val destinations = ScreenCatalog.all.map { ScreenCatalog.destination(it.route) }
        assertEquals(21, destinations.size)
        assertTrue(destinations.all { it != null })
        assertEquals(21, destinations.toSet().size)
        ScreenCatalog.all.forEach { screen ->
            assertNotNull("Missing destination for ${screen.route}", ScreenCatalog.destination(screen.route))
        }
    }
    @Test fun requiredCadDestinationsRemainPresent() {
        val routes = ScreenCatalog.all.map { it.route }.toSet()
        assertTrue(routes.containsAll(setOf("blueprint-editor", "3d-designer", "component-library", "pdf-reports", "backup-restore")))
    }
}
