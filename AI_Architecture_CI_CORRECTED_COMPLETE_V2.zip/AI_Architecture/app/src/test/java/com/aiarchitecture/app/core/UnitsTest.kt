package com.aiarchitecture.app.core

import com.aiarchitecture.app.core.units.*
import org.junit.Assert.assertEquals
import org.junit.Test

class UnitsTest {
    @Test fun exactUnitConversions(){assertEquals(25.4,Units.toMillimetres(1.0,LengthUnit.INCH),1e-9);assertEquals(304.8,Units.toMillimetres(1.0,LengthUnit.FOOT),1e-9);assertEquals(1000.0,Units.toMillimetres(1.0,LengthUnit.METRE),1e-9)}
    @Test fun conversionRoundTrips(){listOf(0.25,1.0,1234.567).forEach{mm->LengthUnit.values().forEach{u->assertEquals(mm,Units.toMillimetres(Units.fromMillimetres(mm,u),u),1e-9)}}}
    @Test(expected=IllegalArgumentException::class) fun rejectsNegative(){Units.toMillimetres(-1.0,LengthUnit.METRE)}
}
