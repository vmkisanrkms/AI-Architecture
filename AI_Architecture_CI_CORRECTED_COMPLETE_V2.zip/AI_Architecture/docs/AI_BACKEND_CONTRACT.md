# Online AI Backend Contract

The Android app never contains a provider API key. It calls a user-deployed HTTPS backend.

## Request
`POST /v1/designs/generate`

Content-Type: `multipart/form-data`

Fields:
- `prompt`: required UTF-8 Hindi or English prompt (maximum 12,000 characters)
- `category`: required design category
- `provider`: `default`, `openai`, `gemini`, or `self_hosted`; the backend validates this value and routes to its configured provider
- `image`: optional JPEG, PNG or WebP image (maximum 12 MB)

Optional header:
- `Authorization: Bearer <short-lived-session-token>`

## Successful response
```json
{
  "description": "A conceptual design description in the user's language.",
  "imageUrls": [
    "https://cdn.example.org/generated/design-001.webp"
  ]
}
```

The Android client requires non-empty `description`, at most 20 image URLs, and HTTPS image URLs. Provider selection only requests a backend route; it does not make a paid provider free or configure its credentials in the APK. It retries network errors, HTTP 429 and HTTP 5xx up to three attempts and reports upload byte progress.

## Backend security requirements
- Terminate TLS and reject cleartext HTTP.
- Authenticate users or issue short-lived scoped tokens.
- Store AI provider secrets only in server-side secret storage.
- Validate MIME type and actual image bytes; do not trust file extensions.
- Enforce upload size, request rate, output size and generation time limits.
- Scan uploaded content as appropriate and use private object storage.
- Define retention/deletion rules and never expose other users' generated files.
- Return only HTTPS image URLs accessible to the requesting user.
- Return structured JSON errors without leaking provider secrets or stack traces.

## Provider abstraction
The Android domain layer uses `OnlineAiProvider`. A backend may route to OpenAI, Gemini, an open-source self-hosted model, or another configured provider. Any paid provider account and usage charges belong to the backend operator and are not represented as free by this app.

No backend URL or provider credentials are shipped as defaults. Live online generation remains PENDING until a real backend is configured and tested.
