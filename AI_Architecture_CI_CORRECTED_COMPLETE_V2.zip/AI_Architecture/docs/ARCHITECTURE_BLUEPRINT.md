# AI Architecture — Architecture Blueprint

**Revision:** 2026-11-06  
**Status:** Requirements baseline recorded; implementation and source recovery pending.  
**Product class:** Native Android architectural CAD / editable 2D + 3D building design application, comparable in workflow ambition to SketchUp; not an AI-image-only application.

## 1. Product requirement (mandatory)
AI image generation is an optional concept-assistance capability. The core product must be a genuine editable architectural design system with 2D drafting, parametric 3D geometry, precise dimensions, reusable components, measurement tools, camera controls and dimensioned drawing export. Static images, pre-rendered pictures, or a fake 3D preview do not satisfy the requirement.

## 2. Core architecture layers
1. **Project & persistence layer:** project, floor, element, component instance, dimension, material and edit-history records. Preserve Room/SQLite offline-first behavior.
2. **Canonical geometry/domain layer:** all geometry stored in a single canonical coordinate system and canonical unit (millimetres); immutable or transaction-safe parametric entities; explicit dimension provenance (`USER_ENTERED`, `DERIVED`, `ESTIMATED`).
3. **2D drafting layer:** walls, room boundaries, openings, stairs, dimensions, grid, snap, alignment, precision, selection, transform handles, measurement and undo/redo.
4. **3D geometry engine:** actual editable scene geometry using the project’s chosen real engine (historical project notes cite SceneView/Filament; exact APIs must be confirmed from recovered source and dependency versions). Build real solids/meshes from parametric entities, not image planes.
5. **Synchronization layer:** one authoritative building model maps to 2D plans and 3D geometry. 2D edits update 3D; 3D property/transform edits update plan coordinates and dimensions. Use stable element IDs, transactions and deterministic regeneration to prevent drift.
6. **Component library & property inspector:** reusable definitions and instances with parameter schemas, constraints, materials and editable dimensions.
7. **Camera & interaction layer:** perspective/orthographic projection, orbit/rotate, pan, zoom and named standard views.
8. **Annotation & export layer:** dimension labels, measurement annotations, actual-scene screenshot/image capture, and scaled dimensioned PDF drawing sheets.
9. **Validation layer:** geometry invariants, numerical tests, export inspection, Android build and real device/emulator acceptance.

## 3. Canonical dimensions and unit policy
- Store all lengths internally in **millimetres** as a consistent numeric representation; do not store rounded display strings as geometry.
- Display units: millimetre (mm), metre (m), inch (in), foot (ft). Conversion constants: 1 in = 25.4 mm; 1 ft = 304.8 mm; 1 m = 1000 mm.
- Preserve adequate numeric precision internally. Apply rounding only at display/export boundaries according to the selected precision setting.
- A user-entered dimension is authoritative. Geometry generation must use that exact canonical value.
- Derived values must carry their derivation. Unknown/inferred values must carry `ESTIMATED` provenance and be visibly marked **Estimated** in the inspector, labels and PDF. Never silently replace a user value with an estimate.
- Dimension edits must update dependent vertices/solids proportionally according to explicit constraints; constrained dimensions must not unexpectedly distort unrelated geometry.

## 4. Building and floor data model
- Building → Floors → Levels → Elements / Component Instances.
- Every floor has its own plan geometry, elevation offset, ceiling/floor heights and visibility/lock state.
- Floor selection selects the actual floor model for editing and rendering; visibility controls can show adjacent floors as reference only.
- Shared building elements (e.g. continuous columns/stairs) must declare their floor span and cross-floor relationship.
- Each element has a stable ID, type, transform, dimensions, material, constraints, source/provenance and revision.

## 5. Required editable geometry/components
- Structural: walls, slabs/floors, pillars/columns, beams where supported, stairs and landings.
- Openings: doors and windows create real voids in host walls; door leaf/frame and window frame/glazing are separate geometry with editable dimensions and offsets.
- Railings: glass, steel and balcony railing systems with editable posts, rails, panel thickness, height and spacing.
- Architectural library: gates, arches, pillars, railings, stairs, doors and windows.
- Component actions: insert, select, move, rotate where applicable, resize, edit properties, duplicate and delete; changes must regenerate the actual engine geometry and linked 2D symbols.

## 6. Editing and precision tools
- Draw, move, resize, delete, undo and redo.
- Grid display and configurable grid spacing; snap to grid, endpoints, midpoints, axes and alignment guides.
- Precision controls for input/display decimal places and angular/linear snapping.
- Measurement tool for point-to-point, wall, opening, room and vertical dimensions.
- Automatic dimension annotations for walls, doors, windows, stairs, railings and pillars; labels must remain readable and avoid overlap where possible.

## 7. Camera and views
- Camera projection: orthographic and perspective.
- Navigation: rotate/orbit, zoom and pan.
- Presets: front, back, left, right, top and isometric.
- Camera state is separate from geometry state; changing camera must never alter dimensions or model coordinates.

## 8. 2D ↔ 3D synchronization contract
- The canonical model is the source of truth; 2D and 3D are views/editors over the same stable-ID entities.
- 2D wall endpoints, room polygons, openings and stairs map to corresponding 3D solids at the selected floor elevation.
- 3D property changes write back to canonical dimensions/transforms and regenerate the 2D plan/dimensions.
- All edits execute as validated transactions with undo/redo snapshots or reversible commands.
- Regeneration must be deterministic; repeated regeneration with unchanged inputs produces equivalent geometry.

## 9. Export requirements
- Screenshot/image export must capture the live rendered 3D scene, not a substituted illustration.
- PDF drawing export must include dimensioned 2D plans and/or 3D views, scale, unit legend, floor/view name, dimension strings, component annotations and readable line weights/text.
- Export must preserve the exact canonical dimensions and visibly mark estimated dimensions.

## 10. Required numerical and behavioral tests
- Unit conversion round trips: mm↔m, mm↔in, mm↔ft, including fractional inches/feet and display rounding.
- Geometry fidelity: user-entered L/W/H equal generated geometry dimensions within a documented tolerance.
- Proportional resize and constraint preservation.
- Floor isolation and elevation offsets.
- Door/window wall-void dimensions, offsets and boundary clamping.
- Stair tread/riser/width and railing height/spacing.
- Component property edit regenerates 3D geometry and 2D annotation.
- 2D→3D and 3D→2D round-trip correspondence.
- Dimension label values and PDF exported dimension values match canonical data.
- Undo/redo restores both geometry and properties.
- Camera projection and preset tests must confirm view orientation without mutating model geometry.

## 11. Screen and section integration
- Retain the original 20 screens and all 22 requirement sections.
- Add screen 21: **Architecture Component Library & Properties Inspector**.
- Integrate drafting tools into Screen 7 (2D Blueprint Editor), geometry/camera/export into Screen 8 (3D House Designer), gate/arch/pillar/railing components into Screens 9/14, and dimensioned PDF into Screen 17.
- No existing feature may be removed to make room for this requirement.

## 12. Current status and recovery dependency
The currently available workspace contains project documentation only. The historical feature ledger describes 55 Kotlin files, 8 unit-test files and 6 instrumentation-test files, and historical notes mention SceneView/Filament plus an isolated geometry pipeline. Those source files are not presently available for inspection or integration. Therefore this blueprint is **requirements recorded**, not an implementation claim. Recover and checksum the original source before modifying the Android application.

**Separate release gates:** source recovery; geometry/unit tests; Gradle build; emulator/device 3D rendering; PDF/export inspection; final acceptance. Android build and device test remain Pending until actually executed.
