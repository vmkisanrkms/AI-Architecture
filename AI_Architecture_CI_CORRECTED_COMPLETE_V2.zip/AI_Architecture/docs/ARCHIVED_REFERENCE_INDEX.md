# Archived Requirement and Audit References

The files copied from `AI_Architecture_Work` preserve the earlier project scope, screen ledger, architecture decisions and historical audit notes. They are retained as references only.

- `FEATURE_STATUS.md` — original 21-screen / 22-section ledger, including partial historical implementation notes.
- `ARCHITECTURE_BLUEPRINT.md` — authoritative canonical-mm, editable 2D/3D CAD requirements.
- `RECOVERY_REPORT_HI.md` — old developed source was not recovered in the available search.
- `NEW_PROJECT_BUILD_PLAN.md` — planned phase sequence; this project has now begun Phase 1.
- `AUDIT_REPORT.md`, `BUILD_INSTRUCTIONS.md`, `SECURITY_AUDIT.md`, `AI_BACKEND_CONTRACT.md`, `OFFLINE_MODEL_NOTES.md`, `CHANGELOG.md` — historical requirements/audit reference documents.
- `RECOVERED_README_REFERENCE.md` — previous README retained for history.

Historical statements that describe 55 Kotlin files, 8 unit-test files, 6 instrumentation-test files or earlier source implementation do not prove those source bytes were recovered. The new source is the code under `app/src/main` in this repository. Current truthful implementation/test status is in `NEW_PROJECT_STATUS.md` and `PHASE1_IMPLEMENTATION.md`.
