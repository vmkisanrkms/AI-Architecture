# Audit Report — AI Architecture

Audit date: 2026-11-06
Audit type: Source/static configuration audit plus isolated pure-Kotlin geometry checks. No Android build/runtime environment is available in this authoring workspace.

## 1. Project identity and configuration
- App label: AI Architecture
- Package: `com.aiarchitecture.app`
- Minimum SDK: 26
- Compile/Target SDK: 36
- JDK configured for CI: 17
- Gradle wrapper distribution: 8.13
- Kotlin 2.3.21, Compose compiler plugin 2.3.21, KSP 2.3.12, AGP 8.12.1 and Gradle 8.13 are pinned as a compatible candidate set; actual dependency resolution/build remains pending.
- Branding scan found only the required app name and package in source files.

## 2. Static checks actually executed
- GitHub Actions YAML parsed successfully with PyYAML.
- AndroidManifest and English/Hindi string resource XML files parsed successfully.
- Static inventory found 20 route objects and 18 specialized feature destinations; all 18 feature destinations have explicit handlers in `MainActivity`.
- Kotlin lexical delimiter scan passed for all 55 Kotlin source files.
- All Kotlin package declarations match the application namespace.
- `kotlinc` compiled the floor-plan model and geometry sources with a temporary Serializable annotation stub; standalone executable checks passed room/stair hit-testing, snapped movement, dimension preservation and room-boundary detection. Android UI source was not compiled.
- Legacy branding scan passed with no forbidden old product name in the project.
- Old generic `FeatureScreen` placeholder was removed; an unregistered route now fails loudly.
- These are static source checks only, not Kotlin compilation or runtime verification.

## 3. Source areas currently implemented
- AppCompat locale and Compose theme settings foundation.
- Room v3 project schema, DAO, database provider, repository validation, migrations 1→2→3 and recovery snapshot/rollback source.
- Project create/edit/delete/duplicate/search/category filter/sort and image gallery source.
- 2D Canvas plan model with walls, rooms, door/window openings, stairs, dimensions, segment-accurate wall hit-testing, room/stair selection and move/delete, linked room-boundary wall handling, snap, draw/move/resize/delete, undo/redo, zoom/pan, Room save/load and debounced auto-save source.
- SceneView/Filament parametric house 3D geometry, camera manipulation, exterior material selection, lighting and project save source. Gate, arch, boundary wall, interior, kitchen and bathroom screens now include parametric 3D concept preview source.
- Gate/arch/interior/kitchen/bathroom/boundary specification forms.
- Brick, concrete volume, foundation concrete, editable concrete/plaster mix ratio, paint, tile, steel, flooring and wall-area calculation source.
- Online AI HTTPS provider contract/client with selectable backend provider routing, request validation, retry handling, upload progress and local image caching.
- Photo Picker upload flow with explicit consent, image size/MIME validation and project persistence.
- Offline GGUF model manager with Wi-Fi-only downloads, declared size/free-space checks, SHA-256 verification, arm64/RAM/storage screening and llama.cpp inference adapter source.
- Multi-page Hindi/English PDF report source using Android StaticLayout and local image pages.
- JSON backup/restore source with project and calculation-history records, local image bytes, checksum validation, 80 MB bounded import, duplicate policies and transactional restore; an image-inclusive backup/restore instrumentation test has been added but not executed.
- GitHub Actions CI source with Gradle bootstrap, wrapper checksum validation, SDK36, unit tests, lint, emulator instrumentation tests, APK inspection and conditional signing.
- 8 unit-test source files and 6 Android instrumentation-test source files (14 total); these include 12 numerical calculator cases, online URL validation, backup path/checksum, plan geometry, real Room migration, recovery, image restore, Hindi PDF and UI navigation test cases.

## 4. Build blocker and Gradle Wrapper
- `gradle/wrapper/gradle-wrapper.properties`, `gradlew` and `gradlew.bat` are present.
- `gradle/wrapper/gradle-wrapper.jar` is absent.
- A real `./gradlew --version` attempt failed with `ClassNotFoundException: org.gradle.wrapper.GradleWrapperMain`.
- No system Gradle, Android SDK, `sdkmanager` or `adb` is installed in the current workspace. `kotlinc` is available and was used only for the isolated pure-geometry compile/check above. The available Java runtime is OpenJDK 21, not the requested JDK 17.
- Outbound DNS resolution is unavailable, so the authentic wrapper JAR could not be downloaded.
- CI now bootstraps Gradle 8.13 using `gradle/actions/setup-gradle`, generates the wrapper via `gradle wrapper`, checks the wrapper JAR SHA-256, validates the wrapper and runs `./gradlew`. The official Gradle distribution SHA-256 is pinned in the wrapper properties. This resolution has not yet been executed in GitHub Actions.

## 5. Known implementation gaps
- Online AI still requires a real HTTPS backend matching `AI_BACKEND_CONTRACT.md`; no endpoint/provider credentials are configured.
- Offline AI requires a user-supplied GGUF model, URL, SHA-256 and licence consent. The selected community llama.cpp AAR is CPU-only and arm64-v8a-only; actual model load/inference has not been run.
- Gate/arch/interior/kitchen/bathroom/boundary screens now have parametric 3D concept preview source, but are not full interactive editors: gate style-specific construction details, precise arch variants, furniture/cabinet/fixture placement controls, and 2D plan previews remain pending.
- A repeatable image-inclusive backup/restore instrumentation test and a point-to-wall geometry unit test have been added; neither has been executed yet.
- The 3D renderer has not been compiled or run on a device. Screenshot/export, orthographic view, floor selection and detailed interior placement remain pending; adjustable entrance-door/window widths and parametric wall openings are now in source.
- 2D Canvas editing and debounced auto-save source is present, but pointer gestures, undo/redo, snapping, persistence and interrupted-edit recovery have not been executed on an emulator.
- Hindi/English resources now cover the language selector and all 18 dashboard destinations; most feature-form, toolbar and dialog labels remain hardcoded in English.
- PDF report source includes text and local images, but actual Hindi glyph shaping, page layout and image rendering have not been visually inspected on-device.
- JSON backup embeds local image bytes and validates checksums, but full SAF export/import and cross-device restore have not been executed.
- Native adaptive launcher icon resources are now present; launcher rendering on real Android launchers remains unverified. Full accessibility review, app-wide autosave/interrupted-edit recovery, and some export/format features remain pending.

## 6. Test execution record
| Check | Result |
|---|---|
| Workflow YAML parse | PASS (static parser only) |
| Android XML parse | PASS (static parser only) |
| Route inventory | PASS (20 routes; 18 feature handlers) |
| Static source gate | PASS (source/config checks only) |
| Kotlin delimiter/package scan | PASS (static only) |
| Isolated floor-plan geometry compile/check | PASS (`kotlinc`; excludes Android UI) |
| Secret-pattern/branding scan | PASS (static only) |
| Kotlin compilation | NOT RUN |
| Gradle dependency resolution | NOT RUN |
| Room KSP/schema generation | NOT RUN |
| Unit tests | NOT RUN |
| Android lint | NOT RUN |
| Connected UI/database/PDF tests | NOT RUN |
| Debug APK | NOT BUILT |
| Release APK | NOT BUILT |
| APK signing | NOT RUN |
| SceneView/Filament device rendering | NOT RUN |
| GGUF download/checksum/model inference | NOT RUN |
| PDF Hindi visual inspection | NOT RUN |
| Full security/dependency audit | NOT RUN |

## 7. Release decision
**NOT FINAL. NOT RELEASE-READY.**

No application feature is marked VERIFIED. Passed checks are limited to static YAML/XML parsing, source-gate rules, route/package/branding/secret scans and Kotlin delimiter balance. The final ZIP is intentionally not created. The next mandatory gate is the first GitHub Actions run, followed by fixing every reproducible build/test/device failure and completing the outstanding feature modules.


## Development phase — 2D non-wall object editing (2026-11-06)
- Added pure geometry hit-testing for room and stair bounds, snapped translation helpers, and room-boundary wall identification.
- Blueprint editor can now select/move/delete rooms and stairs; moving a generated room also moves its four corner-connected boundary walls; deleting a room removes those boundary walls and their attached openings.
- Added five PlanGeometry unit cases and one Compose UI scenario for room selection, movement and deletion. A separate `kotlinc` harness compiled/executed the pure geometry functions successfully; JUnit/Compose tests remain unexecuted.
- Static validation only; Kotlin/Compose compilation and Android execution remain pending because the Gradle wrapper JAR and Android SDK are unavailable in this workspace.
