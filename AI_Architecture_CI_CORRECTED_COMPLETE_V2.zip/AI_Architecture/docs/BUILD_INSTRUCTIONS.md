# Build Instructions — AI Architecture

## Prerequisites
- Android Studio with Android SDK Platform 36
- Android Build Tools 36.0.0
- JDK 17
- Gradle 8.13 for first-time local wrapper generation

## Gradle Wrapper
The source workspace contains `gradlew`, `gradlew.bat`, and `gradle/wrapper/gradle-wrapper.properties`. The official Gradle 8.13 distribution SHA-256 is pinned. The authentic `gradle-wrapper.jar` is not present in this authoring environment because outbound DNS/network access is unavailable.

### Local bootstrap
If Gradle 8.13 is installed locally, run once from the repository root:
```bash
gradle wrapper --gradle-version 8.13 --distribution-type bin
chmod +x gradlew
./gradlew --version
```
This generates the official wrapper JAR and scripts for the pinned Gradle distribution.

### GitHub Actions bootstrap
The workflow installs JDK 17 and Gradle 8.13 with `gradle/actions/setup-gradle`, generates the wrapper using the Gradle `wrapper` task, checks the generated wrapper JAR against Gradle's published SHA-256, validates the wrapper configuration and pinned distribution checksum, runs the static source gate, and then runs all build commands through `./gradlew`. The release APK is zipaligned before signing; signed output is verified with `apksigner` and `zipalign`. The generated wrapper JAR is included in the CI artifact.

## Static source gate
```bash
python3 scripts/verify_source.py
```
GitHub Actions runs the same gate with `--require-wrapper` after generating the wrapper JAR. This gate checks package identity, 20 routes, explicit feature handlers, manifest network policy and required source files; it is not a substitute for compilation or runtime tests.

## Build and test commands
```bash
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
./gradlew assembleRelease
./gradlew connectedDebugAndroidTest
```

`connectedDebugAndroidTest` requires an Android emulator or connected device. GitHub Actions starts an API 36 Google APIs x86_64 emulator for the instrumentation suite.

## GitHub repository
1. Create a repository named `AI-Architecture`.
2. Upload the project contents to the repository root.
3. Push to `main` or `master`.
4. Open Actions → Android CI. The workflow also supports manual dispatch.
5. Download the `ai-architecture-ci-artifacts` artifact for APKs, reports and the generated Gradle wrapper JAR.

## Release signing
In GitHub repository Settings → Secrets and variables → Actions, add:
- `KEYSTORE_BASE64`: base64-encoded JKS/PKCS12 keystore bytes
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

If any signing secret is absent, the workflow reports that signed release is pending and only publishes the unsigned release APK. Do not distribute an unsigned APK as a signed release.

## External services and model weights
- Online AI requires an HTTPS backend matching `AI_BACKEND_CONTRACT.md`; backend provider fees, if any, are separate and must be disclosed by the backend operator.
- Offline AI requires a compatible GGUF model URL, SHA-256 checksum and user licence consent. The model is not bundled in the APK.
