# Changelog

## 2026-11-06 — Development iteration
- Added SceneView/Filament-based parametric 3D house geometry source.
- Added arm64 llama.cpp GGUF offline inference adapter and Wi-Fi-only model download manager with size and SHA-256 checks.
- Added 2D room, door/window opening, stair and dimension objects; snapping and unit display controls.
- Added Room schema v3 image-reference migration.
- Added local image persistence, gallery previews, PDF image pages and image-inclusive JSON backup.
- Added Room recovery snapshot rollback and migration test sources.
- Added online AI retry and upload-progress handling.
- Added language/theme settings and English/Hindi resource foundations.
- Expanded UI, unit and instrumentation test sources.
- GitHub workflow now bootstraps and validates the Gradle wrapper in CI, runs a repeatable static source gate, records APK/dependency inspection output, and zipaligns before signing.
- Added a reusable static source verification script for package identity, route wiring, manifest network policy and required files.\n- Localized all 18 dashboard destination labels and the language selector in English and Hindi.
- Added live parametric Filament 3D concept previews to gate, arch, boundary wall, interior, kitchen and bathroom design screens.
- Added foundation concrete calculations and editable cement/sand/aggregate ratios for concrete and plaster.
- Added image-inclusive backup/restore instrumentation test source and bounded JSON import.
- Added 2D plan hit-testing correction and debounced Room auto-save.\n- Added adjustable door/window widths and actual openings to the Filament house geometry.\n- Added native adaptive launcher icon and round-icon resources.\n- Added brick-masonry mortar/cement/sand estimates and expanded numerical formula test coverage.\n- Added backend-routed provider selection for default, OpenAI, Gemini and self-hosted AI endpoints.\n- Added Room schema v4 calculation-history storage, CRUD instrumentation coverage and included calculation records in JSON backup/restore.

All new source functionality remains PENDING until build and runtime tests are executed.

- Continued the 2D Blueprint Editor: added Room/Stairs hit-testing, selection highlighting, drag-to-move with optional 100 mm snapping, delete support, and linked movement/deletion of room boundary walls and their openings. Added geometry and UI test cases (not executed). An isolated kotlinc compile/executable check of the pure geometry layer passed.
