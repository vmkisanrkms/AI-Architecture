# AI Architecture — New Native Android Kotlin Project Build Plan

**Revision:** 2026-11-06  
**Status:** Planning baseline only — implementation has not started.  
**Recovery decision:** Original developed source (historical 55 Kotlin + 8 unit-test + 6 instrumentation-test files) was not recovered from the available workspace/Library archive inventory. The old starter ZIP is not a substitute.

## 1. Non-negotiable preservation rules

1. Preserve all original 20 screens and all 22 requirement sections; retain the added 21st Architecture Component Library & Properties Inspector screen.
2. Carry forward all previously specified 2D planner, 3D designer, gates/arches, interior, kitchen, bathroom, boundary wall, material calculator, projects/gallery, PDF, settings, backup/restore and AI features.
3. Implement the new SketchUp-class editable 2D/3D CAD requirements in `ARCHITECTURE_BLUEPRINT.md` without replacing existing scope.
4. No static image or pre-rendered image may be represented as an editable 3D model.
5. User-entered dimensions are authoritative. Inferred values must be visibly marked `Estimated`.
6. Do not label a feature Completed or Verified merely because a screen, route, model, or source file exists. `Verified` requires recorded test/build/runtime evidence.
7. Keep all recovered documentation and any future source snapshots. Never overwrite an input archive; work in a separate project directory and create timestamped backups before edits.
8. Do not create a Final Release ZIP until source, tests, Android build, device rendering, PDF inspection, and acceptance gates pass.

## 2. Project identity and delivery target

- Product: AI Architecture
- Package: `com.aiarchitecture.app` (confirm against the recovered requirements before project bootstrap)
- Platform: Native Android
- Language/UI: Kotlin + Jetpack Compose + Material 3
- Architecture: MVVM with domain/data/feature boundaries
- Local persistence: Room / SQLite; offline-first for projects, geometry, materials, history and settings
- Build: Gradle Kotlin DSL, JDK 17, Android SDK API 36 (verify dependency compatibility when pinning versions)
- Delivery path: GitHub repository + GitHub Actions build, operated from the user's Android phone; no old PC is required for cloud CI.

## 3. Proposed source architecture

```text
app/
  core/
    common/          # Result, validation, IDs, errors
    units/           # mm canonical storage; mm/m/in/ft conversion
    geometry/        # canonical parametric building model and constraints
    history/         # command transactions, undo/redo
    database/        # Room entities, DAOs, migrations
    rendering/       # real 3D engine adapter and scene lifecycle
    export/          # dimensioned PDF and live scene capture
    design-system/   # Material 3 theme, typography, components
  feature/
    splash/
    language/
    dashboard/
    ai-generator/
    photo-analysis/
    projects/
    floor-planner/
    blueprint-editor/
    building-3d-editor/
    component-library/
    gate-designer/
    arch-designer/
    interior-designer/
    kitchen-designer/
    bathroom-designer/
    boundary-wall/
    material-calculator/
    reports-pdf/
    settings/
    backup-restore/
    offline-model-manager/
  navigation/
  app-shell/
app/src/test/        # pure domain, units, geometry, constraints and use-case tests
app/src/androidTest/ # Room, Compose, renderer and device interaction tests
```

The exact 3D engine and version must be pinned only after dependency/API compatibility is checked. Historical notes mention SceneView/Filament, but the old source is unavailable; do not assume old APIs or claim renderer integration until compiled and exercised.

## 4. Canonical model and engineering rules

- Store geometry in millimetres using adequate numeric precision; round only for display/export.
- Every element has a stable ID, floor ID, type, transform, dimensions, material, constraints, revision and dimension provenance.
- Provenance values: `USER_ENTERED`, `DERIVED`, `ESTIMATED`.
- Building hierarchy: Project → Building → Floors → Elements/Component Instances.
- One canonical model feeds both 2D drafting and 3D solids. No duplicated, independently drifting geometry models.
- All edits are validated transactions and support undo/redo.
- Component property changes regenerate actual meshes and linked 2D symbols/dimensions.
- Door/window openings are real wall voids, not painted rectangles.
- Floor elevation and visibility are independent and tested.
- Camera state is separate from geometry state.

## 5. Build phases and exit gates

### Phase 0 — Requirements and recovery baseline
- Reconcile all 21 screens and 22 sections against `FEATURE_STATUS.md`.
- Reconcile every historical 2D/3D improvement and new CAD requirement against `ARCHITECTURE_BLUEPRINT.md`.
- Preserve source-recovery findings and documentation-only evidence.
- Exit: requirements traceability matrix has no omitted screen/section; all implementation statuses remain Pending.

### Phase 1 — Native project foundation
- Create clean Kotlin/Compose project, package identity, Gradle wrapper/workflow, manifest, theme, navigation and app shell.
- Add Room schema, migrations, project/floor/element/component/material/history records.
- Configure offline-first policy and document any network permission needed only by explicitly consented AI/backend features.
- Exit: clean CI compile, database migration tests and app launch smoke test.

### Phase 2 — Domain geometry and units
- Implement canonical mm model, exact unit conversions, dimension provenance, validation and constraints.
- Implement walls, floors/slabs, rooms, pillars, openings, doors/windows, stairs and railings as parametric domain entities.
- Implement deterministic mesh/shape generation inputs and stable IDs.
- Exit: unit and geometry tests pass, including conversion round trips and exact dimension fidelity.

### Phase 3 — 2D Blueprint Editor
- Implement draw/select/move/resize/delete, wall/room/opening/stair editing, dimension annotations, grid, snap, alignment and precision controls.
- Add measurement, zoom/pan, floor isolation, save/load and undo/redo.
- Connect to the canonical model, not a separate mock model.
- Exit: Compose interaction tests and 2D persistence/geometry tests pass.

### Phase 4 — Real editable 3D engine
- Integrate a real Android 3D engine with generated editable geometry/meshes.
- Implement perspective/orthographic camera, orbit/rotate, zoom, pan and front/back/left/right/top/isometric presets.
- Support select/move/resize/delete and property-driven geometry regeneration.
- Implement 2D↔3D synchronization over stable element IDs.
- Exit: engine compiles; emulator/device can manipulate live solids; dimension values remain invariant under camera movement; 2D/3D round-trip tests pass.

### Phase 5 — Component library and specialist designers
- Build reusable gates, arches, pillars, glass/steel/balcony railings, doors, windows and stairs.
- Add insert, duplicate, move, rotate where applicable, resize, property editing and delete.
- Connect gate/arch/interior/kitchen/bathroom/boundary-wall designers to the same model and engine.
- Exit: component property tests prove actual geometry and 2D annotations update.

### Phase 6 — Existing non-CAD product scope
- Implement/port AI brief generation, photo upload/consent, online provider abstraction, offline model manager, material calculators, project gallery, settings and backup/restore.
- Preserve Hindi/English flows and all prior calculator formulas/requirements.
- Exit: feature-specific tests and security/privacy checks pass; external backend/model dependencies clearly disclosed.

### Phase 7 — Dimensioned PDF and reports
- Export dimensioned 2D plans and/or 3D views with scale, unit legend, floor/view, component annotations and readable dimensions.
- Capture the actual live 3D scene for image export.
- Mark estimated dimensions explicitly.
- Exit: inspect generated PDFs on Android, verify numerical values against canonical model and verify Hindi/English glyph rendering.

### Phase 8 — Full verification and release candidate
- Run all unit tests, instrumentation tests, lint, static audits, migration tests and GitHub Actions build.
- Install APK on a real Android device; test cold start, project CRUD, 2D editing, live 3D editing, component library, undo/redo, PDF export, backup/restore, offline behavior and permissions.
- Produce test evidence, SHA-256 checksums and an honest known-issues list.
- Exit: all mandatory acceptance gates pass. Only then prepare a Final Release ZIP/APK artifact.

## 6. Screen and section traceability

- Screens 1–20 remain in the existing `FEATURE_STATUS.md` inventory.
- Screen 21 is Architecture Component Library & Properties Inspector.
- All 22 original sections remain mandatory; Section 8 is the central 3D CAD acceptance section, with linked updates to Sections 7, 9, 13/17, 15 and 19 as detailed in the Blueprint and Feature Status.
- This plan does not mark any implementation or runtime feature Verified.

## 7. Mobile-only working method

The user does not need the old computer. Work can be prepared in ChatGPT and stored as project files; source can be placed in a GitHub repository and built with GitHub Actions. The user can operate GitHub from Android. Cloud CI is not proof of device behavior: after CI succeeds, install the APK on the phone and complete the device acceptance checklist. If the GitHub repository is not yet created or connected, that setup is a later explicit step; do not assume access or push files without authorization.

## 8. Current truthful status

| Area | Status |
|---|---|
| Historical developed source recovery | Not recovered after final available Library ZIP inventory/search |
| Old starter ZIP | Found; insufficient and not used as recovered source |
| Requirements / 21 screens / 22 sections | Recorded in documentation; traceability review still required during implementation |
| Architecture Blueprint | Requirements baseline recorded |
| New Native Kotlin project scaffold | Pending |
| Geometry/domain implementation | Pending |
| 2D editor implementation | Pending in the new project |
| Real 3D engine integration | Pending |
| Component library / property inspector | Pending |
| Unit and instrumentation tests | Pending in the new project |
| Gradle build / APK | Pending |
| Real-device acceptance | Pending |
| Final Release ZIP | Not created |

**No feature in this plan is marked Verified.** Planning documents are not implementation evidence.
