# Offline model runtime notes

## Runtime selected
- Android AAR: `dev.ffmpegkit-maintained:llama-android:0.1.1`
- Engine: llama.cpp CPU/NEON
- Model format: GGUF
- Published AAR metadata: minSdk 24; arm64-v8a only; MIT license.
- The project retains minSdk 26 and JDK 17.
- The app does not bundle model weights. The user supplies a trusted HTTPS model URL, SHA-256 checksum and confirms the model licence before Wi-Fi download.

## Device restrictions
- Offline inference is enabled only when the device reports `arm64-v8a`.
- The current app uses a conservative 6 GB RAM recommendation and 1.5 GB free-storage threshold.
- The selected AAR is CPU/NEON only; it does not provide GPU acceleration or streaming tokens in its published free artifact.
- A GGUF model's own licence and download terms are separate from the runtime's MIT licence. Do not assume all models are free for commercial use.
- Android DownloadManager can recover from supported network interruptions, but the current UI does not expose explicit user-controlled pause/resume; this remains pending.\n- Model size, context length and quality depend on the chosen GGUF model. The initial runtime config uses a 2048-token context and 512-token output cap.

## Maturity and verification
The selected AAR is a newly published, small community-maintained project. It is a pragmatic JDK17/API26-compatible integration candidate, not a broadly established Android platform runtime. It must pass Gradle resolution, arm64 APK packaging and real-device load/inference tests before the Offline AI feature can be marked VERIFIED.
