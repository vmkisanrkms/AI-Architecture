# Phase 1 — Native Kotlin Project Foundation

**Status:** Source foundation authored. Android Gradle build and phone runtime are NOT VERIFIED.

## Actual files created

### Android / build / CI
- `settings.gradle.kts`
- `build.gradle.kts`
- `gradle.properties`
- `app/build.gradle.kts`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/res/values/strings.xml`
- `.github/workflows/android-ci.yml`
- `scripts/verify_project.py`

### Native app and navigation
- `app/src/main/java/com/aiarchitecture/app/MainActivity.kt`
- `app/src/main/java/com/aiarchitecture/app/navigation/AppNavHost.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/projects/ProjectsScreen.kt`
- `app/src/main/java/com/aiarchitecture/app/ui/theme/Theme.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/editor/BlueprintEditorScreen.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/projects/ProjectsScreen.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/components/ComponentLibraryScreen.kt`

### Canonical geometry / renderer / editing
- `app/src/main/java/com/aiarchitecture/app/core/units/Units.kt`
- `app/src/main/java/com/aiarchitecture/app/core/geometry/BuildingModel.kt`
- `app/src/main/java/com/aiarchitecture/app/core/geometry/MeshBuilder.kt`
- `app/src/main/java/com/aiarchitecture/app/core/geometry/DimensionEngine.kt`
- `app/src/main/java/com/aiarchitecture/app/core/geometry/GeometryConstraints.kt`
- `app/src/main/java/com/aiarchitecture/app/core/geometry/GridSnapEngine.kt`
- `app/src/main/java/com/aiarchitecture/app/core/history/ModelHistory.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/renderer/Building3DView.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/planner/FloorPlanUseCases.kt`

### Room / repository / backup / PDF
- `app/src/main/java/com/aiarchitecture/app/data/local/Entities.kt`
- `app/src/main/java/com/aiarchitecture/app/data/local/AppDatabase.kt`
- `app/src/main/java/com/aiarchitecture/app/data/repository/ProjectRepository.kt`
- `app/src/main/java/com/aiarchitecture/app/data/repository/BuildingModelStore.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/backup/BackupRestoreManager.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/backup/BoundedInput.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/export/DimensionedPdfExporter.kt`

### Specialist-domain foundations
- `app/src/main/java/com/aiarchitecture/app/feature/components/ArchitecturalComponents.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/components/GateComponent.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/components/ArchComponent.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/interior/InteriorLayout.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/kitchen/KitchenLayout.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/bathroom/BathroomLayout.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/boundary/BoundaryWall.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/calculator/MaterialCalculations.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/ai/DesignBrief.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/ai/AiProvider.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/photo/PhotoConsent.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/settings/AppSettings.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/language/LanguageSettings.kt`
- `app/src/main/java/com/aiarchitecture/app/feature/offline/OfflineModelManager.kt`

## Tests created

Unit test source files (16 files total):
- `app/src/test/java/com/aiarchitecture/app/core/UnitsTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/GeometryTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/HistoryTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/BackupTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/ComponentFactoryTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/PlannerUseCasesTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/MaterialCalculationsTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/DimensionEngineTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/LanguageSettingsTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/DesignBriefValidationTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/InteriorLayoutTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/KitchenLayoutTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/BathroomLayoutTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/BoundaryWallGeometryTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/OfflineModelManagerTest.kt`
- `app/src/test/java/com/aiarchitecture/app/core/ProjectConfigurationTest.kt`

Instrumentation test source files (5 files total):
- `app/src/androidTest/java/com/aiarchitecture/app/LaunchSmokeTest.kt`
- `app/src/androidTest/java/com/aiarchitecture/app/ProjectCrudTest.kt`
- `app/src/androidTest/java/com/aiarchitecture/app/PhotoPickerConsentTest.kt`
- `app/src/androidTest/java/com/aiarchitecture/app/DimensionedPdfExportTest.kt`
- `app/src/androidTest/java/com/aiarchitecture/app/Building3DRenderingTest.kt`

**Count:** 36 main Kotlin files, 16 unit-test source files, and 5 Android instrumentation-test source files (36 `@Test` methods in source). Test source is authored, not yet run by Gradle/JUnit.

## Checks actually executed in this workspace

- `scripts/verify_project.py`: 12/12 static inventory/traceability checks passed.
- YAML parser: `.github/workflows/android-ci.yml` parsed successfully.
- `kotlinc` compiled the pure Kotlin domain subset (units, building model, mesh builder, history, planner operations, material calculations, component factories, specialist layout models, AI brief validation, settings/language models, offline GGUF file validation).
- A standalone executable pure-Kotlin smoke harness passed 13 assertions covering mm/ft/in conversions, real wall/opening triangle mesh generation, mesh array consistency, grid snapping, wall-volume calculation, tile quantity, component catalog, undo/redo, dimension annotation count, proportional opening resize, rotated plan hit-testing and multi-floor creation.
- `ModelJson` serializer/deserializer syntax was separately compiler-checked against lightweight JSON API stubs. This does not test Android's actual `org.json` runtime behavior.

## Not executed / not verified

- Gradle Android build, KAPT/Room code generation, Android lint and JUnit: no `gradle` executable is installed in this authoring environment.
- Android SDK, `sdkmanager` and `adb`: unavailable here.
- APK assembly, emulator test, phone installation and live GLES rendering: not executed.
- Full screen inventory implementation: only the app shell/dashboard, editor, project CRUD and component library foundation are active; other screen workflows remain pending.
- Full CAD acceptance: snap/alignment/measurement tools are only partially represented by domain helpers; 3D object picking, transform handles, dimension annotations in the live scene, 2D/3D round-trip tests, floor visibility/locking, and complete camera UX remain pending.
- Backup conflict handling and cross-device restore remain pending; current backup is bounded model JSON with checksum.
- PDF currently produces a multi-page dimension schedule; scaled architectural drawing sheets, dimension extension lines and visual PDF inspection remain pending.
- AI backend integration and GGUF inference are not implemented; no fake AI result is produced.

**Source snapshot:** `AI_Architecture_Phase1_Source_NOT_FINAL.zip` — ZIP integrity PASS; entry count and SHA-256 are supplied alongside the archive. The SHA-256 checksum is supplied alongside the archive. This is an intermediate source snapshot, not a release ZIP.

**Build status:** NOT VERIFIED. GitHub Actions must run successfully, then the APK must be installed and tested on the Android phone. `AI_ARCHITECTURE_FINAL_RELEASE.zip` has not been created.
