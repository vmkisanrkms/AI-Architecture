# Phase 2 — Screen Navigation, Local Project CRUD and Localization

**Base:** `AI_Architecture_Phase1_AUDITED_CONFIG_FIX.zip` only. The original ZIP was retained unchanged; work was extracted into a separate workspace.

## Source audit baseline
- ZIP integrity: PASS; 87 archive entries.
- 57 Kotlin source files: 36 main, 16 unit-test, 5 instrumentation-test.
- 21 screen rows and 22 section rows exist in traceability documentation.
- Original static verifier: 17/17 checks passed; 34/34 unique source target paths and 22/22 test target paths existed.
- Important audit finding: despite static target checks passing, the actual `AppNavHost` initially exposed only home, editor and projects routes. A trace row/source-file presence is not proof that the workflow is implemented.
- Android manifest has no `INTERNET` permission. The project uses compile/target SDK 36, min SDK 26, Java 17, Kotlin 2.0.21, AGP 8.10.0, Compose BOM 2024.12.01 and Room 2.6.1.
- No Gradle wrapper is included. The CI workflow provisions Gradle 8.11.1. Local Android SDK/Gradle build is not available in this environment.

## Implemented in Phase 2
- Added a typed, 21-entry `ScreenCatalog` preserving all original screen identities and the required component library screen.
- Replaced the 3-route shell with splash, language selection, dashboard, editor, project, component library and parameterized module routes.
- Added Hindi/English destination names and descriptions, with selected language persisted in app preferences.
- Added a native settings screen with persisted dark/light preference and language-change navigation.
- Added screen-specific validated input workflows for AI brief validation (no fabricated AI output), photo-processing consent (no upload initiated), architectural dimension validation and basic volume calculation.
- Enhanced local project management with name search, create, open, rename, duplicate and confirmed delete.
- Project duplication is transactional and copies floors/elements with new IDs and remapped floor references.
- Added `ScreenCatalogTest` covering exact count, IDs, route uniqueness and required CAD destinations.

## Files added/changed
- Added `feature/shell/ScreenCatalog.kt`
- Added `feature/shell/AppStrings.kt`
- Added `feature/shell/PhaseTwoScreens.kt`
- Added `test/.../ScreenCatalogTest.kt`
- Added `scripts/verify_phase2.py`
- Added this report
- Updated `navigation/AppNavHost.kt`, `MainActivity.kt`, `ui/theme/Theme.kt`, `feature/projects/ProjectsScreen.kt`, `data/repository/ProjectRepository.kt`, `docs/FEATURE_STATUS.md`, `docs/NEW_PROJECT_STATUS.md`, and `docs/TRACEABILITY_MATRIX.md`.

## Verification status
- Static Phase 2 checks: run separately using `python3 scripts/verify_phase2.py`.
- Kotlin catalog smoke compile: run with local `kotlinc` if available.
- Android Gradle compile, Room KAPT generation, JUnit, lint, emulator/device tests and visual UI verification: NOT RUN here.
- Screen destinations are now navigable, but several specialist screens still route to their feature workspace foundations; full specialist editors, photo picker, AI provider, offline inference, PDF/backup UI integration and live 3D acceptance remain later-phase work.
- No APK, GitHub upload or final-release archive has been created.

## Phase 2 close-out additions

- PDF route now opens `PdfExportScreen`, loads the latest Room-backed `BuildingModel`, invokes `DimensionedPdfExporter.render`, checks the PDF header and saves with Android's Storage Access Framework.
- Backup route now opens `BackupRestoreScreen`. Backup v2 stores model JSON and optional image attachments in a SHA-256 protected envelope. Restore validates checksum/size, saves the model into Room and writes attachments to app-private storage. The v1 model-only backup format remains readable.
- Duplicate project instrumentation coverage now checks project/floor/element identity changes and floor-reference remapping.
- Preference instrumentation coverage checks Hindi/English and dark/light SharedPreferences persistence. `coldStartDestination` skips the language chooser when a saved language exists; first run still starts at Splash.
- The 21 catalog routes now resolve to 21 distinct typed destinations. The generic Phase 2 workspace is no longer used by the navigation graph. Route-level Compose instrumentation test source covers all 21 catalog entries.
- PDF instrumentation source uses Android `PdfRenderer` to validate generated PDF structure/page geometry and pagination. Backup instrumentation source covers model/image round trip, payload/image corruption, v1 compatibility and Room persistence.
- All new Android tests are **authored but NOT executed** because this workspace has no Gradle executable, Gradle wrapper, Android SDK or adb. No Android build/test pass is claimed.
