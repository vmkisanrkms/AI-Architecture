# AI Architecture

Native Android application source project for architectural concept planning.

- **Application:** AI Architecture
- **Package:** `com.aiarchitecture.app`
- **Platform:** Native Android
- **Language/UI:** Kotlin + Jetpack Compose + Material 3
- **Architecture:** MVVM-oriented modular source boundaries
- **Local data:** Room / SQLite
- **Min SDK:** 26
- **Compile/Target SDK:** 36
- **Build JDK:** 17
- **Gradle:** 8.13 (bootstrapped and wrapped in CI)

## Development status
This is an active development workbench, not a final release. Read `FEATURE_STATUS.md`, `AUDIT_REPORT.md`, and `SECURITY_AUDIT.md`. A screen route or source file does not prove runtime completion. No feature is marked VERIFIED until its tests have executed.

## Implemented source areas
- Splash, home, language selection and settings/theme foundation.
- Room project records and calculation-history CRUD, migrations through schema v4 and database recovery.
- 2D floor-plan model, wall editing gestures, rooms, openings, stairs, dimensions, snapping, zoom/pan, undo/redo and save/load source.
- SceneView/Filament parametric 3D concept renderer source.
- Gate/arch/interior/kitchen/bathroom/boundary design specification forms.
- Brick, concrete, concrete mix, plaster mix, paint, tiles, steel, flooring and wall-area calculation logic.
- HTTPS online AI backend contract, upload progress/retry source, photo consent and private image storage.
- GGUF offline inference adapter using a community llama.cpp Android AAR; arm64-only device check, Wi-Fi download and SHA-256 validation.
- Multi-page Hindi/English PDF generation with local reference-image pages.
- JSON backup/restore with project records, calculation history, embedded local image bytes, checksum validation and conflict policies.
- GitHub Actions build, unit tests, Android lint, emulator instrumentation tests and conditional APK signing.

## Static source gate
Run `python3 scripts/verify_source.py` before building. It checks app identity, route registration, manifest network policy, source file presence and branding. It does not replace compilation, unit tests or device testing.

## Build
See `BUILD_INSTRUCTIONS.md`. The repository currently contains the wrapper scripts and properties but not the wrapper JAR. GitHub Actions bootstraps Gradle 8.13, generates the authentic wrapper, validates it and then builds. Local builds must first run `gradle wrapper --gradle-version 8.13 --distribution-type bin` with Gradle 8.13 installed.

## Online AI
Deploy an HTTPS backend matching `AI_BACKEND_CONTRACT.md`. Do not place provider API keys in the APK.

## Offline AI
Offline text generation requires a user-supplied compatible `.gguf` model, a publisher-provided SHA-256 checksum and licence acceptance. The selected CPU runtime currently supports arm64-v8a only. Model weights are not bundled and are not assumed to be free.

## Release signing
Configure GitHub Actions secrets `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, and `KEY_PASSWORD`. Without all four, the workflow deliberately produces only an unsigned release artifact and reports signing as pending.


## Mandatory 3D Architecture Designer requirement (2026-11-06)
The core product is a genuine editable 2D/3D architectural CAD workflow, not only an AI image generator. See `ARCHITECTURE_BLUEPRINT.md` for the required parametric geometry engine, exact dimensions and unit policy, editable component library, 2D↔3D synchronization, camera/navigation, measurement, annotations and dimensioned PDF export. All requirements are recorded as Pending implementation/verification until the original source is recovered and tests/build/device checks pass.
