# Release Acceptance Checklist

Nothing in this checklist is Verified until evidence is attached.

- [ ] All 21 screens have functional end-to-end workflows.
- [ ] All 22 sections have source/test coverage and requirement traceability.
- [ ] Canonical mm conversion tests pass for mm/m/in/ft.
- [ ] USER_ENTERED / DERIVED / ESTIMATED provenance survives Room and JSON backup.
- [ ] All geometry types are editable and regenerate live 3D meshes.
- [ ] Door/window openings are real wall voids with separate frame/leaf/glazing geometry.
- [ ] 2D and 3D edit the same stable-ID model and round-trip without drift.
- [ ] Grid, snap, alignment, precision, measurement, camera presets, pan/zoom/orbit work.
- [ ] Room CRUD, floor CRUD, autosave, undo/redo, backup/restore and migrations pass tests.
- [ ] Dimensioned PDF is inspected for scale, units, all pages, Estimated labels and Hindi/English glyphs.
- [ ] GitHub Actions unit tests, lint and APK assembly pass.
- [ ] APK installs and launches on the target Android phone.
- [ ] Actual 3D editing and camera manipulation pass on phone.
- [ ] No fake AI output, fake 3D view, placeholder action or static image substitution.
- [ ] Final ZIP inventory, integrity and SHA-256 are recorded.

Release status: **PENDING**.
