# Security Audit — AI Architecture

Audit date: 2026-11-06
Status: Manifest/source review only; no APK or runtime security test has been executed.

## Network permissions and online capability
- The current `app/src/main/AndroidManifest.xml` does **not** declare `android.permission.INTERNET`.
- No network permission has been added as part of this audit.
- Consequently, online AI/provider calls and remote model downloads are currently **disabled/unavailable** in this Android build. Any online AI backend contract or model-download notes are design/reference material only; they are not evidence of a working network feature.
- Do not add `INTERNET` permission without an explicit product/security decision and a separate review of network endpoints, TLS, authentication, privacy and data handling.
- The manifest also does not declare cleartext/network security configuration. Network transport behavior has not been runtime-tested.

## Controls visible in source (not runtime-verified)
- No provider API key or private signing key is hardcoded in the app source reviewed.
- Photo selection uses Android Photo Picker and the app includes an explicit per-upload consent flow.
- Photo and generated images are intended to be stored in app-private internal storage.
- JSON backup includes schema/model validation and checksum handling in source; backup/restore runtime behavior still requires Android tests.
- Android automatic cloud backup is disabled (`allowBackup=false`); user-controlled JSON backup is explicit.

## Remaining security work
- Local Room database is not encrypted at rest. Android app sandbox protects it from ordinary apps, but a rooted/compromised device may expose data.
- User-exported JSON backup is not encrypted; it can contain project prompts and embedded reference images. Users must store it securely.
- Online AI and remote model downloads are unavailable until explicitly authorized network permission and a separately reviewed implementation are added.
- Any future AI backend must enforce authentication, rate limits, file scanning, retention policy and provider-key isolation.
- Any future model downloader must validate publisher identity/signatures in addition to checksums; a checksum from an untrusted source does not prove publisher authenticity.
- Dependency vulnerability/SBOM audit has not run.
- APK permission, exported-component, network and signing audits have not run against a built APK.
- No penetration test, backup corruption device test or device privacy test has run.

## Conclusion
The manifest currently has no INTERNET permission. Online AI and remote model downloads must be treated as unavailable. No security control is marked VERIFIED until the Android build and corresponding automated/device tests run. This document is not a certification.
