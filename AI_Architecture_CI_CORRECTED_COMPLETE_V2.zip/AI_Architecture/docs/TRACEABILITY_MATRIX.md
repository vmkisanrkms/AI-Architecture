# Phase 0 — Requirement Traceability Matrix

**Status:** Baseline complete as a mapping artifact. All implementation and test execution statuses are **PENDING**.

This matrix retains all 21 screens and all 22 original sections. File paths are target implementation/test paths; a path listed here is not proof that the file exists or is implemented.

## A. Screen traceability (21 rows)

| # | Screen | Requirement coverage | Module | Source file | Test file | Status |
|---:|---|---|---|---|---|---|
| 1 | Splash Screen | Startup, app lifecycle and safe entry | `app-shell` | `app/src/main/java/com/aiarchitecture/app/navigation/AppNavHost.kt` | `app/src/androidTest/java/com/aiarchitecture/app/LaunchSmokeTest.kt; app/src/androidTest/java/com/aiarchitecture/app/ScreenRouteNavigationTest.kt; app/src/androidTest/java/com/aiarchitecture/app/ColdStartLanguageNavigationTest.kt` | **PENDING** |
| 2 | Language Selection | Hindi/English language preference and persistence | `language` | `app/src/main/java/com/aiarchitecture/app/feature/language/LanguageSettings.kt` | `app/src/test/java/com/aiarchitecture/app/core/LanguageSettingsTest.kt; app/src/androidTest/java/com/aiarchitecture/app/AppPreferencesPersistenceTest.kt; app/src/androidTest/java/com/aiarchitecture/app/ColdStartLanguageNavigationTest.kt` | **PENDING** |
| 3 | Home Dashboard | Navigation to all retained product modules | `dashboard` | `app/src/main/java/com/aiarchitecture/app/navigation/AppNavHost.kt` | `app/src/androidTest/java/com/aiarchitecture/app/LaunchSmokeTest.kt; app/src/androidTest/java/com/aiarchitecture/app/ScreenRouteNavigationTest.kt` | **PENDING** |
| 4 | AI Design Generator | Validated design brief; honest configured-provider response only | `ai-generator` | `app/src/main/java/com/aiarchitecture/app/feature/ai/DesignBrief.kt` | `app/src/test/java/com/aiarchitecture/app/core/DesignBriefValidationTest.kt` | **PENDING** |
| 5 | Photo Upload and Analysis | Photo picker, consent, MIME/size checks and local references | `photo-analysis` | `app/src/main/java/com/aiarchitecture/app/feature/photo/PhotoConsent.kt` | `app/src/androidTest/java/com/aiarchitecture/app/PhotoPickerConsentTest.kt` | **PENDING** |
| 6 | House Floor Planner | Project/floor creation and floor selection | `floor-planner` | `app/src/main/java/com/aiarchitecture/app/feature/planner/FloorPlanUseCases.kt` | `app/src/test/java/com/aiarchitecture/app/core/PlannerUseCasesTest.kt` | **PENDING** |
| 7 | 2D Blueprint Editor | Shared canonical model; 2D draw/select/move/resize/delete, grid/snap/dimensions/undo/redo/autosave | `blueprint-editor` | `app/src/main/java/com/aiarchitecture/app/feature/editor/BlueprintEditorScreen.kt` | `app/src/test/java/com/aiarchitecture/app/core/GeometryTest.kt` | **PENDING** |
| 8 | 3D House Designer | Real editable 3D solids, camera controls, mm dimensions and 2D↔3D sync | `building-3d-editor` | `app/src/main/java/com/aiarchitecture/app/feature/renderer/Building3DView.kt` | `app/src/androidTest/java/com/aiarchitecture/app/Building3DRenderingTest.kt` | **PENDING** |
| 9 | Gate Designer | Editable gate and pillar parametric components | `gate-designer` | `app/src/main/java/com/aiarchitecture/app/feature/components/GateComponent.kt` | `app/src/test/java/com/aiarchitecture/app/core/ComponentFactoryTest.kt` | **PENDING** |
| 10 | Arch Designer | Editable arch profiles and dimensions | `arch-designer` | `app/src/main/java/com/aiarchitecture/app/feature/components/ArchComponent.kt` | `app/src/test/java/com/aiarchitecture/app/core/ComponentFactoryTest.kt`; `app/src/test/java/com/aiarchitecture/app/core/GeometryTest.kt` | **PENDING** |
| 11 | Interior Designer | Interior object placement and dimensions | `interior-designer` | `app/src/main/java/com/aiarchitecture/app/feature/interior/InteriorLayout.kt` | `app/src/test/java/com/aiarchitecture/app/core/InteriorLayoutTest.kt` | **PENDING** |
| 12 | Kitchen Designer | Kitchen cabinets/appliances as editable geometry | `kitchen-designer` | `app/src/main/java/com/aiarchitecture/app/feature/kitchen/KitchenLayout.kt` | `app/src/test/java/com/aiarchitecture/app/core/KitchenLayoutTest.kt` | **PENDING** |
| 13 | Bathroom Designer | Bathroom fixtures as editable geometry | `bathroom-designer` | `app/src/main/java/com/aiarchitecture/app/feature/bathroom/BathroomLayout.kt` | `app/src/test/java/com/aiarchitecture/app/core/BathroomLayoutTest.kt` | **PENDING** |
| 14 | Boundary Wall Designer | Boundary walls, pillars and gates | `boundary-wall` | `app/src/main/java/com/aiarchitecture/app/feature/boundary/BoundaryWall.kt` | `app/src/test/java/com/aiarchitecture/app/core/BoundaryWallGeometryTest.kt` | **PENDING** |
| 15 | Material Calculator | Audited construction/material calculations and history | `material-calculator` | `app/src/main/java/com/aiarchitecture/app/feature/calculator/MaterialCalculations.kt` | `app/src/test/java/com/aiarchitecture/app/core/MaterialCalculationsTest.kt` | **PENDING** |
| 16 | My Projects and Gallery | Project CRUD, search, duplicate, gallery and local media | `projects-gallery` | `app/src/main/java/com/aiarchitecture/app/data/repository/ProjectRepository.kt` | `app/src/androidTest/java/com/aiarchitecture/app/ProjectCrudTest.kt; app/src/androidTest/java/com/aiarchitecture/app/ScreenRouteNavigationTest.kt` | **PENDING** |
| 17 | PDF Export and Reports | Dimensioned PDF from canonical geometry with provenance labels | `pdf-reports` | `app/src/main/java/com/aiarchitecture/app/feature/export/DimensionedPdfExporter.kt; app/src/main/java/com/aiarchitecture/app/feature/export/PdfExportScreen.kt` | `app/src/androidTest/java/com/aiarchitecture/app/DimensionedPdfExportTest.kt; app/src/androidTest/java/com/aiarchitecture/app/ScreenRouteNavigationTest.kt` | **PENDING** |
| 18 | Settings | Theme, language, privacy, precision and app preferences | `settings` | `app/src/main/java/com/aiarchitecture/app/feature/settings/AppSettings.kt; app/src/main/java/com/aiarchitecture/app/feature/shell/AppStrings.kt` | `app/src/test/java/com/aiarchitecture/app/core/ProjectConfigurationTest.kt; app/src/androidTest/java/com/aiarchitecture/app/AppPreferencesPersistenceTest.kt; app/src/androidTest/java/com/aiarchitecture/app/ScreenRouteNavigationTest.kt` | **PENDING** |
| 19 | Backup and Restore | Validated JSON backup/restore with checksums, image attachments and conflict handling | `backup-restore` | `app/src/main/java/com/aiarchitecture/app/feature/backup/BackupRestoreManager.kt; app/src/main/java/com/aiarchitecture/app/feature/backup/BackupRestoreScreen.kt` | `app/src/test/java/com/aiarchitecture/app/core/BackupTest.kt; app/src/androidTest/java/com/aiarchitecture/app/BackupRestoreIntegrationTest.kt; app/src/androidTest/java/com/aiarchitecture/app/ScreenRouteNavigationTest.kt` | **PENDING** |
| 20 | Offline AI Model Manager | Explicitly licensed local model lifecycle; no fake inference | `offline-model-manager` | `app/src/main/java/com/aiarchitecture/app/feature/offline/OfflineModelManager.kt` | `app/src/test/java/com/aiarchitecture/app/core/OfflineModelManagerTest.kt` | **PENDING** |
| 21 | Architecture Component Library & Properties Inspector (NEW) | Reusable component library, property inspector and geometry regeneration | `component-library` | `app/src/main/java/com/aiarchitecture/app/feature/components/ComponentLibraryScreen.kt` | `app/src/test/java/com/aiarchitecture/app/core/ComponentFactoryTest.kt`; `app/src/test/java/com/aiarchitecture/app/core/DimensionEngineTest.kt` | **PENDING** |

## B. Section traceability (22 rows)

| # | Original section | Linked screen(s) | Module | Source file(s) | Test file(s) | Status |
|---:|---|---|---|---|---|---|
| 1 | Project objective and delivery scope | 1,3,16,21 | `app-shell` | `app/src/main/java/com/aiarchitecture/app/navigation/AppNavHost.kt` | `app/src/androidTest/java/com/aiarchitecture/app/LaunchSmokeTest.kt; app/src/androidTest/java/com/aiarchitecture/app/ScreenRouteNavigationTest.kt` | **PENDING** |
| 2 | Fixed project configuration | 1–21 | `build` | `build.gradle.kts; app/build.gradle.kts` | `app/src/test/java/com/aiarchitecture/app/core/ProjectConfigurationTest.kt` | **PENDING** |
| 3 | Complete application screens | 1–21 | `navigation` | `app/src/main/java/com/aiarchitecture/app/navigation/AppNavHost.kt` | `app/src/androidTest/java/com/aiarchitecture/app/LaunchSmokeTest.kt` | **PENDING** |
| 4 | AI Design Generator | 4 | `ai-generator` | `app/src/main/java/com/aiarchitecture/app/feature/ai/DesignBrief.kt` | `app/src/test/java/com/aiarchitecture/app/core/DesignBriefValidationTest.kt` | **PENDING** |
| 5 | Online AI System | 4,5,18 | `ai-network` | `app/src/main/java/com/aiarchitecture/app/feature/ai/AiProvider.kt` | `app/src/androidTest/java/com/aiarchitecture/app/PhotoPickerConsentTest.kt` | **PENDING** |
| 6 | Offline AI System | 20 | `offline-model-manager` | `app/src/main/java/com/aiarchitecture/app/feature/offline/OfflineModelManager.kt` | `app/src/test/java/com/aiarchitecture/app/core/OfflineModelManagerTest.kt` | **PENDING** |
| 7 | 2D House Planner | 6,7,8,21 | `planner/editor` | `app/src/main/java/com/aiarchitecture/app/core/geometry/BuildingModel.kt; app/src/main/java/com/aiarchitecture/app/feature/editor/BlueprintEditorScreen.kt` | `app/src/test/java/com/aiarchitecture/app/core/PlannerUseCasesTest.kt`; `app/src/test/java/com/aiarchitecture/app/core/GeometryTest.kt` | **PENDING** |
| 8 | 3D Architecture Engine / SketchUp-class Editable Designer | 7,8,9,10,14,21 | `geometry/renderer` | `app/src/main/java/com/aiarchitecture/app/core/geometry/MeshBuilder.kt; app/src/main/java/com/aiarchitecture/app/feature/renderer/Building3DView.kt` | `app/src/test/java/com/aiarchitecture/app/core/GeometryTest.kt`; `app/src/test/java/com/aiarchitecture/app/core/DimensionEngineTest.kt`; `app/src/androidTest/java/com/aiarchitecture/app/Building3DRenderingTest.kt` | **PENDING** |
| 9 | Gate and Arch Designer | 9,10,14,21 | `components` | `app/src/main/java/com/aiarchitecture/app/feature/components/ArchitecturalComponents.kt` | `app/src/test/java/com/aiarchitecture/app/core/ComponentFactoryTest.kt`; `app/src/test/java/com/aiarchitecture/app/core/GeometryTest.kt` | **PENDING** |
| 10 | Interior Designer | 11,12,13 | `interior/kitchen/bathroom` | `app/src/main/java/com/aiarchitecture/app/feature/interior/InteriorLayout.kt` | `app/src/test/java/com/aiarchitecture/app/core/InteriorLayoutTest.kt` | **PENDING** |
| 11 | Material Calculator | 15 | `calculator` | `app/src/main/java/com/aiarchitecture/app/feature/calculator/MaterialCalculations.kt` | `app/src/test/java/com/aiarchitecture/app/core/MaterialCalculationsTest.kt` | **PENDING** |
| 12 | Database and Project Management | 6,16 | `database/projects` | `app/src/main/java/com/aiarchitecture/app/data/local/AppDatabase.kt; app/src/main/java/com/aiarchitecture/app/data/repository/ProjectRepository.kt` | `app/src/androidTest/java/com/aiarchitecture/app/ProjectCrudTest.kt` | **PENDING** |
| 13 | PDF Export | 7,8,17 | `export` | `app/src/main/java/com/aiarchitecture/app/feature/export/DimensionedPdfExporter.kt; app/src/main/java/com/aiarchitecture/app/feature/export/PdfExportScreen.kt` | `app/src/androidTest/java/com/aiarchitecture/app/DimensionedPdfExportTest.kt` | **PENDING** |
| 14 | Backup and Restore | 16,19 | `backup` | `app/src/main/java/com/aiarchitecture/app/feature/backup/BackupRestoreManager.kt; app/src/main/java/com/aiarchitecture/app/feature/backup/BackupRestoreScreen.kt` | `app/src/test/java/com/aiarchitecture/app/core/BackupTest.kt; app/src/androidTest/java/com/aiarchitecture/app/BackupRestoreIntegrationTest.kt` | **PENDING** |
| 15 | UI / UX Requirements | 1–21 | `design-system` | `app/src/main/java/com/aiarchitecture/app/ui/theme/Theme.kt` | `app/src/test/java/com/aiarchitecture/app/core/ProjectConfigurationTest.kt` | **PENDING** |
| 16 | Offline-first Rules | 16,19,20 | `local-first` | `app/src/main/java/com/aiarchitecture/app/data/local/AppDatabase.kt` | `app/src/androidTest/java/com/aiarchitecture/app/ProjectCrudTest.kt`; `app/src/test/java/com/aiarchitecture/app/core/BackupTest.kt` | **PENDING** |
| 17 | Security | 4,5,18,19,20 | `security` | `app/src/main/java/com/aiarchitecture/app/feature/photo/PhotoConsent.kt` | `app/src/androidTest/java/com/aiarchitecture/app/PhotoPickerConsentTest.kt` | **PENDING** |
| 18 | GitHub Actions | 1–21 | `ci` | ` .github/workflows/android-ci.yml` | `scripts/verify_project.py` | **PENDING** |
| 19 | Complete Testing | 1–21 | `testing` | `app/src/test; app/src/androidTest` | `app/src/test/java/com/aiarchitecture/app/core; app/src/androidTest/java/com/aiarchitecture/app` | **PENDING** |
| 20 | Final ZIP Delivery | 1–21 | `release` | `docs/RELEASE_ACCEPTANCE.md` | `docs/RELEASE_ACCEPTANCE.md` | **PENDING** |
| 21 | Strict Development Rules | 1–21 | `governance` | `docs/FEATURE_STATUS.md; docs/ARCHITECTURE_BLUEPRINT.md` | `scripts/verify_project.py` | **PENDING** |
| 22 | Final Acceptance Criteria | 1–21 | `acceptance` | `docs/RELEASE_ACCEPTANCE.md` | `docs/RELEASE_ACCEPTANCE.md` | **PENDING** |

## C. Cross-cutting CAD invariants

- Canonical storage unit is millimetres (`Double`); conversions: 1 in = 25.4 mm, 1 ft = 304.8 mm, 1 m = 1000 mm.
- Every dimension has provenance: `USER_ENTERED`, `DERIVED`, or `ESTIMATED`. Estimates must be visibly marked in editor and PDF.
- 2D plan and 3D scene are projections of the same stable-ID `BuildingModel`; no separate independent 2D/3D truth.
- Door/window openings are subtracted from wall solids and their frames/leaves/glazing are separate editable geometry.
- Property edits regenerate mesh data and dimension annotations; camera movement never changes geometry.
- All edit operations must be reversible and persist through Room/SQLite autosave.
- No static image may be used as the 3D editor or as evidence of geometry.

## D. Traceability acceptance

- [x] 21 screen requirements enumerated and mapped.
- [x] 22 section requirements enumerated and mapped.
- [x] Every row names a module, target source path and target test path.
- [ ] All target source files implemented.
- [ ] Unit tests executed successfully.
- [ ] Instrumentation tests executed on emulator/device.
- [ ] Android CI build passed.
- [ ] Live 3D interaction, PDF, backup/restore and phone acceptance passed.

**Phase 0 result:** Traceability mapping is complete; implementation and verification are not.
