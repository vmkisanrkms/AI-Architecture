# AI Architecture Phase 2 — Unit Test Failure Fix V1 Audit

Date: 2026-11-06  
Scope: Fix the four reported JVM unit-test failures without changing the production backup format or weakening model validation.

## Root-cause findings

### 1–2. `BackupTest` — `JSONObject.put` is not mocked
`ModelJson.encode()` and `BackupRestoreManager` use Android's `org.json.JSONObject` / `JSONArray`. Local Android JVM unit tests normally see mockable Android framework stubs, so calling `JSONObject.put()` can throw `Method ... not mocked`. This is a test-runtime dependency problem, not a backup-format defect.

**Fix:** Added `testImplementation("org.json:json:20240303")` to `app/build.gradle.kts`. This provides the real JVM `org.json` implementation only on the unit-test classpath. Production code and the v1/v2 JSON backup structure/checksum format were not changed.

`BackupTest.backupRoundTrip` now round-trips a populated model and checks project/floor, element dimensions, estimated provenance, rotation and opening values. `rejectsTamperedBackup` still expects `IllegalArgumentException` from the checksum guard and now verifies that its payload marker exists before mutating the payload.

### 3. `DimensionEngineTest` — `BuildingModel.addElement()` rejects a foreign floor
The test created `floor` from one `BuildingModel.starter()` instance and then called `addElement()` on a second, independent starter model. Each starter model creates a unique floor ID. `addElement()` correctly requires the target model to contain the element's `floorId`.

**Fix:** The test now creates one `base` model, obtains its floor from that model, and adds the element to that same model.

### 4. `GeometryTest.doorOpeningSegmentsWall` — same invalid fixture pattern
The wall used a floor ID from one starter model but was inserted into a second starter model.

**Fix:** The test now builds the wall from the floor owned by `base` and calls `base.addElement(wall)`. The production validation was intentionally retained.

## Validation invariant retained

`BuildingModel.addElement()` still contains:
`require(floors.any { it.id == element.floorId })`

Added `GeometryTest.addElementRejectsUnknownFloorId` to explicitly protect this invariant. No validation was removed or weakened.

## Suite inventory

- JVM unit test source files: 17 (retained)
- JVM unit test methods: 37 (36 reported before this patch + 1 invariant regression)
- Instrumentation test source files: 9 (retained)
- Instrumentation test methods: 19 (retained)
- All 21 Screens and 22 Sections remain in the traceability matrix.
- Existing 2D/3D CAD, Room, renderer, PDF, backup/restore and navigation source files remain.

## Static verification performed

- `verify_project.py`: 17/17
- `verify_phase2.py`: 9/9
- `verify_phase2_closeout.py`: 20/20
- `verify_build_readiness.py`: 35/35
- Main CI workflow YAML syntax: parsed successfully
- Mobile bootstrap workflow YAML syntax: parsed successfully
- Exact bootstrap ZIP filename and extraction paths: checked
- Existing production `BuildingModelStore.kt`, `BackupRestoreManager.kt`, `BuildingModel.kt` and backup wire-format implementation: unchanged from the incoming source ZIP.

## Runtime verification status — NOT RUN / PENDING

This execution environment has Java but does not have a Gradle executable, Gradle wrapper/wrapper JAR, Kotlin compiler, Android SDK, `sdkmanager`, or `adb`. Consequently, the following were **not run** and are not marked PASS:

- `:app:assembleDebug`
- Full `:app:testDebugUnitTest` suite (37 JVM test methods)
- `:app:lintDebug`
- Emulator `:app:connectedDebugAndroidTest` (19 instrumentation methods)

The GitHub Actions workflow already runs these tasks in sequence and uploads the test/build reports. Upload this ZIP to the repository root using the exact filename documented in `docs/MOBILE_GITHUB_UPLOAD_HI.md`, then run the workflow. The resulting Actions log/XML reports are required to establish actual runtime results.

No Phase 3, Release build, APK signing, or Final Release work was performed.
