#!/usr/bin/env python3
from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
catalog = root / "app/src/main/java/com/aiarchitecture/app/feature/shell/ScreenCatalog.kt"
nav = root / "app/src/main/java/com/aiarchitecture/app/navigation/AppNavHost.kt"
projects = root / "app/src/main/java/com/aiarchitecture/app/feature/projects/ProjectsScreen.kt"
repo = root / "app/src/main/java/com/aiarchitecture/app/data/repository/ProjectRepository.kt"
checks = {
    "21 screen catalog entries": len(re.findall(r'AppScreen\(\d+,', catalog.read_text())) == 21,
    "navigation uses typed route catalog": "ScreenCatalog.destination(route)" in nav.read_text(),
    "splash and language routes": all(x in nav.read_text() for x in ['composable("splash")','composable("language")']),
    "project search UI": "Search projects" in projects.read_text(),
    "project duplicate UI": "onDuplicate" in projects.read_text(),
    "project delete confirmation": "AlertDialog" in projects.read_text(),
    "transactional project duplication": "suspend fun duplicateProject" in repo.read_text() and "db.withTransaction" in repo.read_text(),
    "localized strings and persisted preference": "setLanguage" in (root / "app/src/main/java/com/aiarchitecture/app/feature/shell/AppStrings.kt").read_text(),
    "21-screen unit test source": (root / "app/src/test/java/com/aiarchitecture/app/core/ScreenCatalogTest.kt").is_file(),
}
for label, passed in checks.items(): print(("PASS" if passed else "FAIL") + " — " + label)
print(f"Phase 2 static checks: {sum(checks.values())}/{len(checks)}")
sys.exit(0 if all(checks.values()) else 1)
