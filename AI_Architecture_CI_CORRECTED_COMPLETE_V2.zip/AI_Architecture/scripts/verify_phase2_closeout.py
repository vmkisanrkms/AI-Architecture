#!/usr/bin/env python3
"""Static source wiring checks for Phase 2 close-out; not a substitute for Android tests."""
from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
read = lambda rel: (root / rel).read_text(encoding="utf-8")
catalog = read("app/src/main/java/com/aiarchitecture/app/feature/shell/ScreenCatalog.kt")
nav = read("app/src/main/java/com/aiarchitecture/app/navigation/AppNavHost.kt")
checks = {}
routes = re.findall(r'AppScreen\((\d+),"([^"]+)"', catalog)
checks["21 catalog rows with ordered IDs"] = [int(i) for i, _ in routes] == list(range(1, 22))
checks["21 unique catalog route strings"] = len({r for _, r in routes}) == 21
checks["21 unique typed destinations"] = len(set(re.findall(r'"[^"]+" -> ScreenDestination\.([A-Z_]+)', catalog))) == 21
checks["navigation uses typed destination resolver"] = "ScreenCatalog.destination(route)" in nav
checks["navigation has no generic workspace fallback"] = "ModuleWorkspaceScreen" not in nav
checks["PDF route opens dedicated PDF screen"] = "ScreenDestination.PDF_EXPORT -> PdfExportScreen" in nav
checks["Backup route opens dedicated backup screen"] = "ScreenDestination.BACKUP_RESTORE -> BackupRestoreScreen" in nav
checks["cold start uses persisted language policy"] = "AppStrings.coldStartDestination(context)" in nav
checks["PDF screen calls real exporter and SAF"] = "DimensionedPdfExporter.render" in read("app/src/main/java/com/aiarchitecture/app/feature/export/PdfExportScreen.kt") and "CreateDocument" in read("app/src/main/java/com/aiarchitecture/app/feature/export/PdfExportScreen.kt")
backup = read("app/src/main/java/com/aiarchitecture/app/feature/backup/BackupRestoreManager.kt")
backup_ui = read("app/src/main/java/com/aiarchitecture/app/feature/backup/BackupRestoreScreen.kt")
checks["backup v2 includes image attachments and checksum"] = all(x in backup for x in ["FORMAT_V2", "images", "sha256(checksumInput(payload, images))"])
checks["backup v1 compatibility remains"] = "FORMAT_V1" in backup and "FORMAT_V1 ->" in backup
checks["backup UI creates and restores actual bundles"] = "BackupRestoreManager.createBackup" in backup_ui and "BackupRestoreManager.restoreBundle" in backup_ui
checks["restored model and image files persisted"] = "store.save(restored.model)" in backup_ui and "restored-backup-images" in backup_ui
checks["duplicate project test checks remapping"] = "duplicateProjectCopiesFloorsAndElementsWithNewIdsAndRemappedFloorReferences" in read("app/src/androidTest/java/com/aiarchitecture/app/ProjectCrudTest.kt")
checks["PDF renderer output validation test exists"] = "PdfRenderer" in read("app/src/androidTest/java/com/aiarchitecture/app/DimensionedPdfExportTest.kt")
checks["backup image/corruption/round-trip tests exist"] = all(x in read("app/src/androidTest/java/com/aiarchitecture/app/BackupRestoreIntegrationTest.kt") for x in ["jsonBackupRoundTripsModelAndImageAttachmentsByteForByte", "corruptedModelPayloadIsRejected", "corruptedImageAttachmentIsRejectedByChecksum"])
checks["language and theme preference tests exist"] = all(x in read("app/src/androidTest/java/com/aiarchitecture/app/AppPreferencesPersistenceTest.kt") for x in ["languageAndColdStartDestinationPersistAcrossPreferenceReads", "darkAndLightThemePreferencesPersist"])
checks["cold-start navigation tests exist"] = "savedLanguageSkipsLanguageSelectionOnColdStart" in read("app/src/androidTest/java/com/aiarchitecture/app/ColdStartLanguageNavigationTest.kt")
checks["all 21 route instrumentation test exists"] = "allTwentyOneCatalogRoutesOpenTheirOwnRegisteredDestination" in read("app/src/androidTest/java/com/aiarchitecture/app/ScreenRouteNavigationTest.kt")
checks["offline manifest remains without INTERNET permission"] = "android.permission.INTERNET" not in read("app/src/main/AndroidManifest.xml")
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " — " + label)
print(f"Phase 2 close-out static checks: {sum(checks.values())}/{len(checks)}")
sys.exit(0 if all(checks.values()) else 1)
