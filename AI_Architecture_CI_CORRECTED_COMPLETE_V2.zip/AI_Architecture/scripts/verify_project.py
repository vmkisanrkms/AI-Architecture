#!/usr/bin/env python3
from pathlib import Path
import json, re, sys
root=Path(__file__).resolve().parents[1]
trace=json.loads((root/'docs/traceability.json').read_text())
checks=[]
def check(name,ok):
    checks.append((name,bool(ok)))
check('21 screen rows',len(trace['screens'])==21)
check('22 section rows',len(trace['sections'])==22)
check('all trace rows have source and test paths',all(x.get('source') and x.get('test') and x.get('module') for group in ('screens','sections') for x in trace[group]))
check('Android manifest exists',(root/'app/src/main/AndroidManifest.xml').exists())
check('native Kotlin entry exists',(root/'app/src/main/java/com/aiarchitecture/app/MainActivity.kt').exists())
check('canonical mm unit source exists',(root/'app/src/main/java/com/aiarchitecture/app/core/units/Units.kt').exists())
check('parametric mesh builder exists',(root/'app/src/main/java/com/aiarchitecture/app/core/geometry/MeshBuilder.kt').exists())
check('OpenGL ES live renderer exists',(root/'app/src/main/java/com/aiarchitecture/app/feature/renderer/Building3DView.kt').exists())
check('Room database source exists',(root/'app/src/main/java/com/aiarchitecture/app/data/local/AppDatabase.kt').exists())
check('backup/restore source exists',(root/'app/src/main/java/com/aiarchitecture/app/feature/backup/BackupRestoreManager.kt').exists())
check('dimensioned PDF source exists',(root/'app/src/main/java/com/aiarchitecture/app/feature/export/DimensionedPdfExporter.kt').exists())
check('GitHub Actions workflow exists',(root/'.github/workflows/android-ci.yml').exists())
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
check('offline CAD manifest has no INTERNET permission','android.permission.INTERNET' not in manifest)
check('all Kotlin package declarations use app namespace',all('package com.aiarchitecture.app' in p.read_text(errors='ignore') for p in (root/'app/src/main/java').rglob('*.kt')))
main_count=len(list((root/'app/src/main/java').rglob('*.kt')))
unit_count=len(list((root/'app/src/test').rglob('*.kt')))
instrumentation_count=len(list((root/'app/src/androidTest').rglob('*.kt')))
check('36 or more real main Kotlin source files',main_count>=36)
check('16 or more unit test source files',unit_count>=16)
check('5 or more instrumentation test source files',instrumentation_count>=5)
source_targets=[]; test_targets=[]
for row in trace['screens']+trace['sections']:
    source_targets += [x.strip() for x in row['source'].split(';') if x.strip()]
    test_targets += [x.strip() for x in row['test'].split(';') if x.strip()]
missing_sources=sorted({x for x in source_targets if not (root/x).exists()})
missing_tests=sorted({x for x in test_targets if not (root/x).exists()})
print(f'Trace source targets present: {len(set(source_targets))-len(missing_sources)}/{len(set(source_targets))} unique target paths')
print(f'Trace test targets present: {len(set(test_targets))-len(missing_tests)}/{len(set(test_targets))} unique target paths')
print(f'Unimplemented source targets (pending): {len(missing_sources)}; missing test targets (pending): {len(missing_tests)}')
for name,ok in checks: print(('PASS' if ok else 'FAIL')+' — '+name)
failed=[n for n,ok in checks if not ok]
print(f'Static source checks: {len(checks)-len(failed)}/{len(checks)} passed')
sys.exit(1 if failed else 0)
