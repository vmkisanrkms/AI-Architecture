#!/usr/bin/env python3
import argparse
import pathlib
import sys
import xml.etree.ElementTree as ET

p = argparse.ArgumentParser(description="Verify generated Android APKs and JUnit XML reports")
p.add_argument("--project-root", required=True)
p.add_argument("--status-dir", required=True)
a = p.parse_args()
root = pathlib.Path(a.project_root)
status = pathlib.Path(a.status_dir)
app = root / "app" / "build"
errors = []

def require_file(label, path):
    if path.is_file() and path.stat().st_size > 0:
        print(f"{label}=PASS bytes={path.stat().st_size}")
    else:
        print(f"{label}=FAIL missing_or_empty={path}")
        errors.append(label)

def verify_xml(label, folders):
    files = sorted({f for folder in folders if folder.exists() for f in folder.rglob("TEST-*.xml") if f.is_file()})
    if not files:
        print(f"{label}_XML=FAIL no TEST-*.xml files found")
        errors.append(label + "_XML_MISSING")
        return
    totals = {"tests": 0, "failures": 0, "errors": 0, "skipped": 0}
    for f in files:
        try:
            r = ET.parse(f).getroot()
            suites = [r] if r.tag == "testsuite" else list(r.iter("testsuite"))
            if not suites:
                raise ValueError("no testsuite elements")
            for s in suites:
                for key in totals:
                    totals[key] += int(s.attrib.get(key, "0"))
        except Exception as e:
            print(f"{label}_XML_PARSE_ERROR={f}: {e}")
            errors.append(label + "_XML_PARSE")
    print(f"{label}_XML_FILES={len(files)} " + " ".join(f"{k.upper()}={v}" for k, v in totals.items()))
    if totals["tests"] <= 0 or totals["failures"] or totals["errors"]:
        errors.append(label + "_TEST_COUNTS")

require_file("DEBUG_APK", app / "outputs/apk/debug/app-debug.apk")
require_file("ANDROID_TEST_APK", app / "outputs/apk/androidTest/debug/app-debug-androidTest.apk")
verify_xml("JVM_UNIT", [app / "test-results/testDebugUnitTest"])
verify_xml("INSTRUMENTATION", [app / "outputs/androidTest-results/connected/debug", app / "outputs/androidTest-results"])
marker = status / "emulator-part-3.txt"
if marker.is_file() and marker.read_text().strip() == "PASS":
    print("INSTRUMENTATION_EXECUTION=PASS")
else:
    print("INSTRUMENTATION_EXECUTION=FAIL (emulator test task did not record PASS)")
    errors.append("INSTRUMENTATION_EXECUTION")
if errors:
    print("REPORT_VERIFICATION=FAIL " + ",".join(errors))
    sys.exit(1)
print("REPORT_VERIFICATION=PASS")
