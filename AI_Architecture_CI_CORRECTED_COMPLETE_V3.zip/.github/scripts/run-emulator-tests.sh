#!/usr/bin/env bash
set -Eeuo pipefail

: "${PROJECT_ROOT:?PROJECT_ROOT is not set}"
: "${STATUS_DIR:?STATUS_DIR is not set}"
: "${ANDROID_HOME:?ANDROID_HOME is not set}"

mkdir -p "$STATUS_DIR"

ADB="$ANDROID_HOME/platform-tools/adb"
if [[ ! -x "$ADB" ]]; then
  ADB="$(command -v adb || true)"
fi
if [[ -z "$ADB" || ! -x "$ADB" ]]; then
  echo "::error::adb executable not found"
  exit 1
fi

mark() {
  printf '%s\n' "$2" > "$STATUS_DIR/emulator-part-$1.txt"
}

SERIAL="${ANDROID_SERIAL:-}"

collect_diagnostics() {
  local rc=$?
  trap - EXIT
  set +e

  printf 'SCRIPT_EXIT_CODE=%s\nANDROID_SERIAL=%s\n' \
    "$rc" "${SERIAL:-not-detected}" \
    > "$STATUS_DIR/emulator-exit.txt"

  "$ADB" devices -l > "$STATUS_DIR/adb-devices.txt" 2>&1

  if [[ -n "$SERIAL" ]]; then
    "$ADB" -s "$SERIAL" logcat -d -b all -v threadtime \
      > "$STATUS_DIR/emulator-logcat.txt" 2>&1
    "$ADB" -s "$SERIAL" shell dumpsys package \
      > "$STATUS_DIR/package-dumpsys.txt" 2>&1
    "$ADB" -s "$SERIAL" shell dumpsys activity processes \
      > "$STATUS_DIR/activity-processes.txt" 2>&1
    "$ADB" -s "$SERIAL" shell getprop \
      > "$STATUS_DIR/device-getprop.txt" 2>&1
  else
    "$ADB" logcat -d -b all -v threadtime \
      > "$STATUS_DIR/emulator-logcat.txt" 2>&1
  fi

  grep -E -i \
    'FATAL EXCEPTION|AndroidRuntime|INSTALL_FAILED|Process .* has died|am_crash|Instrumentation.*(crash|failed)|ANR in |Integrity verification' \
    "$STATUS_DIR/emulator-logcat.txt" \
    > "$STATUS_DIR/crash-summary.txt" 2>&1 || true

  mark 6 DIAGNOSTICS_COLLECTED
  exit "$rc"
}
trap collect_diagnostics EXIT

# Part 1: wait until the emulator is online.
mark 1 STARTED
for attempt in $(seq 1 120); do
  if [[ -z "$SERIAL" ]]; then
    SERIAL="$("$ADB" devices | awk 'NR > 1 && $1 ~ /^emulator-/ {print $1; exit}')"
  fi

  if [[ -n "$SERIAL" ]]; then
    state="$("$ADB" devices | awk -v serial="$SERIAL" '$1 == serial {print $2; exit}')"
    if [[ "$state" == "device" ]]; then
      break
    fi
    if [[ "$state" == "offline" ]]; then
      "$ADB" reconnect offline >/dev/null 2>&1 || true
    fi
  fi
  sleep 5
done

if [[ -z "$SERIAL" ]]; then
  mark 1 FAIL
  echo "::error::No emulator serial detected"
  exit 1
fi

state="$("$ADB" devices | awk -v serial="$SERIAL" '$1 == serial {print $2; exit}')"
if [[ "$state" != "device" ]]; then
  mark 1 FAIL
  echo "::error::Emulator ADB state is $state"
  exit 1
fi
mark 1 PASS

# Part 2: wait for Android framework and Package Manager.
mark 2 STARTED
booted=0
for attempt in $(seq 1 120); do
  value="$("$ADB" -s "$SERIAL" shell getprop sys.boot_completed 2>/dev/null | tr -d '\r' || true)"
  if [[ "$value" == "1" ]]; then
    booted=1
    break
  fi
  sleep 5
done

if [[ "$booted" != "1" ]]; then
  mark 2 FAIL
  echo "::error::Android boot did not complete"
  exit 1
fi

api="$("$ADB" -s "$SERIAL" shell getprop ro.build.version.sdk | tr -d '\r')"
if [[ "$api" != "35" ]]; then
  mark 2 FAIL
  echo "::error::Expected API 35, got $api"
  exit 1
fi

# Wait for boot animation to stop, without failing if property is unavailable.
for attempt in $(seq 1 60); do
  anim="$("$ADB" -s "$SERIAL" shell getprop init.svc.bootanim 2>/dev/null | tr -d '\r' || true)"
  [[ "$anim" == "stopped" || -z "$anim" ]] && break
  sleep 2
done

pm_ready=0
for attempt in $(seq 1 30); do
  if "$ADB" -s "$SERIAL" shell pm path android >/dev/null 2>&1; then
    pm_ready=1
    break
  fi
  sleep 2
done

if [[ "$pm_ready" != "1" ]]; then
  mark 2 FAIL
  echo "::error::Package Manager did not become ready"
  exit 1
fi
mark 2 PASS

# Part 3: stabilize the disposable CI emulator package installer.
mark 3 STARTED
"$ADB" -s "$SERIAL" shell settings put global window_animation_scale 0 || true
"$ADB" -s "$SERIAL" shell settings put global transition_animation_scale 0 || true
"$ADB" -s "$SERIAL" shell settings put global animator_duration_scale 0 || true

# Disable ADB package verification on this disposable test-only emulator.
# This does not modify the app or the repository manifest.
"$ADB" -s "$SERIAL" shell settings put global package_verifier_enable 0 || true
"$ADB" -s "$SERIAL" shell settings put global verifier_verify_adb_installs 0 || true
"$ADB" -s "$SERIAL" shell settings put global verifier_default_response 1 || true

# Confirm the settings were applied and capture installer state.
"$ADB" -s "$SERIAL" shell settings get global package_verifier_enable \
  > "$STATUS_DIR/package-verifier-setting.txt" 2>&1 || true
"$ADB" -s "$SERIAL" shell settings get global verifier_verify_adb_installs \
  >> "$STATUS_DIR/package-verifier-setting.txt" 2>&1 || true
"$ADB" -s "$SERIAL" shell dumpsys package > "$STATUS_DIR/package-before-tests.txt" 2>&1 || true

cd "$PROJECT_ROOT"

# Part 4/5: run the real Gradle connected instrumentation task.
# Retry once to tolerate a transient first-install / emulator verification timeout.
run_instrumentation() {
  local logfile="$1"
  set +e
  gradle --no-daemon --stacktrace :app:connectedDebugAndroidTest 2>&1 | tee "$logfile"
  local task_rc=${PIPESTATUS[0]}
  set -e
  return "$task_rc"
}

if run_instrumentation "$STATUS_DIR/instrumentation-attempt-1.log"; then
  mark 3 PASS
  mark 4 PASS
  mark 5 PASS
  echo "CONNECTED_DEBUG_ANDROID_TEST=PASS"
else
  first_rc=$?
  echo "::warning::Instrumentation attempt 1 failed (exit $first_rc); retrying once"

  "$ADB" reconnect "$SERIAL" >/dev/null 2>&1 || true
  sleep 10

  state="$("$ADB" devices | awk -v serial="$SERIAL" '$1 == serial {print $2; exit}')"
  if [[ "$state" != "device" ]]; then
    echo "::error::Emulator became unavailable before retry"
    mark 3 FAIL
    mark 4 FAIL
    mark 5 FAIL
    exit "$first_rc"
  fi

  if run_instrumentation "$STATUS_DIR/instrumentation-attempt-2.log"; then
    mark 3 PASS
    mark 4 PASS
    mark 5 PASS
    echo "CONNECTED_DEBUG_ANDROID_TEST=PASS_ON_RETRY"
  else
    retry_rc=$?
    mark 3 FAIL
    mark 4 FAIL
    mark 5 FAIL
    echo "::error::connectedDebugAndroidTest failed on both attempts"
    echo "FIRST_ATTEMPT_EXIT=$first_rc"
    echo "RETRY_EXIT=$retry_rc"
    exit "$retry_rc"
  fi
fi
