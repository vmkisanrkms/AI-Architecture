package com.aiarchitecture.app

import android.content.Context
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ColdStartLanguageNavigationTest {

    // Launch MainActivity manually, after setting preferences and before onCreate().
    @get:Rule
    val composeRule = createEmptyComposeRule()

    private fun clearPreferences(context: Context) {
        context.getSharedPreferences(
            "ai_architecture_preferences",
            Context.MODE_PRIVATE
        ).edit().clear().commit()
    }

    @Test
    fun savedLanguageSkipsLanguageSelectionOnColdStart() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        clearPreferences(context)
        context.getSharedPreferences(
            "ai_architecture_preferences",
            Context.MODE_PRIVATE
        ).edit().putString("language", "en").commit()

        val scenario = ActivityScenario.launch(MainActivity::class.java)
        try {
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("destination-home", useUnmergedTree = true).assertExists()
            composeRule.onNodeWithText("Native architectural design workspace").assertExists()
        } finally {
            scenario.close()
        }
    }

    @Test
    fun firstLaunchWithoutSavedLanguageShowsSplash() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        clearPreferences(context)

        val scenario = ActivityScenario.launch(MainActivity::class.java)
        try {
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("destination-splash", useUnmergedTree = true).assertExists()
        } finally {
            scenario.close()
        }
    }
}
