package com.aiarchitecture.app

import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.aiarchitecture.app.feature.shell.ScreenCatalog
import com.aiarchitecture.app.navigation.AppNavHost
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ScreenRouteNavigationTest {

    // Use the Compose test host; do not launch MainActivity, which already calls setContent().
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun allTwentyOneCatalogRoutesOpenTheirOwnRegisteredDestination() {
        lateinit var chooseStart: (String) -> Unit

        composeRule.setContent {
            var startRoute by remember { mutableStateOf("splash") }
            SideEffect { chooseStart = { route -> startRoute = route } }
            key(startRoute) {
                val start = when (startRoute) {
                    "splash", "language", "home" -> startRoute
                    else -> "screen/$startRoute"
                }
                AppNavHost(startDestinationOverride = start)
            }
        }

        composeRule.waitForIdle()
        ScreenCatalog.all.forEach { screen ->
            composeRule.runOnIdle { chooseStart(screen.route) }
            composeRule.waitForIdle()
            composeRule.onNodeWithTag(
                "destination-${screen.route}",
                useUnmergedTree = true
            ).assertExists()
        }
    }
}
