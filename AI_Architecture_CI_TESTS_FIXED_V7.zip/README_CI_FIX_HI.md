# AI Architecture CI Fix Bundle (V3)

## Included
- Full original `AI_Architecture/` Android project source (unchanged).
- Updated `.github/workflows/android-ci.yml`.
- Updated `.github/scripts/run-emulator-tests.sh`.
- Existing `ci/verify-test-reports.py`.
- Existing project verifiers and documentation.

## Fixes
1. Keeps the direct Android SDK `sdkmanager` setup; does not request the obsolete `tools` package.
2. Keeps the API 35 Google APIs x86_64 emulator.
3. Uses a fresh emulator (`-no-snapshot -wipe-data`) for each CI run.
4. Waits for ADB device state, Android boot completion, boot animation completion, and Package Manager readiness.
5. Disables package-verifier settings on the disposable CI emulator before instrumentation installation.
6. Retries `:app:connectedDebugAndroidTest` once after a first failure and preserves the original failure logs.
7. Preserves the `emulator-part-3.txt = PASS` marker contract used by `ci/verify-test-reports.py`.
8. Collects ADB, logcat, package, process and getprop diagnostics on exit.

## Validation performed
- ZIP integrity: checked.
- YAML syntax: parsed with PyYAML BaseLoader.
- Workflow inline Bash blocks: 10/10 pass `bash -n`.
- Emulator script: passes `bash -n`.
- Python report verifier: passes `py_compile`.
- Project static verifiers: verify_project 17/17, verify_phase2 9/9, verify_phase2_closeout 20/20, build-readiness 35/35.

## Important limitation
These are static/source validations only. This environment did not run GitHub Actions, Android SDK, emulator, APK installation, or instrumentation tests. The Android package-verification timeout fix must be confirmed by the next GitHub Actions run. The Android application source and manifest were not modified.

## V5 Emulator correction

V5 replaces reactivecircus/android-emulator-runner with direct AVD creation and emulator launch. The workflow waits separately for ADB online, Android framework boot completion, API 35, and Package Manager readiness before running the existing instrumentation script. This is a CI-side change; Android application source and manifest are unchanged. Runtime success must be confirmed by GitHub Actions.
