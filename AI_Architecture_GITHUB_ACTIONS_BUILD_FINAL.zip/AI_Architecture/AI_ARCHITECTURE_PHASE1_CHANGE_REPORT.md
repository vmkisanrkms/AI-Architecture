# AI Architecture Phase 1 — Persistence Hardening V2 Change Report

Date: 2026-11-07
Status: **SOURCE PACKAGE UPDATED — NOT ACCEPTED / NOT PASS**

## 1. Scope and preservation
- Applied only the accepted Phase 1 Independent Audit findings.
- Did not start Component Properties Inspector or Editing Commands.
- Embedded original V7 source archive retained byte-for-byte.
- V3 `ParametricComponent.kt` and `ParametricComponentTest.kt` retained byte-for-byte in `preserved/V3_domain_overlay/`.
- Existing application feature source files were not intentionally removed.
- Android build, Gradle wrapper bootstrap, APK generation, emulator and GitHub CI remain deferred.

## 2. Source changes
### Room schema
- Database version advanced from 2 to 3.
- `MIGRATION_1_2` remains responsible for creating the four component tables and nine component indexes.
- Added `MIGRATION_2_3`: creates a unique supporting index on `floors(projectId,id)`, rebuilds `component_definitions` with two default-reference foreign keys, then rebuilds `component_instances` and copies all existing component rows. It adds seven logical foreign-key constraints:
  1. `defaultMaterialId → component_materials.id`
  2. `defaultProfileId → component_profiles.id`
  3. `projectId → projects.id`
  4. `(projectId,floorId) → floors(projectId,id)`
  5. `definitionId → component_definitions.id`
  6. `profileId → component_profiles.id`
  7. `materialId → component_materials.id`
- Definition defaults and instance references all use `ON DELETE RESTRICT`. The composite floor FK prevents an instance from combining a project with another project's floor.
- All original nine component indexes remain. Two additional indexes support definition default-profile/material foreign keys. The supporting legacy-floor composite index is additional and is not counted as a component index.
- If a pre-existing v2 component row has a dangling reference, v2→v3 migration fails transactionally rather than silently discarding or rewriting the row. Such data must be repaired explicitly before retrying migration.

### Persistence boundary
- Single-instance and bulk replacement paths now share the same validation for project, project-owned floor, definition, component constraints, profile and material references.
- `replaceProjectInstances` rejects blank/duplicate IDs before its delete/insert transaction.
- `BuildingModelStore.save` performs the same duplicate-ID preflight before opening its transaction.
- Component instances are deleted before floor replacement to respect `RESTRICT` foreign keys; the model, floors, elements, components and history snapshot are then written atomically.
- Definition key collision with a different definition ID is rejected; same-ID updates use Room `@Update` (not destructive `REPLACE`) so referenced rows can be edited without deleting their parent keys. Profile/material same-ID updates use the same non-destructive update path.
- Delete policy is **RESTRICT** for referenced profiles/materials/definitions. Definition default profile/material references are protected by database foreign keys and transactional `ComponentPersistence` validation; instance references are protected by database foreign keys and the same repository validation. Built-in definitions are non-deletable.
- Legacy JSON snapshots lacking componentInstances/floors/elements/openings decode those collections as empty rather than failing solely due to those absent arrays.

## 3. New/expanded tests — purpose and expected result
File: `ComponentPersistenceRoundTripTest.kt`

| Test | Purpose | Expected result |
|---|---|---|
| `allFourTablesRoundTripThroughRoomDaos` | Persist and reload Definition, Instance, Profile and Material via Room | Every persisted domain object equals its original |
| `profilePointOrderAndProfileMetadataSurviveDatabaseRoundTrip` | Verify ordered profile vertices and profile-level metadata | Points remain in exact order; kind, closed, thickness and revision remain unchanged |
| `buildingModelStoreSavesAndLoadsComponentInstances` | Exercise BuildingModelStore and edit-history snapshot path | Loaded model and decoded history snapshot equal the saved model |
| `legacySnapshotWithoutComponentInstancesRemainsReadable` | Decode a pre-component snapshot fixture | Decode succeeds and componentInstances is empty |
| `duplicateInstanceIdsAreRejectedBeforeReplacingExistingRows` | Verify duplicate IDs are rejected before destructive save | Existing persisted component remains unchanged |
| `referencedProfileMaterialAndDefinitionDeletionIsRestricted` | Verify instance references block deletes and same-ID updates | Deletes fail; same-ID edits update rows while retaining instance references |
| `danglingReferencesAreRejectedBySingleAndBulkPersistencePaths` | Verify shared reference validation | Single save and BuildingModel bulk save fail; no component rows are committed |
| `definitionDefaultsAndFloorReferencesAreValidated` | Validate default references and project-owned floor | Invalid defaults/wrong floor fail; no component row is committed |
| `definitionDefaultProfileAndMaterialReferencesRestrictDeletion` | Verify definition default references block profile/material deletion | Both delete attempts fail |
| `definitionKeyCannotSilentlyReplaceDifferentDefinitionId` | Protect unique definition key from destructive REPLACE collision | Collision fails and original owner remains |

File: `ComponentDatabaseMigrationTest.kt`
- Expanded to assert preservation of Projects, Floors, Building Elements and Edit History.
- Asserts all four component tables and all nine original component indexes plus the two default-reference indexes and the composite floor/project index.
- Asserts the supporting `index_floors_projectId_id` index.
- Asserts seven logical foreign keys (two definition defaults and five instance references; six PRAGMA rows for instances because project+floor is composite).
- Expected result: migration from a v1 fixture to v3 retains every legacy row and installs the complete schema.

## 4. Source inventory
- JVM source: 19 files / 62 `@Test` annotations (unchanged).
- Instrumentation source: 11 files / 30 `@Test` annotations (10 in new round-trip file + 1 migration test; other existing instrumentation tests retained).
- These are source annotation counts only, not executed results.

## 5. Validation actually performed
- ZIP integrity: performed after packaging.
- Source-level structural assertions: performed for schema version, migration chain, foreign keys, DAO validation, duplicate preflight, tests and preserved source hashes.
- SQLite simulation: `scripts/verify_phase1_sqlite_migrations.py` executed 13 extracted SQL statements for v1→v2 and 17 for v2→v3 against a legacy fixture. Preserved one row each in projects, floors, building_elements and edit_history; verified four component tables, all nine original component indexes plus two definition-reference indexes, the supporting floor index, seven logical foreign keys, invalid/mismatched floor and definition insertion rejection, cross-project floor rejection, and RESTRICT profile/material deletion (five negative cases). Output is retained in `docs/PHASE1_SQLITE_SIMULATION_RESULTS.txt`.
- SQLite simulation is not Room runtime, KAPT schema validation, Kotlin compilation, JVM JUnit execution or Android instrumentation execution.

## 6. Not performed / pending
- Kotlin/Android compilation: NOT RUN.
- JVM JUnit execution: NOT RUN.
- Room instrumentation execution: NOT RUN.
- Android build/APK/emulator/GitHub CI: DEFERRED by project direction.
- Room-generated schema identity still requires a later Android/Gradle validation run.

## 7. Decision
**Phase 1 remains PENDING. Do not declare PASS or Completed.** This package is ready for independent source review only. Do not start Inspector or Editing Commands until the source changes are independently audited and the pending Android tests can later be executed.
