# AI Architecture – Phase 1 Persistence Hardening V3 Change Report

## Scope
Only the two remaining independent-audit findings were addressed. No Component Properties Inspector, editing commands, Gradle Wrapper, Android Build, APK, or GitHub CI work was started.

## 1. Legacy Snapshot Compatibility
File: `app/src/androidTest/java/com/aiarchitecture/app/data/ComponentPersistenceRoundTripTest.kt`

Added four independent tests:

| Test | Input omission | Expected result |
|---|---|---|
| `legacySnapshotWithoutComponentInstancesDecodesToEmptyComponentCollection` | root `componentInstances` | `componentInstances.isEmpty()` |
| `legacySnapshotWithoutFloorsDecodesToEmptyFloorCollection` | root `floors` | `floors.isEmpty()` |
| `legacyFloorWithoutElementsDecodesToEmptyElementCollection` | floor `elements` | decoded floor exists; its `elements` is empty |
| `legacyElementWithoutOpeningsDecodesToEmptyOpeningCollection` | element `openings` | decoded element exists; its `openings` is empty |

All four use independent legacy JSON fixtures to prevent one omitted field from masking another.

## 2. Direct DAO Write Safety
File: `app/src/main/java/com/aiarchitecture/app/data/local/AppDatabase.kt`

- Removed `REPLACE` conflict behavior from all four component DAOs.
- New-row operations are explicitly named `insertNew` / `insertNewAll` and use `OnConflictStrategy.ABORT`.
- Same-ID modifications are explicit `@Update updateExisting(...)` operations returning affected-row count.
- DAO KDoc marks these as low-level repository-only APIs. UI/ViewModels must use `ComponentPersistence` / `BuildingModelStore` rather than writing through DAOs.
- Existing FK definitions and `ON DELETE RESTRICT` behavior are unchanged.

File: `app/src/main/java/com/aiarchitecture/app/data/repository/ComponentPersistence.kt`

- Create path uses `insertNew`.
- Existing ID path uses `updateExisting` and requires exactly one affected row.
- Instance insert and bulk insert use ABORT semantics.
- Existing BuildingModelStore transactional replacement remains the only bulk replacement workflow; duplicate IDs are rejected before its destructive transaction.

Added three direct DAO tests:
- Duplicate Definition ID insert aborts and preserves original; explicit update changes it.
- Duplicate Profile and Material ID inserts abort and preserve originals; explicit updates change them.
- Duplicate Instance ID insert aborts and preserves original; explicit update changes it.

## 3. Test Inventory (Source Only)
- JVM: 19 Kotlin files / 62 `@Test` annotations.
- Instrumentation: 11 Kotlin files / 36 `@Test` annotations.
- These are source inventory counts, not test execution results.

## 4. Validation Actually Performed
- ZIP integrity: to be checked on final archive.
- Static source scan: verified no `REPLACE` conflict strategy remains in the four component DAO declarations.
- SQLite migration simulation rerun: `SQLITE_SIMULATION_OK`.
  - v1→v2: 13 SQL statements.
  - v2→v3: 17 SQL statements.
  - One legacy record each preserved in projects, floors, building_elements, edit_history.
  - Four component tables, nine original component indexes, two additional FK indexes, floor/project composite index, seven logical FK relationships verified.
  - Five invalid-reference FK negative cases rejected.
- Android Room/JUnit tests were NOT executed.
- Kotlin/Android compilation was NOT executed.

## 5. Preserved Inputs
- Original V7 archive remains embedded byte-for-byte unchanged.
- V3 domain overlay source files remain embedded byte-for-byte unchanged.
- No pre-existing application feature was intentionally removed.

## Status
Phase 1 remains **PENDING independent final source audit**. No PASS or Completed claim is made.
