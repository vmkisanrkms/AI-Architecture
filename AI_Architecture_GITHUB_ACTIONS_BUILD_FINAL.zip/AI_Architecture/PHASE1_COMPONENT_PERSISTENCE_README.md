# AI Architecture — Phase 1: Component Persistence + BuildingModel Integration

## Scope
This development package starts the feature-first development track. It intentionally does **not** run or configure Gradle Wrapper generation, Android builds, APK packaging, release signing, emulator verification, or GitHub CI.

## Source lineage and preservation
- The working application tree is based on the Phase 2 domain foundation, with the exact V3 `ParametricComponent.kt` and `ParametricComponentTest.kt` overlay applied.
- The original `AI_Architecture_CI_TESTS_FIXED_V7.zip` is included unchanged under `preserved/`.
- The exact V3 domain source and test overlay are included under `preserved/V3_domain_overlay/`.
- V7 is not edited by this package.

## Implemented in this phase
1. Room schema version advanced from 1 to 2.
2. Added Room entities and DAOs for component definitions, component instances, custom profiles, and materials.
3. Added explicit `MIGRATION_1_2` that creates only the four new component tables and indexes; it does not drop or rewrite the existing project/floor/element/history tables.
4. Centralized database construction in `AppDatabase.open(context)` and registered the migration at every app database entry point.
5. Added `ComponentPersistence` for catalogue, instance, profile, and material persistence. Definitions validate unique keys/IDs and constraint references; instances validate definitions, values, profile/material references, project and floor ownership.
6. Added built-in component catalogue seeding when a BuildingModel containing parametric instances is saved.
7. Integrated `componentInstances` into `BuildingModel` with a default empty list for source compatibility.
8. `BuildingModelStore.save()` persists the existing BuildingModel and parametric instances in the same Room transaction; `load()` reconstructs both.
9. Edit-history JSON now includes component-instance snapshots; older snapshots without this field decode to an empty list.
10. Added JVM source tests for catalogue uniqueness, profile/material validation, component snapshot round-trip, and visual-scale/physical-dimension separation.
11. Added an Android instrumentation migration test that creates a v1 database with legacy project/floor data and verifies that those records remain readable after v1→v2 migration.

## Source inventory
- JVM test source: 19 Kotlin files, 62 `@Test` annotations.
- Android instrumentation source: 11 Kotlin files, 36 `@Test` annotations.
- These are source counts only. No test execution is claimed.

## Validation status
Static inspection and package integrity checks are performed when this archive is prepared. Android compilation, Room KAPT schema generation, JVM test execution, instrumentation execution, and runtime migration verification remain **PENDING** because the requested build/CI work is paused. The migration instrumentation test is added but has not been run.

## Known limitations / next work
- Room's generated `schemas/` JSON for version 2 must be generated and reviewed during the deferred Android build stage; no hand-authored schema JSON is represented as generated evidence.
- Component definition/profile/material library UI is not part of this phase.
- Component properties inspector, editing commands, geometry generation, 2D/3D synchronization, and specialist component builders remain future phases.
- Component instance references are validated in repository code; SQL foreign-key constraints are intentionally not added in this migration, to avoid risking legacy project migration semantics. Deletion policies need an explicit product decision before adding FK constraints.
- The existing backup/restore format has not yet been extended in this phase; this is scheduled in the later offline/backup phase.


## V3 Audit Follow-up
- Legacy Snapshot tests independently cover missing `componentInstances`, `floors`, `elements`, and `openings`; each asserts the corresponding decoded collection is empty.
- Component Definition, Instance, Profile, and Material DAO inserts use `OnConflictStrategy.ABORT`; explicit same-ID edits use `@Update updateExisting` and verify exactly one row was updated.
- Low-level component DAOs are repository-only APIs; UI/ViewModels must call `ComponentPersistence` / `BuildingModelStore`.
- Component source test inventory: 19 JVM files / 62 annotations; 11 instrumentation files / 36 annotations. These are source counts, not executed tests.
