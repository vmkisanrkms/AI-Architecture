# AI Architecture — Phase 1 Persistence Hardening V2

This package addresses the findings in `PHASE1_INDEPENDENT_AUDIT_FINDINGS.md`.

## Scope
- Room schema version 3: retains the v1→v2 component-table migration and adds v2→v3 referential-integrity migration.
- Four component tables remain: definitions, instances, profiles, materials.
- The original nine component indexes are retained. Two additional indexes support definition default-profile/material foreign keys, and a unique `floors(projectId,id)` index supports the composite project/floor foreign key.
- Component definitions have two foreign-key constraints for default material/profile. Component instances have five logical foreign-key constraints: project, composite project+floor, definition, profile, material. `ON DELETE RESTRICT` is used throughout.
- Definition default-profile/material references are enforced both by database foreign keys and transactionally in `ComponentPersistence`.
- Referenced profiles/materials/definitions use RESTRICT deletion policy. Built-in definitions cannot be deleted. Replacing a definition under a key owned by another ID is rejected.
- Duplicate or blank component instance IDs are rejected before `BuildingModelStore.save()` opens its destructive transaction.
- BuildingModel save deletes component children before replacing floor parents, then validates and inserts new instances in the same transaction.
- Legacy snapshot decoding accepts absent `componentInstances`, `floors`, `elements`, and `openings` arrays as empty collections.

## New instrumentation tests
See `app/src/androidTest/java/com/aiarchitecture/app/data/ComponentPersistenceRoundTripTest.kt` and the expanded `ComponentDatabaseMigrationTest.kt`.
The tests are source only and have not been executed in this environment.

## Deferred
No Gradle wrapper generation, Android build, APK, emulator run, or GitHub CI execution was performed. Existing V7 and V3 source archives are retained unchanged under `preserved/`.


## V3 Audit Follow-up
- Legacy Snapshot tests independently cover missing `componentInstances`, `floors`, `elements`, and `openings`; each asserts the corresponding decoded collection is empty.
- Component Definition, Instance, Profile, and Material DAO inserts use `OnConflictStrategy.ABORT`; explicit same-ID edits use `@Update updateExisting` and verify exactly one row was updated.
- Low-level component DAOs are repository-only APIs; UI/ViewModels must call `ComponentPersistence` / `BuildingModelStore`.
- Component source test inventory: 19 JVM files / 62 annotations; 11 instrumentation files / 36 annotations. These are source counts, not executed tests.
