package com.aiarchitecture.app.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.aiarchitecture.app.data.local.AppDatabase
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ComponentDatabaseMigrationTest {
    private val context: Context = ApplicationProvider.getApplicationContext()
    private val dbName = "component-migration-test.db"
    private var database: AppDatabase? = null

    @Before fun createLegacyV1Database() {
        context.deleteDatabase(dbName)
        val legacy = context.openOrCreateDatabase(dbName, Context.MODE_PRIVATE, null)
        legacy.execSQL("CREATE TABLE projects (id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL)")
        legacy.execSQL("CREATE TABLE floors (id TEXT NOT NULL PRIMARY KEY, projectId TEXT NOT NULL, name TEXT NOT NULL, elevationMm REAL NOT NULL)")
        legacy.execSQL("CREATE INDEX index_floors_projectId ON floors (projectId)")
        legacy.execSQL("CREATE TABLE building_elements (id TEXT NOT NULL PRIMARY KEY, projectId TEXT NOT NULL, floorId TEXT NOT NULL, type TEXT NOT NULL, xMm REAL NOT NULL, yMm REAL NOT NULL, zMm REAL NOT NULL, lengthMm REAL NOT NULL, widthMm REAL NOT NULL, heightMm REAL NOT NULL, material TEXT NOT NULL, openingsJson TEXT NOT NULL, revision INTEGER NOT NULL, lengthProvenance TEXT NOT NULL, widthProvenance TEXT NOT NULL, heightProvenance TEXT NOT NULL, yawDegrees REAL NOT NULL)")
        legacy.execSQL("CREATE INDEX index_building_elements_floorId ON building_elements (floorId)")
        legacy.execSQL("CREATE INDEX index_building_elements_projectId ON building_elements (projectId)")
        legacy.execSQL("CREATE TABLE edit_history (sequence INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, projectId TEXT NOT NULL, snapshotJson TEXT NOT NULL, createdAt INTEGER NOT NULL)")
        legacy.execSQL("CREATE INDEX index_edit_history_projectId ON edit_history (projectId)")
        legacy.execSQL("INSERT INTO projects VALUES ('legacy-project','Legacy house',100,200)")
        legacy.execSQL("INSERT INTO floors VALUES ('legacy-floor','legacy-project','Ground',0.0)")
        legacy.execSQL("INSERT INTO building_elements VALUES ('legacy-element','legacy-project','legacy-floor','WALL',0,0,0,4000,200,2800,'brick','[]',3,'USER_ENTERED','USER_ENTERED','USER_ENTERED',0)")
        legacy.execSQL("INSERT INTO edit_history (projectId,snapshotJson,createdAt) VALUES ('legacy-project','{\"id\":\"legacy-project\",\"name\":\"Legacy house\",\"floors\":[]}',300)")
        legacy.version = 1
        legacy.close()
    }

    @After fun closeDatabase() {
        database?.close()
        database = null
        context.deleteDatabase(dbName)
    }

    @Test fun migrationPreservesExistingProjectAndFloorRows() = runBlocking {
        database = Room.databaseBuilder(context, AppDatabase::class.java, dbName)
            .addMigrations(AppDatabase.MIGRATION_1_2, AppDatabase.MIGRATION_2_3).build()
        val db = database!!
        assertEquals("Legacy house", db.projects().getProject("legacy-project")?.name)
        assertEquals("Ground", db.floors().floors("legacy-project").single().name)
        assertEquals("legacy-element", db.elements().elements("legacy-project").single().id)
        assertEquals("legacy-project", db.history().recent("legacy-project").single().projectId)
        assertTrue(db.componentDefinitions().all().isEmpty())
        assertTrue(db.componentInstances().forProject("legacy-project").isEmpty())

        val sqlite = db.openHelper.readableDatabase
        val expectedTables = setOf("component_definitions", "component_instances", "component_profiles", "component_materials")
        val actualTables = mutableSetOf<String>()
        sqlite.query("SELECT name FROM sqlite_master WHERE type='table'").use { c -> while (c.moveToNext()) actualTables += c.getString(0) }
        assertTrue("All four component tables must exist", actualTables.containsAll(expectedTables))
        val expectedIndexes = setOf(
            "index_component_definitions_key",
            "index_component_instances_projectId", "index_component_instances_floorId",
            "index_component_instances_definitionId", "index_component_instances_materialId", "index_component_instances_profileId",
            "index_component_profiles_name", "index_component_materials_name", "index_component_materials_category"
        )
        val actualIndexes = mutableSetOf<String>()
        sqlite.query("SELECT name FROM sqlite_master WHERE type='index'").use { c -> while (c.moveToNext()) actualIndexes += c.getString(0) }
        assertTrue("All nine original component indexes must exist", actualIndexes.containsAll(expectedIndexes))
        assertTrue("Definition default-reference indexes must exist", actualIndexes.contains("index_component_definitions_defaultMaterialId") && actualIndexes.contains("index_component_definitions_defaultProfileId"))
        assertTrue("Composite floor/project parent index must exist", actualIndexes.contains("index_floors_projectId_id"))
        var definitionForeignKeyRows = 0
        sqlite.query("PRAGMA foreign_key_list(component_definitions)").use { c -> while (c.moveToNext()) definitionForeignKeyRows++ }
        assertEquals("Definition default profile/material references must be enforced", 2, definitionForeignKeyRows)
        var foreignKeyRows = 0
        sqlite.query("PRAGMA foreign_key_list(component_instances)").use { c -> while (c.moveToNext()) foreignKeyRows++ }
        // Five logical foreign keys; the project+floor relationship is composite and occupies two PRAGMA rows.
        assertEquals("Component instances must enforce project, floor/project, definition, profile and material references", 6, foreignKeyRows)
    }
}
