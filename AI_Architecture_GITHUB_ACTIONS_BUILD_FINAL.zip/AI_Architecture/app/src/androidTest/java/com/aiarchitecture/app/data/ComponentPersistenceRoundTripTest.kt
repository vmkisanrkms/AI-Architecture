package com.aiarchitecture.app.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.aiarchitecture.app.core.components.*
import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm
import com.aiarchitecture.app.data.local.*
import com.aiarchitecture.app.data.repository.*
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ComponentPersistenceRoundTripTest {
    private lateinit var db: AppDatabase
    private lateinit var persistence: ComponentPersistence
    private val context: Context = ApplicationProvider.getApplicationContext()

    @Before fun openDb() {
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        persistence = ComponentPersistence(db)
    }
    @After fun closeDb() { db.close() }

    private fun definition(id: String = "def-test", key: String = "test-component") = ComponentDefinition(
        id=id, key=key, name="Test Component", category=ComponentCategory.CUSTOM,
        geometryRecipe=GeometryRecipe(GeometryRecipeType.BOX, mapOf("axis" to "Z"), 3),
        parameters=listOf(ParameterDefinition("heightMm", "Height", ParameterValueType.NUMBER, ParameterUnit.MM, "1000", 100.0, 5000.0, 5.0, true, true, false)),
        constraints=listOf(ComponentConstraint("height-positive", setOf("heightMm"), ConstraintRule.GreaterThan("heightMm", 0.0), "Height must be positive"))
    )
    private fun profile() = CustomProfile(
        id="profile-test", name="Ordered profile", kind=ProfileKind.POLYLINE,
        points=listOf(ProfilePoint(0.0,0.0), ProfilePoint(120.5,4.25), ProfilePoint(240.0,0.0)),
        closed=false, thicknessMm=6.5, revision=9
    )
    private fun material() = MaterialDescriptor(
        id="material-test", name="Anodized steel", category=MaterialCategory.STEEL,
        red=.2f, green=.3f, blue=.4f, alpha=.8f, roughness=.25f, metallic=.9f,
        textureReference="textures/steel-a.png"
    )
    private fun instance(id: String = "instance-test", profileId: String? = "profile-test", materialId: String? = "material-test") = ComponentInstance(
        id=id, projectId="project-test", floorId="floor-test", definitionId="def-test", name="Instance",
        dimensions=DimensionsMm(1200.0,1000.0,80.0,10.0), profileId=profileId, materialId=materialId,
        parameterValues=mapOf("heightMm" to ParameterValue("heightMm", "1000"))
    )
    private suspend fun seedReferences() {
        db.projects().upsert(ProjectEntity("project-test","Test project",1,1))
        db.floors().upsertAll(listOf(FloorEntity("floor-test","project-test","Ground",0.0)))
        persistence.saveProfile(profile())
        persistence.saveMaterial(material())
        persistence.saveDefinition(definition())
    }

    @Test fun allFourTablesRoundTripThroughRoomDaos() = runBlocking {
        seedReferences()
        persistence.saveInstance(instance())
        assertEquals(definition(), persistence.definitions().single())
        assertEquals(profile(), persistence.profiles().single())
        assertEquals(material(), persistence.materials().single())
        assertEquals(instance(), persistence.instances("project-test").single())
    }

    @Test fun profilePointOrderAndProfileMetadataSurviveDatabaseRoundTrip() = runBlocking {
        persistence.saveProfile(profile())
        val restored = persistence.profiles().single()
        assertEquals(listOf(ProfilePoint(0.0,0.0), ProfilePoint(120.5,4.25), ProfilePoint(240.0,0.0)), restored.points)
        assertEquals(ProfileKind.POLYLINE, restored.kind)
        assertFalse(restored.closed)
        assertEquals(6.5, restored.thicknessMm, 0.0)
        assertEquals(9, restored.revision)
    }

    @Test fun buildingModelStoreSavesAndLoadsComponentInstances() = runBlocking {
        seedReferences()
        val floor = BuildingFloor("floor-test", "Ground", 0.0)
        val model = BuildingModel("project-test", "Test project", listOf(floor), listOf(instance()))
        val store = BuildingModelStore(db)
        store.save(model)
        assertEquals(model, store.load("project-test"))
        val history = db.history().recent("project-test").single()
        assertEquals(model, ModelJson.decode(history.snapshotJson))
    }

    private fun legacyFixture(
        includeComponentInstances: Boolean = true,
        includeFloors: Boolean = true,
        includeElements: Boolean = true,
        includeOpenings: Boolean = true
    ): String {
        val root = org.json.JSONObject().put("id", "legacy-fixture").put("name", "Legacy")
        if (includeComponentInstances) root.put("componentInstances", org.json.JSONArray())
        if (includeFloors) {
            val floor = org.json.JSONObject().put("id", "f").put("name", "Ground").put("elevation", 0)
            if (includeElements) {
                val element = org.json.JSONObject()
                    .put("id", "e").put("type", "WALL")
                    .put("x", 0).put("y", 0).put("z", 0)
                    .put("l", 4000).put("w", 200).put("h", 2800)
                    .put("lp", "USER_ENTERED").put("wp", "USER_ENTERED").put("hp", "USER_ENTERED")
                    .put("material", "brick").put("revision", 1).put("yaw", 0)
                if (includeOpenings) element.put("openings", org.json.JSONArray())
                floor.put("elements", org.json.JSONArray().put(element))
            }
            root.put("floors", org.json.JSONArray().put(floor))
        }
        return root.toString()
    }

    @Test fun legacySnapshotWithoutComponentInstancesDecodesToEmptyComponentCollection() {
        val decoded = ModelJson.decode(legacyFixture(includeComponentInstances = false))
        assertTrue(decoded.floors.isNotEmpty())
        assertTrue(decoded.floors.single().elements.isNotEmpty())
        assertTrue(decoded.floors.single().elements.single().openings.isEmpty())
        assertTrue(decoded.componentInstances.isEmpty())
    }

    @Test fun legacySnapshotWithoutFloorsDecodesToEmptyFloorCollection() {
        val decoded = ModelJson.decode(legacyFixture(includeFloors = false))
        assertTrue(decoded.componentInstances.isEmpty())
        assertTrue(decoded.floors.isEmpty())
    }

    @Test fun legacyFloorWithoutElementsDecodesToEmptyElementCollection() {
        val decoded = ModelJson.decode(legacyFixture(includeElements = false))
        assertTrue(decoded.componentInstances.isEmpty())
        assertEquals(1, decoded.floors.size)
        assertTrue(decoded.floors.single().elements.isEmpty())
    }

    @Test fun legacyElementWithoutOpeningsDecodesToEmptyOpeningCollection() {
        val decoded = ModelJson.decode(legacyFixture(includeOpenings = false))
        assertTrue(decoded.componentInstances.isEmpty())
        assertEquals(1, decoded.floors.size)
        assertEquals(1, decoded.floors.single().elements.size)
        assertTrue(decoded.floors.single().elements.single().openings.isEmpty())
    }

    @Test fun directDaoInsertRejectsDuplicateDefinitionIdWithoutOverwriting() = runBlocking {
        persistence.saveDefinition(definition())
        val original = db.componentDefinitions().get("def-test")!!
        val duplicate = original.copy(name="Must not overwrite")
        assertTrue(runCatching { db.componentDefinitions().insertNew(duplicate) }.isFailure)
        assertEquals("Test Component", db.componentDefinitions().get("def-test")!!.name)
        assertEquals(1, db.componentDefinitions().updateExisting(original.copy(name="Explicit update")))
        assertEquals("Explicit update", db.componentDefinitions().get("def-test")!!.name)
    }

    @Test fun directDaoInsertRejectsDuplicateProfileAndMaterialIdsWithoutOverwriting() = runBlocking {
        persistence.saveProfile(profile())
        persistence.saveMaterial(material())
        val oldProfile = db.componentProfiles().get("profile-test")!!
        val oldMaterial = db.componentMaterials().get("material-test")!!
        assertTrue(runCatching { db.componentProfiles().insertNew(oldProfile.copy(name="Overwrite attempt")) }.isFailure)
        assertTrue(runCatching { db.componentMaterials().insertNew(oldMaterial.copy(name="Overwrite attempt")) }.isFailure)
        assertEquals("Ordered profile", db.componentProfiles().get("profile-test")!!.name)
        assertEquals("Anodized steel", db.componentMaterials().get("material-test")!!.name)
        assertEquals(1, db.componentProfiles().updateExisting(oldProfile.copy(name="Explicit profile update")))
        assertEquals(1, db.componentMaterials().updateExisting(oldMaterial.copy(name="Explicit material update")))
    }

    @Test fun directDaoInsertRejectsDuplicateInstanceIdWithoutOverwriting() = runBlocking {
        seedReferences()
        persistence.saveInstance(instance("instance-unique", null, null))
        val original = db.componentInstances().forProject("project-test").single()
        val duplicate = original.copy(name="Overwrite attempt")
        assertTrue(runCatching { db.componentInstances().insertNew(duplicate) }.isFailure)
        assertEquals("Instance", db.componentInstances().forProject("project-test").single().name)
        assertEquals(1, db.componentInstances().updateExisting(original.copy(name="Explicit instance update")))
        assertEquals("Explicit instance update", db.componentInstances().forProject("project-test").single().name)
    }

    @Test fun duplicateInstanceIdsAreRejectedBeforeReplacingExistingRows() = runBlocking {
        seedReferences()
        val store = BuildingModelStore(db)
        val floor = BuildingFloor("floor-test", "Ground", 0.0)
        store.save(BuildingModel("project-test","Test",listOf(floor),listOf(instance("kept",null,null))))
        val duplicate = instance("duplicate",null,null)
        val bad = BuildingModel("project-test","Test",listOf(floor),listOf(duplicate,duplicate))
        val failure = runCatching { store.save(bad) }.exceptionOrNull()
        assertNotNull(failure)
        assertEquals("kept", db.componentInstances().forProject("project-test").single().id)
    }

    @Test fun definitionDefaultsAndFloorReferencesAreValidated() = runBlocking {
        seedReferences()
        val invalidDefault = definition(id="bad-default", key="bad-default-key").copy(defaultMaterialId="absent-material")
        assertTrue(runCatching { persistence.saveDefinition(invalidDefault) }.isFailure)
        db.projects().upsert(ProjectEntity("other-project","Other project",1,1))
        db.floors().upsertAll(listOf(FloorEntity("other-floor","other-project","Other",0.0)))
        val wrongFloor = instance(profileId=null, materialId=null).copy(floorId="other-floor")
        assertTrue(runCatching { persistence.saveInstance(wrongFloor) }.isFailure)
        val rawDangling = ComponentInstanceEntity("raw-bad", "project-test", "other-floor", "def-test", "Raw", "{}", "{}", "{}", "{}", null, null, 0, true, false, 1)
        assertTrue("Composite project/floor foreign key must reject DAO-level cross-project floor references", runCatching { db.componentInstances().insertNew(rawDangling) }.isFailure)
        val store = BuildingModelStore(db)
        val invalidModel = BuildingModel("project-test", "Test", listOf(BuildingFloor("floor-test", "Ground", 0.0)), listOf(wrongFloor))
        assertTrue(runCatching { store.save(invalidModel) }.isFailure)
        assertTrue(db.componentInstances().forProject("project-test").isEmpty())
    }

    @Test fun definitionDefaultProfileAndMaterialReferencesRestrictDeletion() = runBlocking {
        persistence.saveProfile(profile())
        persistence.saveMaterial(material())
        persistence.saveDefinition(definition(id="default-ref", key="default-ref-key").copy(defaultProfileId="profile-test", defaultMaterialId="material-test"))
        assertTrue(runCatching { persistence.deleteProfile("profile-test") }.isFailure)
        assertTrue(runCatching { persistence.deleteMaterial("material-test") }.isFailure)
        assertTrue("Raw DAO delete must also be blocked by database foreign key", runCatching { db.componentProfiles().delete("profile-test") }.isFailure)
        assertTrue("Raw DAO delete must also be blocked by database foreign key", runCatching { db.componentMaterials().delete("material-test") }.isFailure)
    }

    @Test fun definitionKeyCannotSilentlyReplaceDifferentDefinitionId() = runBlocking {
        persistence.saveDefinition(definition())
        val collision = definition(id="other-id", key="test-component")
        assertTrue(runCatching { persistence.saveDefinition(collision) }.isFailure)
        assertEquals("def-test", db.componentDefinitions().getByKey("test-component")?.id)
    }

    @Test fun referencedProfileMaterialAndDefinitionDeletionIsRestricted() = runBlocking {
        seedReferences()
        persistence.saveInstance(instance())
        assertTrue(runCatching { persistence.deleteProfile("profile-test") }.isFailure)
        assertTrue(runCatching { persistence.deleteMaterial("material-test") }.isFailure)
        assertTrue(runCatching { persistence.deleteDefinition("def-test") }.isFailure)
        // Same-ID edits use UPDATE (not destructive REPLACE) and retain all instance references.
        persistence.saveProfile(profile().copy(name="Updated profile"))
        persistence.saveMaterial(material().copy(name="Updated steel"))
        persistence.saveDefinition(definition().copy(name="Updated component"))
        assertEquals("Updated profile", persistence.profiles().single().name)
        assertEquals("Updated steel", persistence.materials().single().name)
        assertEquals("Updated component", persistence.definitions().single().name)
        assertEquals("instance-test", persistence.instances("project-test").single().id)
    }

    @Test fun danglingReferencesAreRejectedBySingleAndBulkPersistencePaths() = runBlocking {
        seedReferences()
        val bad = instance(profileId="missing-profile", materialId="missing-material")
        assertTrue(runCatching { persistence.saveInstance(bad) }.isFailure)
        val store = BuildingModelStore(db)
        val model = BuildingModel("project-test","Test",listOf(BuildingFloor("floor-test","Ground",0.0)),listOf(bad))
        assertTrue(runCatching { store.save(model) }.isFailure)
        assertTrue(db.componentInstances().forProject("project-test").isEmpty())
    }

    @Test fun bulkInsertDuplicateDefinitionIdAbortsWithoutPartialInsert() = runBlocking {
        persistence.saveDefinition(definition())
        val dao = db.componentDefinitions()
        val original = dao.get("def-test")!!
        val newRow = original.copy(id="new-def", key="new-def-key", name="New row")
        assertTrue(runCatching { dao.insertNewAll(listOf(newRow, original.copy(name="Duplicate"))) }.isFailure)
        assertNull(dao.get("new-def"))
        assertEquals("Test Component", dao.get("def-test")!!.name)
    }

    @Test fun bulkInsertDuplicateProfileIdAbortsWithoutPartialInsert() = runBlocking {
        persistence.saveProfile(profile())
        val dao = db.componentProfiles()
        val original = dao.get("profile-test")!!
        val newRow = original.copy(id="new-profile", name="New profile")
        assertTrue(runCatching { dao.insertNewAll(listOf(newRow, original.copy(name="Duplicate"))) }.isFailure)
        assertNull(dao.get("new-profile"))
        assertEquals("Ordered profile", dao.get("profile-test")!!.name)
    }

    @Test fun bulkInsertDuplicateMaterialIdAbortsWithoutPartialInsert() = runBlocking {
        persistence.saveMaterial(material())
        val dao = db.componentMaterials()
        val original = dao.get("material-test")!!
        val newRow = original.copy(id="new-material", name="New material")
        assertTrue(runCatching { dao.insertNewAll(listOf(newRow, original.copy(name="Duplicate"))) }.isFailure)
        assertNull(dao.get("new-material"))
        assertEquals("Anodized steel", dao.get("material-test")!!.name)
    }

    @Test fun bulkInsertDuplicateInstanceIdAbortsWithoutPartialInsert() = runBlocking {
        seedReferences()
        persistence.saveInstance(instance("instance-unique", null, null))
        val dao = db.componentInstances()
        val original = dao.forProject("project-test").single()
        val newRow = original.copy(id="new-instance", name="New instance")
        assertTrue(runCatching { dao.insertNewAll(listOf(newRow, original.copy(name="Duplicate"))) }.isFailure)
        assertTrue(dao.forProject("project-test").none { it.id == "new-instance" })
        assertEquals("Instance", dao.forProject("project-test").single { it.id == "instance-unique" }.name)
    }

    @Test fun updateExistingReturnsZeroForMissingIdsAcrossAllComponentDaos() = runBlocking {
        seedReferences()
        val definitionRow = db.componentDefinitions().get("def-test")!!
        val profileRow = db.componentProfiles().get("profile-test")!!
        val materialRow = db.componentMaterials().get("material-test")!!
        val instanceRow = instance("missing-instance", null, null).let {
            ComponentInstanceEntity(
                id="missing-instance", projectId=it.projectId, floorId=it.floorId,
                definitionId=it.definitionId, name=it.name, dimensionsJson="{}",
                transformJson="{}", parameterValuesJson="{}", dimensionProvenanceJson="{}",
                profileId=null, materialId=null, revision=0, visible=true, locked=false, updatedAt=1
            )
        }
        assertEquals(0, db.componentDefinitions().updateExisting(definitionRow.copy(id="missing-definition")))
        assertEquals(0, db.componentProfiles().updateExisting(profileRow.copy(id="missing-profile")))
        assertEquals(0, db.componentMaterials().updateExisting(materialRow.copy(id="missing-material")))
        assertEquals(0, db.componentInstances().updateExisting(instanceRow))
        assertEquals("Test Component", db.componentDefinitions().get("def-test")!!.name)
        assertEquals("Ordered profile", db.componentProfiles().get("profile-test")!!.name)
        assertEquals("Anodized steel", db.componentMaterials().get("material-test")!!.name)
    }

}
