package com.aiarchitecture.app.core.components

import java.util.UUID
import kotlin.math.abs

/** All physical lengths are millimetres. Renderer conversion happens only at the rendering boundary. */
data class DimensionsMm(
    val length: Double,
    val height: Double,
    val width: Double,
    val thickness: Double
) {
    fun validate(): List<String> = buildList {
        val values = listOf("length" to length, "height" to height, "width" to width, "thickness" to thickness)
        values.forEach { (name, value) ->
            if (!value.isFinite() || value <= 0.0) add("$name must be a finite value greater than zero")
        }
    }
}

data class Transform3D(
    val xMm: Double = 0.0,
    val yMm: Double = 0.0,
    val zMm: Double = 0.0,
    val rotationXDegrees: Double = 0.0,
    val rotationYDegrees: Double = 0.0,
    val rotationZDegrees: Double = 0.0,
    val scaleX: Double = 1.0,
    val scaleY: Double = 1.0,
    val scaleZ: Double = 1.0
) {
    fun validate(): List<String> = buildList {
        listOf(xMm, yMm, zMm, rotationXDegrees, rotationYDegrees, rotationZDegrees,
            scaleX, scaleY, scaleZ).forEach { if (!it.isFinite()) add("Transform values must be finite") }
        if (scaleX <= 0 || scaleY <= 0 || scaleZ <= 0) add("Transform scales must be greater than zero")
    }
}

enum class DimensionProvenance { USER_ENTERED, DERIVED, ESTIMATED }
enum class ParameterValueType { NUMBER, INTEGER, BOOLEAN, TEXT, ENUM }
enum class ParameterUnit { NONE, MM, SQUARE_MM, DEGREES }
enum class ComponentCategory { RAILING, CONNECTOR, OPENING, STRUCTURAL, ARCHITECTURAL, CIRCULATION, CUSTOM }
enum class GeometryRecipeType { BOX, PLATE, BEAM, PROFILE_EXTRUSION, SWEEP, PANEL_WITH_OPENINGS, ARCH, STAIR, ASSEMBLY }
enum class ProfileKind { POLYLINE, CLOSED_POLYGON, ARC, PARAMETRIC }
enum class MaterialCategory { GLASS, STEEL, ALUMINIUM, WOOD, CONCRETE, MASONRY, TILE, PAINT, CUSTOM }

data class ParameterDefinition(
    val key: String,
    val label: String,
    val valueType: ParameterValueType,
    val unit: ParameterUnit = ParameterUnit.NONE,
    val defaultValue: String,
    val minimum: Double? = null,
    val maximum: Double? = null,
    val step: Double? = null,
    val required: Boolean = true,
    val affectsGeometry: Boolean = true,
    val affectsPlan: Boolean = true,
    val allowedValues: List<String> = emptyList()
) {
    init {
        require(key.isNotBlank() && label.isNotBlank())
        require(minimum == null || minimum.isFinite())
        require(maximum == null || maximum.isFinite())
        require(minimum == null || maximum == null || minimum <= maximum)
        require(step == null || (step.isFinite() && step > 0.0))
    }
}

data class ParameterValue(
    val key: String,
    val value: String,
    val provenance: DimensionProvenance = DimensionProvenance.USER_ENTERED
)

data class ComponentConstraint(
    val id: String = UUID.randomUUID().toString(),
    val parameterKeys: Set<String>,
    val rule: ConstraintRule,
    val message: String
)

/** Typed rules only; arbitrary executable expressions are deliberately not supported. */
sealed interface ConstraintRule {
    data class GreaterThan(val key: String, val minimumExclusive: Double) : ConstraintRule
    data class LessThanOrEqual(val key: String, val maximumInclusive: Double) : ConstraintRule
    data class LessThanOrEqualRatio(val numeratorKey: String, val denominatorKey: String, val maximumRatio: Double) : ConstraintRule
    data class EnumIsOneOf(val key: String, val values: Set<String>) : ConstraintRule
}

data class ProfilePoint(val xMm: Double, val yMm: Double)
data class CustomProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: ProfileKind,
    val points: List<ProfilePoint>,
    val closed: Boolean,
    val thicknessMm: Double = 0.0,
    val revision: Long = 0
) {
    fun validate(): List<String> = buildList {
        if (name.isBlank()) add("Profile name is required")
        if (points.size < 2) add("A profile requires at least two points")
        if (points.any { !it.xMm.isFinite() || !it.yMm.isFinite() }) add("Profile coordinates must be finite")
        if (points.zipWithNext().any { (a, b) -> abs(a.xMm - b.xMm) < 1e-9 && abs(a.yMm - b.yMm) < 1e-9 }) add("Profile contains a zero-length segment")
        if (closed && points.size < 3) add("A closed profile requires at least three points")
        if (!thicknessMm.isFinite() || thicknessMm < 0.0) add("Profile thickness cannot be negative")
    }
}

data class MaterialDescriptor(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: MaterialCategory,
    val red: Float,
    val green: Float,
    val blue: Float,
    val alpha: Float = 1f,
    val roughness: Float = 0.5f,
    val metallic: Float = 0f,
    val textureReference: String? = null
) {
    fun validate(): List<String> = buildList {
        if (name.isBlank()) add("Material name is required")
        listOf(red, green, blue, alpha, roughness, metallic).forEach { if (!it.isFinite() || it !in 0f..1f) add("Material channels and PBR values must be between 0 and 1") }
    }
}

data class GeometryRecipe(val type: GeometryRecipeType, val options: Map<String, String> = emptyMap(), val generatorVersion: Int = 1)

data class ComponentDefinition(
    val id: String = UUID.randomUUID().toString(),
    val key: String,
    val name: String,
    val category: ComponentCategory,
    val schemaVersion: Int = 1,
    val geometryRecipe: GeometryRecipe,
    val parameters: List<ParameterDefinition>,
    val constraints: List<ComponentConstraint> = emptyList(),
    val defaultMaterialId: String? = null,
    val defaultProfileId: String? = null,
    val builtIn: Boolean = false
) {
    init { require(key.isNotBlank() && name.isNotBlank() && schemaVersion > 0) }
}

data class ComponentInstance(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val floorId: String,
    val definitionId: String,
    val name: String,
    val dimensions: DimensionsMm,
    val transform: Transform3D = Transform3D(),
    val profileId: String? = null,
    val materialId: String? = null,
    val parameterValues: Map<String, ParameterValue> = emptyMap(),
    val dimensionProvenance: Map<String, DimensionProvenance> = emptyMap(),
    val revision: Long = 0,
    val visible: Boolean = true,
    val locked: Boolean = false
)

data class ComponentValidationResult(val errors: List<String>) { val isValid: Boolean get() = errors.isEmpty() }

object ComponentValidator {
    fun validate(definition: ComponentDefinition, instance: ComponentInstance): ComponentValidationResult {
        val errors = mutableListOf<String>()
        errors += instance.dimensions.validate()
        errors += instance.transform.validate()
        if (instance.definitionId != definition.id) errors += "Instance definition ID does not match definition"

        val duplicateParameterKeys = definition.parameters.groupBy { it.key }.filterValues { it.size > 1 }.keys
        duplicateParameterKeys.forEach { errors += "Duplicate parameter key in definition: $it" }
        val duplicateConstraintIds = definition.constraints.groupBy { it.id }.filterValues { it.size > 1 }.keys
        duplicateConstraintIds.forEach { errors += "Duplicate constraint ID: $it" }

        val schema = definition.parameters.associateBy { it.key }
        instance.parameterValues.forEach { (key, value) ->
            val spec = schema[key]
            if (spec == null) errors += "Unknown parameter: $key"
            else if (value.key != key) errors += "Parameter map key mismatch: $key"
            else validateValue(spec, value.value)?.let(errors::add)
        }
        definition.parameters.filter { it.required && it.key !in instance.parameterValues }
            .forEach { errors += "Missing required parameter: ${it.key}" }

        definition.constraints.forEach { constraint ->
            val ruleKeys = when (val rule = constraint.rule) {
                is ConstraintRule.GreaterThan -> setOf(rule.key)
                is ConstraintRule.LessThanOrEqual -> setOf(rule.key)
                is ConstraintRule.LessThanOrEqualRatio -> setOf(rule.numeratorKey, rule.denominatorKey)
                is ConstraintRule.EnumIsOneOf -> setOf(rule.key)
            }
            (ruleKeys - schema.keys).forEach { errors += "Constraint ${constraint.id} references unknown parameter: $it" }
            (ruleKeys - constraint.parameterKeys).forEach { errors += "Constraint ${constraint.id} parameterKeys missing reference: $it" }
            (constraint.parameterKeys - schema.keys).forEach { errors += "Constraint ${constraint.id} declares unknown parameter: $it" }
            if (constraint.id.isBlank()) errors += "Constraint ID must not be blank"
            if (constraint.message.isBlank()) errors += "Constraint ${constraint.id} message must not be blank"

            when (val rule = constraint.rule) {
                is ConstraintRule.GreaterThan -> {
                    if (!rule.minimumExclusive.isFinite()) errors += "Constraint ${constraint.id}: GreaterThan threshold must be finite"
                    val raw = instance.parameterValues[rule.key]?.value
                    val value = raw?.toDoubleOrNull()?.takeIf { it.isFinite() }
                    if (raw == null || value == null) errors += "Constraint ${constraint.id}: GreaterThan requires a present, valid numeric parameter '${rule.key}'"
                    else if (rule.minimumExclusive.isFinite() && value <= rule.minimumExclusive) errors += constraint.message
                }
                is ConstraintRule.LessThanOrEqual -> {
                    if (!rule.maximumInclusive.isFinite()) errors += "Constraint ${constraint.id}: LessThanOrEqual maximum must be finite"
                    val raw = instance.parameterValues[rule.key]?.value
                    val value = raw?.toDoubleOrNull()?.takeIf { it.isFinite() }
                    if (raw == null || value == null) errors += "Constraint ${constraint.id}: LessThanOrEqual requires a present, valid numeric parameter '${rule.key}'"
                    else if (rule.maximumInclusive.isFinite() && value > rule.maximumInclusive) errors += constraint.message
                }
                is ConstraintRule.LessThanOrEqualRatio -> {
                    if (!rule.maximumRatio.isFinite() || rule.maximumRatio < 0.0) errors += "Constraint ${constraint.id}: ratio maximum must be finite and non-negative"
                    val numeratorRaw = instance.parameterValues[rule.numeratorKey]?.value
                    val denominatorRaw = instance.parameterValues[rule.denominatorKey]?.value
                    val numerator = numeratorRaw?.toDoubleOrNull()?.takeIf { it.isFinite() }
                    val denominator = denominatorRaw?.toDoubleOrNull()?.takeIf { it.isFinite() }
                    if (numeratorRaw == null || numerator == null) errors += "Constraint ${constraint.id}: ratio numerator '${rule.numeratorKey}' is missing or invalid"
                    if (denominatorRaw == null || denominator == null) errors += "Constraint ${constraint.id}: ratio denominator '${rule.denominatorKey}' is missing or invalid"
                    else if (denominator <= 0.0) errors += "Constraint ${constraint.id}: ratio denominator must be greater than zero"
                    if (numerator != null && denominator != null && denominator > 0.0 && rule.maximumRatio.isFinite() && rule.maximumRatio >= 0.0 && numerator / denominator > rule.maximumRatio) errors += constraint.message
                }
                is ConstraintRule.EnumIsOneOf -> {
                    val value = instance.parameterValues[rule.key]?.value
                    if (value == null) errors += "Constraint ${constraint.id}: EnumIsOneOf requires parameter '${rule.key}'"
                    else if (rule.values.isEmpty() || value !in rule.values) errors += constraint.message
                }
            }
        }
        return ComponentValidationResult(errors.distinct())
    }

    private fun validateValue(spec: ParameterDefinition, raw: String): String? {
        return when (spec.valueType) {
            ParameterValueType.NUMBER, ParameterValueType.INTEGER -> {
                val value = raw.toDoubleOrNull() ?: return "${spec.label} must be numeric"
                if (!value.isFinite()) return "${spec.label} must be finite"
                if (spec.valueType == ParameterValueType.INTEGER && value % 1.0 != 0.0) return "${spec.label} must be an integer"
                if (spec.minimum != null && value < spec.minimum) return "${spec.label} is below minimum ${spec.minimum}"
                if (spec.maximum != null && value > spec.maximum) return "${spec.label} exceeds maximum ${spec.maximum}"
                null
            }
            ParameterValueType.BOOLEAN -> if (raw == "true" || raw == "false") null else "${spec.label} must be true or false"
            ParameterValueType.ENUM -> if (raw in spec.allowedValues) null else "${spec.label} is not an allowed value"
            ParameterValueType.TEXT -> if (!spec.required || raw.isNotBlank()) null else "${spec.label} is required"
        }
    }
}

object ComponentTransformOperations {
    fun move(instance: ComponentInstance, xMm: Double, yMm: Double, zMm: Double): ComponentInstance {
        require(listOf(xMm, yMm, zMm).all { it.isFinite() }) { "Move coordinates must be finite" }
        return instance.copy(transform = instance.transform.copy(xMm = xMm, yMm = yMm, zMm = zMm), revision = instance.revision + 1)
    }

    fun rotate(instance: ComponentInstance, xDegrees: Double, yDegrees: Double, zDegrees: Double): ComponentInstance {
        require(listOf(xDegrees, yDegrees, zDegrees).all { it.isFinite() }) { "Rotation values must be finite" }
        return instance.copy(transform = instance.transform.copy(rotationXDegrees = xDegrees, rotationYDegrees = yDegrees, rotationZDegrees = zDegrees), revision = instance.revision + 1)
    }

    /** Physical resize updates dimensions; it deliberately does not mutate visual scale. */
    fun resize(instance: ComponentInstance, dimensions: DimensionsMm): ComponentInstance {
        require(dimensions.validate().isEmpty()) { "Invalid physical dimensions: ${dimensions.validate().joinToString()}" }
        return instance.copy(dimensions = dimensions, revision = instance.revision + 1)
    }

    /**
     * Changes renderer-facing visual scale only. Physical dimensions in millimetres remain
     * untouched. Every axis must be finite and strictly positive; invalid input is rejected
     * before a new instance is created.
     */
    fun setVisualScale(
        instance: ComponentInstance,
        scaleX: Double,
        scaleY: Double,
        scaleZ: Double
    ): ComponentInstance {
        require(scaleX.isFinite() && scaleX > 0.0) { "scaleX must be finite and greater than zero" }
        require(scaleY.isFinite() && scaleY > 0.0) { "scaleY must be finite and greater than zero" }
        require(scaleZ.isFinite() && scaleZ > 0.0) { "scaleZ must be finite and greater than zero" }
        return instance.copy(
            transform = instance.transform.copy(scaleX = scaleX, scaleY = scaleY, scaleZ = scaleZ),
            revision = instance.revision + 1
        )
    }

    fun setParameter(instance: ComponentInstance, key: String, value: String, provenance: DimensionProvenance = DimensionProvenance.USER_ENTERED): ComponentInstance =
        instance.copy(parameterValues = instance.parameterValues + (key to ParameterValue(key, value, provenance)), revision = instance.revision + 1)
}

object BuiltInComponentDefinitions {
    private fun number(key: String, label: String, default: String, min: Double = 0.1) =
        ParameterDefinition(key, label, ParameterValueType.NUMBER, ParameterUnit.MM, default, minimum = min)

    val all: List<ComponentDefinition> = listOf(
        definition("glass-railing", "Glass Railing", ComponentCategory.RAILING, GeometryRecipeType.ASSEMBLY, listOf(number("panelThicknessMm", "Glass thickness", "12"), number("postSpacingMm", "Post spacing", "1000", 100.0), number("railingHeightMm", "Railing height", "1050", 100.0))),
        definition("steel-railing", "Steel Railing", ComponentCategory.RAILING, GeometryRecipeType.SWEEP, listOf(number("railDiameterMm", "Rail diameter", "40"), number("postSpacingMm", "Post spacing", "1000", 100.0))),
        definition("bracket", "Bracket", ComponentCategory.CONNECTOR, GeometryRecipeType.PROFILE_EXTRUSION, listOf(number("plateThicknessMm", "Plate thickness", "8"))),
        definition("clamp", "Glass Clamp", ComponentCategory.CONNECTOR, GeometryRecipeType.BOX, listOf(number("clampThicknessMm", "Clamp thickness", "10"))),
        definition("post", "Railing Post", ComponentCategory.CONNECTOR, GeometryRecipeType.BOX, listOf(number("postThicknessMm", "Post thickness", "50"))),
        definition("gate", "Gate", ComponentCategory.OPENING, GeometryRecipeType.ASSEMBLY, listOf(number("frameThicknessMm", "Frame thickness", "50"))),
        definition("pillar", "Pillar / Column", ComponentCategory.STRUCTURAL, GeometryRecipeType.BOX, listOf(number("capHeightMm", "Cap height", "100"))),
        definition("arch", "Arch", ComponentCategory.ARCHITECTURAL, GeometryRecipeType.ARCH, listOf(ParameterDefinition("archType", "Arch type", ParameterValueType.ENUM, defaultValue = "ROUND", allowedValues = listOf("ROUND", "HALF", "SEGMENTAL", "POINTED", "CUSTOM")))),
        definition("staircase", "Staircase", ComponentCategory.CIRCULATION, GeometryRecipeType.STAIR, listOf(ParameterDefinition("treadCount", "Tread count", ParameterValueType.INTEGER, defaultValue = "12", minimum = 1.0), number("riserHeightMm", "Riser height", "175", 50.0), number("treadDepthMm", "Tread depth", "280", 100.0))),
        definition("door", "Door", ComponentCategory.OPENING, GeometryRecipeType.PANEL_WITH_OPENINGS, listOf(number("frameThicknessMm", "Frame thickness", "45"))),
        definition("window", "Window", ComponentCategory.OPENING, GeometryRecipeType.PANEL_WITH_OPENINGS, listOf(number("frameThicknessMm", "Frame thickness", "50"), number("glassThicknessMm", "Glass thickness", "6")))
    )

    private fun definition(key: String, name: String, category: ComponentCategory, recipe: GeometryRecipeType, parameters: List<ParameterDefinition>) =
        ComponentDefinition(
            id = UUID.nameUUIDFromBytes("aiarchitecture:builtin:$key".toByteArray()).toString(),
            key = key, name = name, category = category,
            geometryRecipe = GeometryRecipe(recipe), parameters = parameters, builtIn = true
        )
}
