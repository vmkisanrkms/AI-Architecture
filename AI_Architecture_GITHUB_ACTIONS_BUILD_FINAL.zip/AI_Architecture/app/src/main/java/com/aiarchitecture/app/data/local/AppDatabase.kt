package com.aiarchitecture.app.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC") fun observeProjects(): Flow<List<ProjectEntity>>
    @Query("SELECT * FROM projects WHERE id=:id LIMIT 1") suspend fun getProject(id:String):ProjectEntity?
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC LIMIT 1") suspend fun latestProject():ProjectEntity?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsert(project:ProjectEntity)
    @Query("DELETE FROM projects WHERE id=:id") suspend fun delete(id:String)
}
@Dao interface FloorDao {
    @Query("SELECT * FROM floors WHERE projectId=:projectId ORDER BY elevationMm") suspend fun floors(projectId:String):List<FloorEntity>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<FloorEntity>)
    @Query("DELETE FROM floors WHERE projectId=:projectId") suspend fun deleteForProject(projectId:String)
}
@Dao interface ElementDao {
    @Query("SELECT * FROM building_elements WHERE projectId=:projectId") suspend fun elements(projectId:String):List<ElementEntity>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<ElementEntity>)
    @Query("DELETE FROM building_elements WHERE projectId=:projectId") suspend fun deleteForProject(projectId:String)
}
@Dao interface HistoryDao {
    @Insert suspend fun add(item:EditHistoryEntity)
    @Query("SELECT * FROM edit_history WHERE projectId=:projectId ORDER BY sequence DESC LIMIT 100") suspend fun recent(projectId:String):List<EditHistoryEntity>
    @Query("DELETE FROM edit_history WHERE projectId=:projectId") suspend fun clear(projectId:String)
}
/** Low-level persistence API: call only from ComponentPersistence/BuildingModelStore. Inserts are ABORT-only; edits must use explicit updateExisting. */
@Dao interface ComponentDefinitionDao {
    @Query("SELECT * FROM component_definitions ORDER BY builtIn DESC, name COLLATE NOCASE") suspend fun all(): List<ComponentDefinitionEntity>
    @Query("SELECT * FROM component_definitions WHERE id=:id LIMIT 1") suspend fun get(id: String): ComponentDefinitionEntity?
    @Query("SELECT * FROM component_definitions WHERE `key`=:key LIMIT 1") suspend fun getByKey(key: String): ComponentDefinitionEntity?
    @Query("SELECT COUNT(*) FROM component_instances WHERE definitionId=:id") suspend fun instanceReferenceCount(id: String): Int
    @Query("SELECT COUNT(*) FROM component_definitions WHERE defaultMaterialId=:id OR defaultProfileId=:id") suspend fun defaultReferenceCount(id: String): Int
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertNew(item: ComponentDefinitionEntity)
    @Update suspend fun updateExisting(item: ComponentDefinitionEntity): Int
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertNewAll(items: List<ComponentDefinitionEntity>)
    @Query("DELETE FROM component_definitions WHERE id=:id AND builtIn=0") suspend fun deleteCustom(id: String)
}
/** Internal repository boundary. Never expose these DAO methods to UI/ViewModels. insertNew is ABORT-only; updateExisting is explicit. */
@Dao interface ComponentInstanceDao {
    @Query("SELECT * FROM component_instances WHERE projectId=:projectId ORDER BY updatedAt, id") suspend fun forProject(projectId: String): List<ComponentInstanceEntity>
    @Query("SELECT * FROM component_instances WHERE floorId=:floorId ORDER BY updatedAt, id") suspend fun forFloor(floorId: String): List<ComponentInstanceEntity>
    @Query("SELECT COUNT(*) FROM component_instances WHERE profileId=:id") suspend fun profileReferenceCount(id: String): Int
    @Query("SELECT COUNT(*) FROM component_instances WHERE materialId=:id") suspend fun materialReferenceCount(id: String): Int
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertNew(item: ComponentInstanceEntity)
    @Update suspend fun updateExisting(item: ComponentInstanceEntity): Int
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertNewAll(items: List<ComponentInstanceEntity>)
    @Query("DELETE FROM component_instances WHERE projectId=:projectId") suspend fun deleteForProject(projectId: String)
    @Query("DELETE FROM component_instances WHERE id=:id") suspend fun delete(id: String)
}
/** Low-level repository-only DAO. Duplicate primary keys abort; updates must call updateExisting. */
@Dao interface ComponentProfileDao {
    @Query("SELECT * FROM component_profiles ORDER BY name COLLATE NOCASE") suspend fun all(): List<ComponentProfileEntity>
    @Query("SELECT * FROM component_profiles WHERE id=:id LIMIT 1") suspend fun get(id: String): ComponentProfileEntity?
    @Query("SELECT COUNT(*) FROM component_definitions WHERE defaultProfileId=:id") suspend fun defaultReferenceCount(id: String): Int
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertNew(item: ComponentProfileEntity)
    @Update suspend fun updateExisting(item: ComponentProfileEntity): Int
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertNewAll(items: List<ComponentProfileEntity>)
    @Query("DELETE FROM component_profiles WHERE id=:id") suspend fun delete(id: String)
}
/** Low-level repository-only DAO. Duplicate primary keys abort; updates must call updateExisting. */
@Dao interface ComponentMaterialDao {
    @Query("SELECT * FROM component_materials ORDER BY name COLLATE NOCASE") suspend fun all(): List<ComponentMaterialEntity>
    @Query("SELECT * FROM component_materials WHERE id=:id LIMIT 1") suspend fun get(id: String): ComponentMaterialEntity?
    @Query("SELECT COUNT(*) FROM component_definitions WHERE defaultMaterialId=:id") suspend fun defaultReferenceCount(id: String): Int
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertNew(item: ComponentMaterialEntity)
    @Update suspend fun updateExisting(item: ComponentMaterialEntity): Int
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertNewAll(items: List<ComponentMaterialEntity>)
    @Query("DELETE FROM component_materials WHERE id=:id") suspend fun delete(id: String)
}

@Database(entities=[ProjectEntity::class,FloorEntity::class,ElementEntity::class,EditHistoryEntity::class,
    ComponentDefinitionEntity::class,ComponentInstanceEntity::class,ComponentProfileEntity::class,ComponentMaterialEntity::class],version=3,exportSchema=true)
abstract class AppDatabase:RoomDatabase(){
    abstract fun projects():ProjectDao; abstract fun floors():FloorDao; abstract fun elements():ElementDao; abstract fun history():HistoryDao
    // Module-internal persistence boundary. Feature/UI code must go through repositories.
    internal abstract fun componentDefinitions(): ComponentDefinitionDao
    internal abstract fun componentInstances(): ComponentInstanceDao
    internal abstract fun componentProfiles(): ComponentProfileDao
    internal abstract fun componentMaterials(): ComponentMaterialDao
    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS component_definitions (id TEXT NOT NULL PRIMARY KEY, `key` TEXT NOT NULL, name TEXT NOT NULL, category TEXT NOT NULL, schemaVersion INTEGER NOT NULL, geometryRecipeJson TEXT NOT NULL, parametersJson TEXT NOT NULL, constraintsJson TEXT NOT NULL, defaultMaterialId TEXT, defaultProfileId TEXT, builtIn INTEGER NOT NULL, updatedAt INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_component_definitions_key ON component_definitions (`key`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS component_instances (id TEXT NOT NULL PRIMARY KEY, projectId TEXT NOT NULL, floorId TEXT NOT NULL, definitionId TEXT NOT NULL, name TEXT NOT NULL, dimensionsJson TEXT NOT NULL, transformJson TEXT NOT NULL, parameterValuesJson TEXT NOT NULL, dimensionProvenanceJson TEXT NOT NULL, profileId TEXT, materialId TEXT, revision INTEGER NOT NULL, visible INTEGER NOT NULL, locked INTEGER NOT NULL, updatedAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_component_instances_projectId ON component_instances (projectId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_component_instances_floorId ON component_instances (floorId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_component_instances_definitionId ON component_instances (definitionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_component_instances_materialId ON component_instances (materialId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_component_instances_profileId ON component_instances (profileId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS component_profiles (id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL, pointsJson TEXT NOT NULL, closed INTEGER NOT NULL, thicknessMm REAL NOT NULL, revision INTEGER NOT NULL, updatedAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_component_profiles_name ON component_profiles (name)")
                db.execSQL("CREATE TABLE IF NOT EXISTS component_materials (id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL, red REAL NOT NULL, green REAL NOT NULL, blue REAL NOT NULL, alpha REAL NOT NULL, roughness REAL NOT NULL, metallic REAL NOT NULL, textureReference TEXT, updatedAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_component_materials_name ON component_materials (name)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_component_materials_category ON component_materials (category)")
            }
        }
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_floors_projectId_id ON floors (projectId, id)")
                // Rebuild definitions first: at v2 the instance table has no FK to it yet.
                db.execSQL("CREATE TABLE component_definitions_new (id TEXT NOT NULL PRIMARY KEY, `key` TEXT NOT NULL, name TEXT NOT NULL, category TEXT NOT NULL, schemaVersion INTEGER NOT NULL, geometryRecipeJson TEXT NOT NULL, parametersJson TEXT NOT NULL, constraintsJson TEXT NOT NULL, defaultMaterialId TEXT, defaultProfileId TEXT, builtIn INTEGER NOT NULL, updatedAt INTEGER NOT NULL, FOREIGN KEY(defaultMaterialId) REFERENCES component_materials(id) ON UPDATE NO ACTION ON DELETE RESTRICT, FOREIGN KEY(defaultProfileId) REFERENCES component_profiles(id) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("INSERT INTO component_definitions_new SELECT * FROM component_definitions")
                db.execSQL("DROP TABLE component_definitions")
                db.execSQL("ALTER TABLE component_definitions_new RENAME TO component_definitions")
                db.execSQL("CREATE UNIQUE INDEX index_component_definitions_key ON component_definitions (`key`)")
                db.execSQL("CREATE INDEX index_component_definitions_defaultMaterialId ON component_definitions (defaultMaterialId)")
                db.execSQL("CREATE INDEX index_component_definitions_defaultProfileId ON component_definitions (defaultProfileId)")
                db.execSQL("CREATE TABLE component_instances_new (id TEXT NOT NULL PRIMARY KEY, projectId TEXT NOT NULL, floorId TEXT NOT NULL, definitionId TEXT NOT NULL, name TEXT NOT NULL, dimensionsJson TEXT NOT NULL, transformJson TEXT NOT NULL, parameterValuesJson TEXT NOT NULL, dimensionProvenanceJson TEXT NOT NULL, profileId TEXT, materialId TEXT, revision INTEGER NOT NULL, visible INTEGER NOT NULL, locked INTEGER NOT NULL, updatedAt INTEGER NOT NULL, FOREIGN KEY(projectId) REFERENCES projects(id) ON UPDATE NO ACTION ON DELETE RESTRICT, FOREIGN KEY(projectId, floorId) REFERENCES floors(projectId, id) ON UPDATE NO ACTION ON DELETE RESTRICT, FOREIGN KEY(definitionId) REFERENCES component_definitions(id) ON UPDATE NO ACTION ON DELETE RESTRICT, FOREIGN KEY(profileId) REFERENCES component_profiles(id) ON UPDATE NO ACTION ON DELETE RESTRICT, FOREIGN KEY(materialId) REFERENCES component_materials(id) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("INSERT INTO component_instances_new SELECT * FROM component_instances")
                db.execSQL("DROP TABLE component_instances")
                db.execSQL("ALTER TABLE component_instances_new RENAME TO component_instances")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_component_instances_projectId ON component_instances (projectId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_component_instances_floorId ON component_instances (floorId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_component_instances_definitionId ON component_instances (definitionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_component_instances_materialId ON component_instances (materialId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_component_instances_profileId ON component_instances (profileId)")
            }
        }
        fun open(context: Context): AppDatabase = Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "ai_architecture.db")
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3).build()
    }
}
