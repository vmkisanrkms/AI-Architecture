package com.aiarchitecture.app.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(tableName="projects")
data class ProjectEntity(@PrimaryKey val id:String, val name:String, val createdAt:Long, val updatedAt:Long)
@Entity(tableName="floors", indices=[Index(value=["projectId"]), Index(value=["projectId", "id"], unique=true)])
data class FloorEntity(@PrimaryKey val id:String, val projectId:String, val name:String, val elevationMm:Double)
@Entity(tableName="building_elements", indices=[Index(value=["floorId"]),Index(value=["projectId"])])
data class ElementEntity(@PrimaryKey val id:String, val projectId:String, val floorId:String, val type:String, val xMm:Double, val yMm:Double, val zMm:Double, val lengthMm:Double, val widthMm:Double, val heightMm:Double, val material:String, val openingsJson:String, val revision:Long, val lengthProvenance:String="USER_ENTERED", val widthProvenance:String="USER_ENTERED", val heightProvenance:String="USER_ENTERED", val yawDegrees:Double=0.0 )
@Entity(tableName="edit_history", indices=[Index(value=["projectId"])])
data class EditHistoryEntity(@PrimaryKey(autoGenerate=true) val sequence:Long=0, val projectId:String, val snapshotJson:String, val createdAt:Long)


/** Component catalogue records are versioned independently from project geometry. */
@Entity(
    tableName = "component_definitions",
    foreignKeys = [
        ForeignKey(entity = ComponentMaterialEntity::class, parentColumns = ["id"], childColumns = ["defaultMaterialId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = ComponentProfileEntity::class, parentColumns = ["id"], childColumns = ["defaultProfileId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index(value = ["key"], unique = true), Index(value = ["defaultMaterialId"]), Index(value = ["defaultProfileId"])]
)
data class ComponentDefinitionEntity(
    @PrimaryKey val id: String,
    val key: String,
    val name: String,
    val category: String,
    val schemaVersion: Int,
    val geometryRecipeJson: String,
    val parametersJson: String,
    val constraintsJson: String,
    val defaultMaterialId: String?,
    val defaultProfileId: String?,
    val builtIn: Boolean,
    val updatedAt: Long
)

@Entity(
    tableName = "component_instances",
    foreignKeys = [
        ForeignKey(entity = ProjectEntity::class, parentColumns = ["id"], childColumns = ["projectId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = FloorEntity::class, parentColumns = ["projectId", "id"], childColumns = ["projectId", "floorId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = ComponentDefinitionEntity::class, parentColumns = ["id"], childColumns = ["definitionId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = ComponentProfileEntity::class, parentColumns = ["id"], childColumns = ["profileId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = ComponentMaterialEntity::class, parentColumns = ["id"], childColumns = ["materialId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index(value = ["projectId"]), Index(value = ["floorId"]), Index(value = ["definitionId"]), Index(value = ["materialId"]), Index(value = ["profileId"])]
)
data class ComponentInstanceEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val floorId: String,
    val definitionId: String,
    val name: String,
    val dimensionsJson: String,
    val transformJson: String,
    val parameterValuesJson: String,
    val dimensionProvenanceJson: String,
    val profileId: String?,
    val materialId: String?,
    val revision: Long,
    val visible: Boolean,
    val locked: Boolean,
    val updatedAt: Long
)

@Entity(tableName = "component_profiles", indices = [Index(value = ["name"])])
data class ComponentProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val kind: String,
    val pointsJson: String,
    val closed: Boolean,
    val thicknessMm: Double,
    val revision: Long,
    val updatedAt: Long
)

@Entity(tableName = "component_materials", indices = [Index(value = ["name"]), Index(value = ["category"])])
data class ComponentMaterialEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val red: Float,
    val green: Float,
    val blue: Float,
    val alpha: Float,
    val roughness: Float,
    val metallic: Float,
    val textureReference: String?,
    val updatedAt: Long
)
