package com.aiarchitecture.app.data.repository

import androidx.room.withTransaction
import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm
import com.aiarchitecture.app.core.units.DimensionProvenance
import com.aiarchitecture.app.data.local.*
import org.json.JSONArray
import org.json.JSONObject

class BuildingModelStore(private val db:AppDatabase){
    suspend fun save(model:BuildingModel){
        require(model.componentInstances.all { it.id.isNotBlank() } && model.componentInstances.map { it.id }.distinct().size == model.componentInstances.size) {
            "Duplicate or blank component instance IDs rejected before save transaction"
        }
        db.withTransaction{
        val now=System.currentTimeMillis();val existing=db.projects().getProject(model.id);db.projects().upsert(ProjectEntity(model.id,model.name,existing?.createdAt?:now,now))
        // RESTRICT foreign keys require component children to be removed before replacing their floor parents.
        db.componentInstances().deleteForProject(model.id)
        db.floors().deleteForProject(model.id);db.elements().deleteForProject(model.id)
        db.floors().upsertAll(model.floors.map{FloorEntity(it.id,model.id,it.name,it.elevationMm)})
        db.elements().upsertAll(model.floors.flatMap{floor->floor.elements.map{e->ElementEntity(e.id,model.id,e.floorId,e.type.name,e.origin.x,e.origin.y,e.origin.z,e.size.length.value,e.size.width.value,e.size.height.value,e.material,encodeOpenings(e.openings),e.revision,e.size.length.provenance.name,e.size.width.provenance.name,e.size.height.provenance.name,e.yawDegrees)}})
        ComponentPersistence(db).replaceProjectInstances(model.id, model.componentInstances)
        db.history().add(EditHistoryEntity(projectId=model.id,snapshotJson=ModelJson.encode(model),createdAt=now))
    }}
    suspend fun loadLatest():BuildingModel? = db.projects().latestProject()?.let { load(it.id) }
    suspend fun load(projectId:String):BuildingModel?{
        val project=db.projects().getProject(projectId)?:return null
        val floors=db.floors().floors(projectId);val elements=db.elements().elements(projectId).groupBy{it.floorId}
        return BuildingModel(project.id,project.name,floors.map{f->BuildingFloor(f.id,f.name,f.elevationMm,(elements[f.id]?: emptyList()).map{e->BuildingElement(e.id,e.floorId,ElementType.valueOf(e.type),Vec3(e.xMm,e.yMm,e.zMm),Size3(DimensionMm(e.lengthMm,DimensionProvenance.valueOf(e.lengthProvenance)),DimensionMm(e.widthMm,DimensionProvenance.valueOf(e.widthProvenance)),DimensionMm(e.heightMm,DimensionProvenance.valueOf(e.heightProvenance))),e.material,decodeOpenings(e.openingsJson),e.revision,e.yawDegrees)})}, ComponentPersistence(db).instances(projectId))
    }
    private fun encodeOpenings(list:List<Opening>)=JSONArray().apply{list.forEach{o->put(JSONObject().put("id",o.id).put("type",o.type.name).put("offset",o.offsetMm).put("width",o.widthMm).put("height",o.heightMm).put("sill",o.sillMm).put("provenance",o.provenance.name))}}.toString()
    private fun decodeOpenings(raw:String)=runCatching{val a=JSONArray(raw);(0 until a.length()).map{i->val o=a.getJSONObject(i);Opening(o.getString("id"),ElementType.valueOf(o.getString("type")),o.getDouble("offset"),o.getDouble("width"),o.getDouble("height"),o.getDouble("sill"),DimensionProvenance.valueOf(o.optString("provenance","USER_ENTERED")))}}.getOrDefault(emptyList())
}
object ModelJson{
    fun encode(model:BuildingModel):String=JSONObject().put("id",model.id).put("name",model.name).put("componentInstances",ComponentInstanceSnapshotCodec.encode(model.componentInstances)).put("floors",JSONArray().apply{model.floors.forEach{f->put(JSONObject().put("id",f.id).put("name",f.name).put("elevation",f.elevationMm).put("elements",JSONArray().apply{f.elements.forEach{e->put(JSONObject().put("id",e.id).put("type",e.type.name).put("x",e.origin.x).put("y",e.origin.y).put("z",e.origin.z).put("l",e.size.length.value).put("w",e.size.width.value).put("h",e.size.height.value).put("lp",e.size.length.provenance.name).put("wp",e.size.width.provenance.name).put("hp",e.size.height.provenance.name).put("material",e.material).put("revision",e.revision).put("yaw",e.yawDegrees).put("openings",JSONArray().apply{e.openings.forEach{o->put(JSONObject().put("id",o.id).put("type",o.type.name).put("offset",o.offsetMm).put("width",o.widthMm).put("height",o.heightMm).put("sill",o.sillMm).put("provenance",o.provenance.name))}}))}}))}}).toString()
    fun decode(raw:String):BuildingModel{val root=JSONObject(raw);val floors=root.optJSONArray("floors") ?: JSONArray();return BuildingModel(root.getString("id"),root.getString("name"),(0 until floors.length()).map{fi->val f=floors.getJSONObject(fi);val es=f.optJSONArray("elements") ?: JSONArray();BuildingFloor(f.getString("id"),f.getString("name"),f.getDouble("elevation"),(0 until es.length()).map{ei->val e=es.getJSONObject(ei);val os=e.optJSONArray("openings") ?: JSONArray();BuildingElement(e.getString("id"),f.getString("id"),ElementType.valueOf(e.getString("type")),Vec3(e.getDouble("x"),e.getDouble("y"),e.getDouble("z")),Size3(DimensionMm(e.getDouble("l"),DimensionProvenance.valueOf(e.optString("lp","USER_ENTERED"))),DimensionMm(e.getDouble("w"),DimensionProvenance.valueOf(e.optString("wp","USER_ENTERED"))),DimensionMm(e.getDouble("h"),DimensionProvenance.valueOf(e.optString("hp","USER_ENTERED")))),e.getString("material"),(0 until os.length()).map{oi->val o=os.getJSONObject(oi);Opening(o.getString("id"),ElementType.valueOf(o.getString("type")),o.getDouble("offset"),o.getDouble("width"),o.getDouble("height"),o.getDouble("sill"),DimensionProvenance.valueOf(o.optString("provenance","USER_ENTERED")))},e.getLong("revision"),e.optDouble("yaw",0.0))})},ComponentInstanceSnapshotCodec.decode(root.optJSONArray("componentInstances")))}
}
