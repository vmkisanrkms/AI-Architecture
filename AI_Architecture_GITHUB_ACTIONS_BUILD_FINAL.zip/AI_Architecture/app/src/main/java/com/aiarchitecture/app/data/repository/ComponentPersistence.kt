package com.aiarchitecture.app.data.repository

import androidx.room.withTransaction
import com.aiarchitecture.app.core.components.*
import com.aiarchitecture.app.core.geometry.BuildingModel
import com.aiarchitecture.app.data.local.*
import org.json.JSONArray
import org.json.JSONObject

/** Validates and persists the reusable parametric catalogue and project instances. */
class ComponentPersistence(private val db: AppDatabase) {
    suspend fun saveDefinition(definition: ComponentDefinition) {
        validateDefinitionStructure(definition)
        db.withTransaction {
            require(definition.defaultMaterialId == null || db.componentMaterials().get(definition.defaultMaterialId) != null) { "Default material does not exist" }
            require(definition.defaultProfileId == null || db.componentProfiles().get(definition.defaultProfileId) != null) { "Default profile does not exist" }
            val keyOwner = db.componentDefinitions().getByKey(definition.key)
            require(keyOwner == null || keyOwner.id == definition.id) { "Definition key already belongs to ${keyOwner?.id}; replacement by another ID is forbidden" }
            val now = System.currentTimeMillis()
            val entity = definition.toEntity(now)
            if (db.componentDefinitions().get(definition.id) == null) db.componentDefinitions().insertNew(entity)
            else check(db.componentDefinitions().updateExisting(entity) == 1) { "Definition disappeared during update" }
        }
    }

    private fun validateDefinitionStructure(definition: ComponentDefinition) {
        require(definition.parameters.all { it.key.isNotBlank() } && definition.parameters.map { it.key }.distinct().size == definition.parameters.size) { "Parameter keys must be non-blank and unique" }
        require(definition.constraints.all { it.id.isNotBlank() } && definition.constraints.map { it.id }.distinct().size == definition.constraints.size) { "Constraint IDs must be non-blank and unique" }
        val declared = definition.parameters.map { it.key }.toSet()
        definition.constraints.forEach { c ->
            val used = when (val r = c.rule) {
                is ConstraintRule.GreaterThan -> setOf(r.key)
                is ConstraintRule.LessThanOrEqual -> setOf(r.key)
                is ConstraintRule.LessThanOrEqualRatio -> setOf(r.numeratorKey, r.denominatorKey)
                is ConstraintRule.EnumIsOneOf -> setOf(r.key)
            }
            require(used.all { it in declared } && c.parameterKeys == used) { "Constraint ${c.id} has missing or unknown referenced parameter keys" }
            require(c.message.isNotBlank()) { "Constraint ${c.id} message is required" }
            when (val r = c.rule) {
                is ConstraintRule.GreaterThan -> require(r.minimumExclusive.isFinite()) { "GreaterThan threshold must be finite" }
                is ConstraintRule.LessThanOrEqual -> require(r.maximumInclusive.isFinite()) { "LessThanOrEqual threshold must be finite" }
                is ConstraintRule.LessThanOrEqualRatio -> require(r.maximumRatio.isFinite() && r.maximumRatio >= 0.0) { "Ratio maximum must be finite and non-negative" }
                is ConstraintRule.EnumIsOneOf -> require(r.values.isNotEmpty()) { "Enum constraint values are required" }
            }
        }
    }
    suspend fun saveProfile(profile: CustomProfile) {
        require(profile.validate().isEmpty()) { profile.validate().joinToString("; ") }
        db.withTransaction {
            val entity = profile.toEntity(System.currentTimeMillis())
            if (db.componentProfiles().get(profile.id) == null) db.componentProfiles().insertNew(entity)
            else check(db.componentProfiles().updateExisting(entity) == 1) { "Profile disappeared during update" }
        }
    }
    suspend fun saveMaterial(material: MaterialDescriptor) {
        require(material.validate().isEmpty()) { material.validate().joinToString("; ") }
        db.withTransaction {
            val entity = material.toEntity(System.currentTimeMillis())
            if (db.componentMaterials().get(material.id) == null) db.componentMaterials().insertNew(entity)
            else check(db.componentMaterials().updateExisting(entity) == 1) { "Material disappeared during update" }
        }
    }
    private suspend fun validateInstance(instance: ComponentInstance, expectedProjectId: String? = null) {
        require(expectedProjectId == null || instance.projectId == expectedProjectId) { "Component instance belongs to a different project" }
        require(db.projects().getProject(instance.projectId) != null) { "Component project does not exist" }
        require(db.floors().floors(instance.projectId).any { it.id == instance.floorId }) { "Component floor does not belong to the project" }
        val definition = db.componentDefinitions().get(instance.definitionId)
            ?: throw IllegalArgumentException("Component definition not found: ${instance.definitionId}")
        val errors = ComponentValidator.validate(definition.toDomain(), instance).errors
        require(errors.isEmpty()) { errors.joinToString("; ") }
        require(instance.profileId == null || db.componentProfiles().get(instance.profileId) != null) { "Referenced profile does not exist" }
        require(instance.materialId == null || db.componentMaterials().get(instance.materialId) != null) { "Referenced material does not exist" }
    }

    suspend fun saveInstance(instance: ComponentInstance) = db.withTransaction {
        validateInstance(instance)
        db.componentInstances().insertNew(instance.toEntity(System.currentTimeMillis()))
    }

    /** Deletion policy: RESTRICT. A referenced profile cannot be deleted until all instances and definition defaults release it. */
    suspend fun deleteProfile(id: String) = db.withTransaction {
        require(db.componentInstances().profileReferenceCount(id) == 0 && db.componentProfiles().defaultReferenceCount(id) == 0) {
            "Profile $id is referenced; deletion is restricted"
        }
        db.componentProfiles().delete(id)
    }

    /** Deletion policy: RESTRICT. A referenced material cannot be deleted until all references are cleared. */
    suspend fun deleteMaterial(id: String) = db.withTransaction {
        require(db.componentInstances().materialReferenceCount(id) == 0 && db.componentMaterials().defaultReferenceCount(id) == 0) {
            "Material $id is referenced; deletion is restricted"
        }
        db.componentMaterials().delete(id)
    }

    /** Deletion policy: RESTRICT. Built-ins and definitions used by instances cannot be deleted. */
    suspend fun deleteDefinition(id: String) = db.withTransaction {
        val definition = db.componentDefinitions().get(id) ?: return@withTransaction
        require(!definition.builtIn) { "Built-in definitions cannot be deleted" }
        require(db.componentDefinitions().instanceReferenceCount(id) == 0) { "Definition $id is referenced; deletion is restricted" }
        db.componentDefinitions().deleteCustom(id)
    }

    suspend fun saveBuiltInsIfMissing() {
        val existing = db.componentDefinitions().all().map { it.id }.toSet()
        val missing = BuiltInComponentDefinitions.all.filterNot { it.id in existing }
        // Route catalogue inserts through the same key/reference validation as custom definitions.
        missing.forEach { saveDefinition(it) }
    }
    suspend fun definitions(): List<ComponentDefinition> = db.componentDefinitions().all().map { it.toDomain() }
    suspend fun profiles(): List<CustomProfile> = db.componentProfiles().all().map { it.toDomain() }
    suspend fun materials(): List<MaterialDescriptor> = db.componentMaterials().all().map { it.toDomain() }
    suspend fun instances(projectId: String): List<ComponentInstance> = db.componentInstances().forProject(projectId).map { it.toDomain() }

    internal suspend fun replaceProjectInstances(projectId: String, instances: List<ComponentInstance>) {
        // Reject duplicate IDs before opening the destructive delete/insert transaction.
        require(instances.all { it.id.isNotBlank() } && instances.map { it.id }.distinct().size == instances.size) {
            "Duplicate or blank component instance IDs are not allowed"
        }
        db.withTransaction {
            saveBuiltInsIfMissing()
            instances.forEach { validateInstance(it, projectId) }
            db.componentInstances().deleteForProject(projectId)
            if (instances.isNotEmpty()) db.componentInstances().insertNewAll(instances.map { it.toEntity(System.currentTimeMillis()) })
        }
    }

}

private fun ComponentDefinition.toEntity(now: Long) = ComponentDefinitionEntity(id,key,name,category.name,schemaVersion,recipeJson(geometryRecipe),parametersJson(parameters),constraintsJson(constraints),defaultMaterialId,defaultProfileId,builtIn,now)
private fun ComponentDefinitionEntity.toDomain() = ComponentDefinition(id,key,name,ComponentCategory.valueOf(category),schemaVersion,readRecipe(geometryRecipeJson),readParameters(parametersJson),readConstraints(constraintsJson),defaultMaterialId,defaultProfileId,builtIn)
private fun ComponentInstance.toEntity(now: Long) = ComponentInstanceEntity(id,projectId,floorId,definitionId,name,dimensionsJson(dimensions),transformJson(transform),valuesJson(parameterValues),provenanceJson(dimensionProvenance),profileId,materialId,revision,visible,locked,now)
private fun ComponentInstanceEntity.toDomain() = ComponentInstance(id,projectId,floorId,definitionId,name,readDimensions(dimensionsJson),readTransform(transformJson),profileId,materialId,readValues(parameterValuesJson),readProvenance(dimensionProvenanceJson),revision,visible,locked)
private fun CustomProfile.toEntity(now: Long) = ComponentProfileEntity(id,name,kind.name,JSONArray().apply { points.forEach { put(JSONObject().put("x",it.xMm).put("y",it.yMm)) } }.toString(),closed,thicknessMm,revision,now)
private fun ComponentProfileEntity.toDomain() = CustomProfile(id,name,ProfileKind.valueOf(kind), (0 until JSONArray(pointsJson).length()).map { val p=JSONArray(pointsJson).getJSONObject(it); ProfilePoint(p.getDouble("x"),p.getDouble("y")) },closed,thicknessMm,revision)
private fun MaterialDescriptor.toEntity(now: Long) = ComponentMaterialEntity(id,name,category.name,red,green,blue,alpha,roughness,metallic,textureReference,now)
private fun ComponentMaterialEntity.toDomain() = MaterialDescriptor(id,name,MaterialCategory.valueOf(category),red,green,blue,alpha,roughness,metallic,textureReference)

private fun recipeJson(r: GeometryRecipe) = JSONObject().put("type",r.type.name).put("options",JSONObject(r.options)).put("version",r.generatorVersion).toString()
private fun readRecipe(raw:String): GeometryRecipe { val o=JSONObject(raw); val options=o.getJSONObject("options"); return GeometryRecipe(GeometryRecipeType.valueOf(o.getString("type")), options.keys().asSequence().associateWith { options.getString(it) },o.optInt("version",1)) }
private fun parametersJson(items:List<ParameterDefinition>) = JSONArray().apply { items.forEach { p -> put(JSONObject().put("key",p.key).put("label",p.label).put("type",p.valueType.name).put("unit",p.unit.name).put("default",p.defaultValue).put("min",p.minimum).put("max",p.maximum).put("step",p.step).put("required",p.required).put("geometry",p.affectsGeometry).put("plan",p.affectsPlan).put("allowed",JSONArray(p.allowedValues))) } }.toString()
private fun readParameters(raw:String) = (0 until JSONArray(raw).length()).map { i -> val p=JSONArray(raw).getJSONObject(i); ParameterDefinition(p.getString("key"),p.getString("label"),ParameterValueType.valueOf(p.getString("type")),ParameterUnit.valueOf(p.getString("unit")),p.getString("default"),p.nullableDouble("min"),p.nullableDouble("max"),p.nullableDouble("step"),p.optBoolean("required",true),p.optBoolean("geometry",true),p.optBoolean("plan",true),(0 until p.getJSONArray("allowed").length()).map { p.getJSONArray("allowed").getString(it) }) }
private fun constraintsJson(items:List<ComponentConstraint>) = JSONArray().apply { items.forEach { c -> val rule=when(val r=c.rule) { is ConstraintRule.GreaterThan -> JSONObject().put("type","gt").put("key",r.key).put("value",r.minimumExclusive); is ConstraintRule.LessThanOrEqual -> JSONObject().put("type","lte").put("key",r.key).put("value",r.maximumInclusive); is ConstraintRule.LessThanOrEqualRatio -> JSONObject().put("type","ratio").put("numerator",r.numeratorKey).put("denominator",r.denominatorKey).put("value",r.maximumRatio); is ConstraintRule.EnumIsOneOf -> JSONObject().put("type","enum").put("key",r.key).put("values",JSONArray(r.values.toList())) }; put(JSONObject().put("id",c.id).put("keys",JSONArray(c.parameterKeys.toList())).put("message",c.message).put("rule",rule)) } }.toString()
private fun readConstraints(raw:String) = (0 until JSONArray(raw).length()).map { i -> val c=JSONArray(raw).getJSONObject(i); val r=c.getJSONObject("rule"); val rule:ConstraintRule=when(r.getString("type")) { "gt" -> ConstraintRule.GreaterThan(r.getString("key"),r.getDouble("value")); "lte" -> ConstraintRule.LessThanOrEqual(r.getString("key"),r.getDouble("value")); "ratio" -> ConstraintRule.LessThanOrEqualRatio(r.getString("numerator"),r.getString("denominator"),r.getDouble("value")); "enum" -> ConstraintRule.EnumIsOneOf(r.getString("key"),(0 until r.getJSONArray("values").length()).map { r.getJSONArray("values").getString(it) }.toSet()); else -> error("Unknown constraint type") }; ComponentConstraint(c.getString("id"),(0 until c.getJSONArray("keys").length()).map { c.getJSONArray("keys").getString(it) }.toSet(),rule,c.getString("message")) }
private fun dimensionsJson(d:DimensionsMm)=JSONObject().put("l",d.length).put("h",d.height).put("w",d.width).put("t",d.thickness).toString()
private fun readDimensions(raw:String):DimensionsMm { val o=JSONObject(raw); return DimensionsMm(o.getDouble("l"),o.getDouble("h"),o.getDouble("w"),o.getDouble("t")) }
private fun transformJson(t:Transform3D)=JSONObject().put("x",t.xMm).put("y",t.yMm).put("z",t.zMm).put("rx",t.rotationXDegrees).put("ry",t.rotationYDegrees).put("rz",t.rotationZDegrees).put("sx",t.scaleX).put("sy",t.scaleY).put("sz",t.scaleZ).toString()
private fun readTransform(raw:String):Transform3D { val o=JSONObject(raw); return Transform3D(o.getDouble("x"),o.getDouble("y"),o.getDouble("z"),o.getDouble("rx"),o.getDouble("ry"),o.getDouble("rz"),o.getDouble("sx"),o.getDouble("sy"),o.getDouble("sz")) }
private fun valuesJson(values:Map<String,ParameterValue>)=JSONObject().apply { values.forEach { (k,v)->put(k,JSONObject().put("key",v.key).put("value",v.value).put("provenance",v.provenance.name)) } }.toString()
private fun readValues(raw:String):Map<String,ParameterValue> { val o=JSONObject(raw); return o.keys().asSequence().associateWith { k -> val v=o.getJSONObject(k); ParameterValue(v.getString("key"),v.getString("value"),DimensionProvenance.valueOf(v.optString("provenance","USER_ENTERED"))) } }
private fun provenanceJson(values:Map<String,DimensionProvenance>)=JSONObject().apply { values.forEach { (k,v)->put(k,v.name) } }.toString()
private fun readProvenance(raw:String):Map<String,DimensionProvenance> { val o=JSONObject(raw); return o.keys().asSequence().associateWith { DimensionProvenance.valueOf(o.getString(it)) } }
private fun JSONObject.nullableDouble(key:String):Double? = if (isNull(key)) null else optDouble(key)

/** Shared snapshot codec keeps edit-history snapshots aligned with the persisted BuildingModel. */
object ComponentInstanceSnapshotCodec {
    fun encode(items: List<ComponentInstance>): JSONArray = JSONArray().apply {
        items.forEach { item ->
            put(JSONObject().put("id",item.id).put("projectId",item.projectId).put("floorId",item.floorId)
                .put("definitionId",item.definitionId).put("name",item.name)
                .put("dimensions",JSONObject(dimensionsJson(item.dimensions)))
                .put("transform",JSONObject(transformJson(item.transform)))
                .put("profileId",item.profileId).put("materialId",item.materialId)
                .put("parameterValues",JSONObject(valuesJson(item.parameterValues)))
                .put("dimensionProvenance",JSONObject(provenanceJson(item.dimensionProvenance)))
                .put("revision",item.revision).put("visible",item.visible).put("locked",item.locked))
        }
    }
    fun decode(array: JSONArray?): List<ComponentInstance> {
        if (array == null) return emptyList()
        return (0 until array.length()).map { i ->
            val o=array.getJSONObject(i)
            ComponentInstance(o.getString("id"),o.getString("projectId"),o.getString("floorId"),o.getString("definitionId"),o.getString("name"),
                readDimensions(o.getJSONObject("dimensions").toString()),readTransform(o.getJSONObject("transform").toString()),
                o.optString("profileId").takeIf { it.isNotBlank() && it != "null" },o.optString("materialId").takeIf { it.isNotBlank() && it != "null" },
                readValues(o.getJSONObject("parameterValues").toString()),readProvenance(o.getJSONObject("dimensionProvenance").toString()),
                o.optLong("revision",0),o.optBoolean("visible",true),o.optBoolean("locked",false))
        }
    }
}
