package com.aiarchitecture.app.feature.backup

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.room.Room
import com.aiarchitecture.app.core.geometry.BuildingModel
import com.aiarchitecture.app.data.local.AppDatabase
import com.aiarchitecture.app.data.repository.BuildingModelStore
import java.io.File

@Composable
fun BackupRestoreScreen(onBack: () -> Unit = {}) {
    val context = LocalContext.current
    val db = remember { AppDatabase.open(context) }
    val store = remember { BuildingModelStore(db) }
    var model by remember { mutableStateOf<BuildingModel?>(null) }
    val images = remember { mutableStateMapOf<String, ByteArray>() }
    var status by remember { mutableStateOf("Loading current project…") }
    val scope = rememberCoroutineScope()

    val addImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val bytes = requireNotNull(context.contentResolver.openInputStream(uri)).use {
                it.readBounded(BackupRestoreManager.MAX_BACKUP_BYTES)
            }
            require(bytes.isNotEmpty()) { "Selected image is empty" }
            val name = "attachment_${images.size + 1}.bin"
            images[name] = bytes
        }.onSuccess { status = "Image added to backup (${images.size})" }
            .onFailure { status = "Image could not be added: ${it.message}" }
    }

    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) status = "Backup cancelled"
        else runCatching {
            val current = requireNotNull(model) { "No project model is available" }
            val bytes = BackupRestoreManager.createBackup(current, images.toMap())
            require(bytes.size.toLong() <= BackupRestoreManager.MAX_BACKUP_BYTES) { "Backup exceeds size limit" }
            requireNotNull(context.contentResolver.openOutputStream(uri)).use { it.write(bytes) }
        }.onSuccess { status = "JSON backup exported with ${images.size} image attachment(s)" }
            .onFailure { status = "Backup failed: ${it.message}" }
    }

    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val parsed = runCatching {
                val bytes = requireNotNull(context.contentResolver.openInputStream(uri)).use {
                    it.readBounded(BackupRestoreManager.MAX_BACKUP_BYTES)
                }
                BackupRestoreManager.restoreBundle(bytes)
            }
            parsed.onSuccess { restored ->
                scope.launch {
                    runCatching {
                        store.save(restored.model)
                        val imageDir = File(context.filesDir, "restored-backup-images").apply { mkdirs() }
                        restored.images.forEach { (name, data) ->
                            val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                            File(imageDir, safeName).writeBytes(data)
                        }
                    }.onSuccess {
                        model = restored.model
                        images.clear()
                        images.putAll(restored.images)
                        status = "Restored ${restored.model.name} and ${restored.images.size} image attachment(s)"
                    }.onFailure { status = "Restore failed: ${it.message}" }
                }
            }.onFailure { status = "Restore rejected: ${it.message}" }
        }
    }

    LaunchedEffect(Unit) {
        model = runCatching { store.loadLatest() }.getOrNull() ?: BuildingModel.starter()
        status = "Ready — local JSON backup"
    }

    Column(Modifier.fillMaxSize().padding(20.dp).testTag("destination-backup-restore"), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Backup and Restore", style = MaterialTheme.typography.headlineSmall)
        Text("Backup contains the canonical project model, floors, elements, wall openings and optional image attachments. SHA-256 is checked before restore.")
        Text(status, style = MaterialTheme.typography.bodyMedium)
        model?.let { current ->
            Text("Project: ${current.name}")
            Text("Floors: ${current.floors.size}  •  Elements: ${current.floors.sumOf { it.elements.size }}")
        }
        OutlinedButton(onClick = { addImage.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text("Add image attachment (${images.size})")
        }
        Button(onClick = { export.launch("AI_Architecture_Backup.json") }, enabled = model != null, modifier = Modifier.fillMaxWidth()) {
            Text("Create JSON Backup")
        }
        OutlinedButton(onClick = { restore.launch(arrayOf("application/json", "text/json")) }, modifier = Modifier.fillMaxWidth()) {
            Text("Restore JSON Backup")
        }
        OutlinedButton(onClick = onBack) { Text("Back") }
    }
}
