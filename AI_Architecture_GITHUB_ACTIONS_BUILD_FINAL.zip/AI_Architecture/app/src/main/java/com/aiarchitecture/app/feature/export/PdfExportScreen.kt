package com.aiarchitecture.app.feature.export

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.room.Room
import com.aiarchitecture.app.core.geometry.BuildingModel
import com.aiarchitecture.app.data.local.AppDatabase
import com.aiarchitecture.app.data.repository.BuildingModelStore

@Composable
fun PdfExportScreen(onBack: () -> Unit = {}) {
    val context = LocalContext.current
    val db = remember { AppDatabase.open(context) }
    val store = remember { BuildingModelStore(db) }
    var model by remember { mutableStateOf<BuildingModel?>(null) }
    var status by remember { mutableStateOf("Loading current project…") }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri == null) status = "PDF export cancelled"
        else runCatching {
            val current = requireNotNull(model) { "No project model is available" }
            val bytes = DimensionedPdfExporter.render(current)
            require(bytes.size > 8 && bytes.copyOfRange(0, 4).toString(Charsets.US_ASCII) == "%PDF") {
                "PDF generator returned invalid output"
            }
            requireNotNull(context.contentResolver.openOutputStream(uri)).use { it.write(bytes) }
        }.onSuccess { status = "Dimensioned PDF exported successfully" }
            .onFailure { status = "PDF export failed: ${it.message}" }
    }
    LaunchedEffect(Unit) {
        model = runCatching { store.loadLatest() }.getOrNull() ?: BuildingModel.starter()
        status = "Ready — ${model?.floors?.sumOf { it.elements.size } ?: 0} editable elements"
    }
    Column(Modifier.fillMaxSize().padding(20.dp).testTag("destination-pdf-reports"), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Export and Reports", style = MaterialTheme.typography.headlineSmall)
        Text("Creates a vector PDF directly from the current Room-saved canonical building model. Dimensions remain in millimetres.")
        Text(status, style = MaterialTheme.typography.bodyMedium)
        model?.let { current ->
            Text("Project: ${current.name}")
            Text("Floors: ${current.floors.size}  •  Elements: ${current.floors.sumOf { it.elements.size }}")
            Button(onClick = { export.launch("AI_Architecture_Dimensions.pdf") }, modifier = Modifier.fillMaxWidth()) {
                Text("Generate and Save Dimensioned PDF")
            }
        }
        OutlinedButton(onClick = onBack) { Text("Back") }
    }
}
