package com.aiarchitecture.app.navigation

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import androidx.room.Room
import com.aiarchitecture.app.data.local.AppDatabase
import com.aiarchitecture.app.data.repository.ProjectRepository
import com.aiarchitecture.app.feature.backup.BackupRestoreScreen
import com.aiarchitecture.app.feature.components.ComponentLibraryScreen
import com.aiarchitecture.app.feature.editor.BlueprintEditorScreen
import com.aiarchitecture.app.feature.export.PdfExportScreen
import com.aiarchitecture.app.feature.projects.ProjectsScreen
import com.aiarchitecture.app.feature.shell.*

@Composable
fun AppNavHost(startDestinationOverride: String? = null) {
    val nav = rememberNavController()
    val context = LocalContext.current
    val database = remember { AppDatabase.open(context) }
    val repository = remember { ProjectRepository(database) }
    DisposableEffect(database) { onDispose { database.close() } }
    var language by remember { mutableStateOf(AppStrings.language(context)) }
    val startDestination = startDestinationOverride
        ?: AppStrings.coldStartDestination(context)

    NavHost(navController = nav, startDestination = startDestination) {
        composable("splash") {
            SplashScreen(language) { nav.navigate("language") { popUpTo("splash") { inclusive = true } } }
        }
        composable("language") {
            LanguageScreen(language) { selected ->
                language = selected
                AppStrings.setLanguage(context, selected)
                nav.navigate("home") { popUpTo("language") { inclusive = true } }
            }
        }
        composable("home") {
            HomeDashboard(language) { route -> nav.navigate("screen/$route") }
        }
        composable("editor") {
            Box(Modifier.fillMaxSize().testTag("destination-blueprint-editor")) { BlueprintEditorScreen() }
        }
        composable("editor/{projectId}", arguments = listOf(navArgument("projectId") { type = NavType.StringType })) { entry ->
            Box(Modifier.fillMaxSize().testTag("destination-blueprint-editor")) {
                BlueprintEditorScreen(entry.arguments?.getString("projectId"))
            }
        }
        composable("projects") {
            ProjectsScreen(repository) { id -> nav.navigate("editor/$id") }
        }
        composable("components") {
            Box(Modifier.fillMaxSize().testTag("destination-component-library")) {
                ComponentLibraryScreen(onInsert = { nav.navigate("editor") })
            }
        }
        composable("screen/{route}", arguments = listOf(navArgument("route") { type = NavType.StringType })) { entry ->
            val route = entry.arguments?.getString("route").orEmpty()
            when (ScreenCatalog.destination(route)) {
                ScreenDestination.AI_GENERATOR -> AiDesignGeneratorDestination()
                ScreenDestination.PHOTO_ANALYSIS -> PhotoAnalysisDestination()
                ScreenDestination.FLOOR_PLANNER -> FloorPlannerDestination { nav.navigate("projects") }
                ScreenDestination.BLUEPRINT_EDITOR -> Box(Modifier.fillMaxSize().testTag("destination-blueprint-editor")) { BlueprintEditorScreen() }
                ScreenDestination.THREE_D_DESIGNER -> ThreeDDesignerDestination()
                ScreenDestination.GATE_DESIGNER -> GateDesignerDestination()
                ScreenDestination.ARCH_DESIGNER -> ArchDesignerDestination()
                ScreenDestination.INTERIOR_DESIGNER -> InteriorDesignerDestination()
                ScreenDestination.KITCHEN_DESIGNER -> KitchenDesignerDestination()
                ScreenDestination.BATHROOM_DESIGNER -> BathroomDesignerDestination()
                ScreenDestination.BOUNDARY_WALL -> BoundaryWallDestination()
                ScreenDestination.MATERIAL_CALCULATOR -> MaterialCalculatorDestination()
                ScreenDestination.PROJECTS_GALLERY -> ProjectsScreen(repository) { id -> nav.navigate("editor/$id") }
                ScreenDestination.PDF_EXPORT -> PdfExportScreen { nav.popBackStack() }
                ScreenDestination.SETTINGS -> SettingsScreen(language) { nav.navigate("language") }
                ScreenDestination.BACKUP_RESTORE -> BackupRestoreScreen { nav.popBackStack() }
                ScreenDestination.OFFLINE_MODEL_MANAGER -> OfflineModelManagerDestination()
                ScreenDestination.COMPONENT_LIBRARY -> ComponentLibraryDestination { nav.navigate("editor") }
                ScreenDestination.SPLASH -> SplashScreen(language) { nav.navigate("language") }
                ScreenDestination.LANGUAGE -> LanguageScreen(language) { selected ->
                    language = selected
                    AppStrings.setLanguage(context, selected)
                    nav.navigate("home") { launchSingleTop = true }
                }
                ScreenDestination.HOME -> HomeDashboard(language) { target -> nav.navigate("screen/$target") }
                null -> Column(Modifier.fillMaxSize().padding(24.dp)) {
                    Text(AppStrings.text(language, "Screen not found", "स्क्रीन नहीं मिली"))
                    Button(onClick = { nav.popBackStack() }) { Text(AppStrings.text(language, "Back", "वापस")) }
                }
            }
        }
    }
}
