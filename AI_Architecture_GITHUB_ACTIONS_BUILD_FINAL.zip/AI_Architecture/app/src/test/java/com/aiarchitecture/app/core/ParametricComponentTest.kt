package com.aiarchitecture.app.core

import com.aiarchitecture.app.core.components.*
import org.junit.Assert.*
import org.junit.Test

class ParametricComponentTest {
    private val glassDefinition = BuiltInComponentDefinitions.all.first { it.key == "glass-railing" }
    private fun glassInstance() = ComponentInstance(
        projectId = "project-1", floorId = "floor-1", definitionId = glassDefinition.id,
        name = "Balcony glass railing", dimensions = DimensionsMm(3000.0, 1050.0, 100.0, 12.0),
        parameterValues = mapOf(
            "panelThicknessMm" to ParameterValue("panelThicknessMm", "12"),
            "postSpacingMm" to ParameterValue("postSpacingMm", "1000"),
            "railingHeightMm" to ParameterValue("railingHeightMm", "1050")
        )
    )

    @Test fun builtInCatalogueContainsRequiredFamilies() {
        assertTrue(BuiltInComponentDefinitions.all.map { it.key }.containsAll(
            listOf("glass-railing", "steel-railing", "bracket", "clamp", "post", "gate", "pillar", "arch", "staircase", "door", "window")
        ))
    }

    @Test fun validComponentPassesValidation() {
        assertTrue(ComponentValidator.validate(glassDefinition, glassInstance()).isValid)
    }

    @Test fun rejectsNonPositiveDimensions() {
        val invalid = glassInstance().copy(dimensions = DimensionsMm(0.0, 1050.0, 100.0, -2.0))
        assertFalse(ComponentValidator.validate(glassDefinition, invalid).isValid)
    }

    @Test fun rejectsUnknownAndOutOfRangeParameters() {
        val invalid = glassInstance().copy(parameterValues = glassInstance().parameterValues +
            ("unknown" to ParameterValue("unknown", "1")) +
            ("postSpacingMm" to ParameterValue("postSpacingMm", "NaN")))
        assertFalse(ComponentValidator.validate(glassDefinition, invalid).isValid)
    }

    @Test fun physicalResizeChangesDimensionsNotScale() {
        val resized = ComponentTransformOperations.resize(glassInstance(), DimensionsMm(4000.0, 1100.0, 120.0, 15.0))
        assertEquals(4000.0, resized.dimensions.length, 0.0)
        assertEquals(1.0, resized.transform.scaleX, 0.0)
        assertEquals(1L, resized.revision)
    }


    @Test fun visualScaleChangesOnlyVisualTransformAndIncrementsRevision() {
        val original = glassInstance()
        val scaled = ComponentTransformOperations.setVisualScale(original, 1.5, 2.0, 0.75)
        assertEquals(original.dimensions, scaled.dimensions)
        assertEquals(1.5, scaled.transform.scaleX, 0.0)
        assertEquals(2.0, scaled.transform.scaleY, 0.0)
        assertEquals(0.75, scaled.transform.scaleZ, 0.0)
        assertEquals(original.revision + 1, scaled.revision)
    }

    @Test fun visualScaleRejectsZeroNegativeNanAndInfinityWithoutChangingOriginal() {
        val original = glassInstance()
        val invalidScales = listOf(0.0, -1.0, Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY)
        invalidScales.forEach { invalid ->
            assertThrows(IllegalArgumentException::class.java) {
                ComponentTransformOperations.setVisualScale(original, invalid, 1.0, 1.0)
            }
            assertThrows(IllegalArgumentException::class.java) {
                ComponentTransformOperations.setVisualScale(original, 1.0, invalid, 1.0)
            }
            assertThrows(IllegalArgumentException::class.java) {
                ComponentTransformOperations.setVisualScale(original, 1.0, 1.0, invalid)
            }
        }
        assertEquals(0L, original.revision)
        assertEquals(1.0, original.transform.scaleX, 0.0)
    }

    @Test fun moveAndRotateUpdateTransformAndRevision() {
        val moved = ComponentTransformOperations.move(glassInstance(), 100.0, 200.0, 300.0)
        val rotated = ComponentTransformOperations.rotate(moved, 10.0, 20.0, 30.0)
        assertEquals(100.0, rotated.transform.xMm, 0.0)
        assertEquals(30.0, rotated.transform.rotationZDegrees, 0.0)
        assertEquals(2L, rotated.revision)
    }

    @Test fun customProfileRejectsZeroLengthEdges() {
        val profile = CustomProfile(name = "Bad", kind = ProfileKind.CLOSED_POLYGON,
            points = listOf(ProfilePoint(0.0, 0.0), ProfilePoint(0.0, 0.0), ProfilePoint(10.0, 10.0)), closed = true)
        assertTrue(profile.validate().any { it.contains("zero-length") })
    }

    @Test fun materialChannelsAreRangeChecked() {
        val material = MaterialDescriptor(name = "Invalid", category = MaterialCategory.GLASS,
            red = 1.2f, green = 0.0f, blue = 0.0f)
        assertFalse(material.validate().isEmpty())
    }

    private fun constrainedDefinition(rule: ConstraintRule, parameterKeys: Set<String> = when (rule) {
        is ConstraintRule.GreaterThan -> setOf(rule.key)
        is ConstraintRule.LessThanOrEqual -> setOf(rule.key)
        is ConstraintRule.LessThanOrEqualRatio -> setOf(rule.numeratorKey, rule.denominatorKey)
        is ConstraintRule.EnumIsOneOf -> setOf(rule.key)
    }, parameters: List<ParameterDefinition> = listOf(
        ParameterDefinition("a", "A", ParameterValueType.NUMBER, defaultValue = "5"),
        ParameterDefinition("b", "B", ParameterValueType.NUMBER, defaultValue = "2"),
        ParameterDefinition("kind", "Kind", ParameterValueType.ENUM, defaultValue = "X", allowedValues = listOf("X", "Y"))
    )): ComponentDefinition = glassDefinition.copy(
        parameters = parameters,
        constraints = listOf(ComponentConstraint(id = "constraint-1", parameterKeys = parameterKeys, rule = rule, message = "Constraint failed"))
    )

    private fun instanceFor(definition: ComponentDefinition, values: Map<String, String>): ComponentInstance = glassInstance().copy(
        definitionId = definition.id,
        parameterValues = values.mapValues { (key, value) -> ParameterValue(key, value) }
    )

    @Test fun greaterThanRejectsMissingAndInvalidParameters() {
        val definition = constrainedDefinition(ConstraintRule.GreaterThan("a", 1.0))
        assertFalse(ComponentValidator.validate(definition, instanceFor(definition, mapOf("b" to "2", "kind" to "X"))).isValid)
        assertFalse(ComponentValidator.validate(definition, instanceFor(definition, mapOf("a" to "NaN", "b" to "2", "kind" to "X"))).isValid)
    }

    @Test fun lessThanOrEqualRejectsMissingAndInvalidParameters() {
        val definition = constrainedDefinition(ConstraintRule.LessThanOrEqual("a", 10.0))
        assertFalse(ComponentValidator.validate(definition, instanceFor(definition, mapOf("b" to "2", "kind" to "X"))).isValid)
        assertFalse(ComponentValidator.validate(definition, instanceFor(definition, mapOf("a" to "Infinity", "b" to "2", "kind" to "X"))).isValid)
    }

    @Test fun ratioRequiresBothValidParametersAndPositiveDenominator() {
        val definition = constrainedDefinition(ConstraintRule.LessThanOrEqualRatio("a", "b", 4.0))
        assertFalse(ComponentValidator.validate(definition, instanceFor(definition, mapOf("a" to "4", "kind" to "X"))).isValid)
        assertFalse(ComponentValidator.validate(definition, instanceFor(definition, mapOf("a" to "4", "b" to "NaN", "kind" to "X"))).isValid)
        assertFalse(ComponentValidator.validate(definition, instanceFor(definition, mapOf("a" to "Infinity", "b" to "2", "kind" to "X"))).isValid)
        listOf("0", "-1").forEach { denominator ->
            assertFalse(ComponentValidator.validate(definition, instanceFor(definition, mapOf("a" to "4", "b" to denominator, "kind" to "X"))).isValid)
        }
    }

    @Test fun enumConstraintRejectsMissingParameter() {
        val definition = constrainedDefinition(ConstraintRule.EnumIsOneOf("kind", setOf("X", "Y")))
        assertFalse(ComponentValidator.validate(definition, instanceFor(definition, mapOf("a" to "5", "b" to "2"))).isValid)
    }

    @Test fun constraintDefinitionMustDeclareEveryReferencedKey() {
        val definition = constrainedDefinition(ConstraintRule.LessThanOrEqualRatio("a", "b", 2.0), parameterKeys = setOf("a"))
        val result = ComponentValidator.validate(definition, instanceFor(definition, mapOf("a" to "1", "b" to "2", "kind" to "X")))
        assertTrue(result.errors.any { it.contains("parameterKeys missing reference: b") })
    }

    @Test fun constraintDefinitionRejectsUnknownReferencedKey() {
        val definition = constrainedDefinition(ConstraintRule.GreaterThan("missing", 0.0), parameterKeys = setOf("missing"))
        val result = ComponentValidator.validate(definition, instanceFor(definition, mapOf("a" to "1", "b" to "2", "kind" to "X")))
        assertTrue(result.errors.any { it.contains("references unknown parameter: missing") })
    }

    @Test fun duplicateParameterKeysAndConstraintIdsAreRejected() {
        val duplicateParameters = listOf(
            ParameterDefinition("a", "A1", ParameterValueType.NUMBER, defaultValue = "1"),
            ParameterDefinition("a", "A2", ParameterValueType.NUMBER, defaultValue = "2")
        )
        val duplicateConstraint = ComponentConstraint(id = "same", parameterKeys = setOf("a"), rule = ConstraintRule.GreaterThan("a", 0.0), message = "first")
        val definition = glassDefinition.copy(parameters = duplicateParameters, constraints = listOf(duplicateConstraint, duplicateConstraint))
        val result = ComponentValidator.validate(definition, instanceFor(definition, mapOf("a" to "1")))
        assertTrue(result.errors.any { it.contains("Duplicate parameter key") })
        assertTrue(result.errors.any { it.contains("Duplicate constraint ID") })
    }

    @Test fun moveRejectsNonFiniteCoordinates() {
        val original = glassInstance()
        listOf(Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY).forEach { bad ->
            assertThrows(IllegalArgumentException::class.java) { ComponentTransformOperations.move(original, bad, 0.0, 0.0) }
            assertThrows(IllegalArgumentException::class.java) { ComponentTransformOperations.move(original, 0.0, bad, 0.0) }
            assertThrows(IllegalArgumentException::class.java) { ComponentTransformOperations.move(original, 0.0, 0.0, bad) }
        }
        assertEquals(0L, original.revision)
    }

    @Test fun rotateRejectsNonFiniteAngles() {
        val original = glassInstance()
        listOf(Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY).forEach { bad ->
            assertThrows(IllegalArgumentException::class.java) { ComponentTransformOperations.rotate(original, bad, 0.0, 0.0) }
            assertThrows(IllegalArgumentException::class.java) { ComponentTransformOperations.rotate(original, 0.0, bad, 0.0) }
            assertThrows(IllegalArgumentException::class.java) { ComponentTransformOperations.rotate(original, 0.0, 0.0, bad) }
        }
        assertEquals(0L, original.revision)
    }

}
