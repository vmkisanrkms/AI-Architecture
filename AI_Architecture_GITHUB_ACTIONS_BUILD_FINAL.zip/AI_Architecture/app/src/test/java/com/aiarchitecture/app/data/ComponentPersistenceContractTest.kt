package com.aiarchitecture.app.data

import com.aiarchitecture.app.core.components.*
import com.aiarchitecture.app.data.repository.ComponentInstanceSnapshotCodec
import org.junit.Assert.*
import org.junit.Test

class ComponentPersistenceContractTest {
    @Test fun builtInCatalogueHasStableUniqueIdsAndKeys() {
        val items = BuiltInComponentDefinitions.all
        assertTrue(items.isNotEmpty())
        assertEquals(items.size, items.map { it.id }.toSet().size)
        assertEquals(items.size, items.map { it.key }.toSet().size)
    }
    @Test fun allBuiltInParameterKeysAreUniqueWithinDefinition() {
        BuiltInComponentDefinitions.all.forEach { definition ->
            assertEquals(definition.key, definition.key)
            assertEquals(definition.parameters.size, definition.parameters.map { it.key }.toSet().size)
        }
    }
    @Test fun profileValidationRejectsDegenerateCoordinates() {
        val profile = CustomProfile(name="Bad",kind=ProfileKind.POLYLINE,points=listOf(ProfilePoint(0.0,0.0),ProfilePoint(0.0,0.0)),closed=false)
        assertTrue(profile.validate().any { it.contains("zero-length") })
    }
    @Test fun materialValidationRejectsOutOfRangePbrValues() {
        val material = MaterialDescriptor(name="Bad",category=MaterialCategory.STEEL,red=2f,green=0f,blue=0f)
        assertFalse(material.validate().isEmpty())
    }

    @Test fun componentInstanceSnapshotRoundTripsAllPersistedFields() {
        val original = ComponentInstance(
            id="instance-1", projectId="project-1", floorId="floor-1",
            definitionId=BuiltInComponentDefinitions.all.first().id, name="Railing A",
            dimensions=DimensionsMm(1200.0,1050.0,80.0,12.0),
            transform=Transform3D(10.0,20.0,30.0,0.0,0.0,15.0,1.2,1.0,1.0),
            parameterValues=mapOf("panelThicknessMm" to ParameterValue("panelThicknessMm","12")),
            revision=7, visible=false, locked=true
        )
        val decoded = ComponentInstanceSnapshotCodec.decode(ComponentInstanceSnapshotCodec.encode(listOf(original))).single()
        assertEquals(original, decoded)
    }

    @Test fun physicalDimensionsAndVisualScaleRemainIndependent() {
        val instance = ComponentInstance(projectId="p",floorId="f",definitionId="d",name="test",dimensions=DimensionsMm(100.0,100.0,50.0,5.0))
        val scaled = ComponentTransformOperations.setVisualScale(instance,2.0,1.0,1.0)
        assertEquals(100.0,scaled.dimensions.length,0.0)
        assertEquals(2.0,scaled.transform.scaleX,0.0)
    }
}
