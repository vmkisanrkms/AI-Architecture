# AI Architecture — GitHub Actions Android Debug Build

## Repository preparation

1. Create/open the GitHub repository that will contain the Android project.
2. Extract `AI_Architecture_PHASE1_COMPONENT_PERSISTENCE_V8_1.zip` locally.
3. Open the extracted `AI_Architecture` directory. Copy **its contents**, including the hidden `.github` directory, into the repository root. The repository root must directly contain `settings.gradle.kts`, `build.gradle.kts`, `app/`, `scripts/`, and `.github/workflows/android-ci.yml`.
4. Commit and push to `main` (or `master`). The workflow also supports **Actions → AI Architecture Android Build and Debug APK → Run workflow**.
5. Do not upload only the ZIP as a repository file: GitHub only discovers workflows stored under the repository-root `.github/workflows/` path.

## Pinned build environment

The workflow uses `ubuntu-latest`, Temurin JDK 17, Gradle 8.11.1 via `gradle/actions/setup-gradle@v4`, Android API 36, Build Tools 36.0.0, Platform Tools, and an API 36 `google_apis` x86_64 emulator. It installs Kotlin/JVM compiler 1.9.0 separately because the PSI DAO guard compiles and runs against the Kotlin compiler PSI classes.

The V8.1 source ZIP does not contain `gradlew`, `gradlew.bat`, or `gradle/wrapper/gradle-wrapper.jar`. The workflow confirms this and intentionally uses the pinned `gradle` executable installed by the Gradle setup action. It does not generate or modify a wrapper.

## Workflow execution order

1. Checkout and locate the Gradle project root.
2. Install JDK 17, Gradle 8.11.1, Android SDK API 36 / Build Tools 36.0.0 / Platform Tools, and Kotlin compiler 1.9.0.
3. Verify the environment and resolve Gradle dependencies.
4. Run the six existing static/fixture verifiers, including actual Kotlin PSI and Tokenizer fixtures.
5. Run Room KAPT schema generation and Kotlin compilation.
6. Run JVM unit tests and Android Lint.
7. Boot the API 36 emulator and run `:app:connectedDebugAndroidTest`; the existing `ComponentDatabaseMigrationTest` is included in this instrumentation suite and its report is explicitly checked.
8. Assemble `:app:assembleDebug`, verify package ID `com.aiarchitecture.app`, ZIP alignment, APK signature integrity and SHA-256.
9. Upload the Debug APK and build/test/lint/Room schema logs even when an earlier step fails.

## Artifacts

A successful or failed workflow run uploads:

- `AI_Architecture_DEBUG_APK`
- `AI_Architecture_BUILD_LOGS_AND_REPORTS` (environment, static verifier, Gradle, unit-test, lint, emulator/instrumentation, APK verification logs; Gradle reports and Room schemas)

The workflow final summary is `FINAL_RESULT=PASS` only if every required build/test/instrumentation/APK step succeeds. A missing emulator, test report, APK, schema, or failed task is not silently converted to a pass.

## Scope and preservation

This workflow changes no app feature, UI, database schema, DAO, repository, migration, manifest permission, measurement unit, or domain implementation. It does not add INTERNET permission, Release signing, GitHub CI deployment, Component Properties Inspector, or Editing Commands. Debug APK only.
