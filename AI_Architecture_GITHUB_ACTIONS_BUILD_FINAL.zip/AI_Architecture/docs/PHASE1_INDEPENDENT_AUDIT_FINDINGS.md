# AI Architecture Phase 1 — Independent Source Audit
Date: 2026-11-07
Artifact audited: AI_Architecture_PHASE1_COMPONENT_PERSISTENCE_V1.zip

## Verdict
**NOT PASS / NOT COMPLETE.** The archive contains real Room entities, DAOs, a v1→v2 migration, BuildingModel integration and a component snapshot codec. However, important referential-integrity and round-trip test gaps remain. No Android build or test execution was performed.

## Artifact integrity and lineage
- ZIP integrity: valid (`ZipFile.testzip()` returned no bad entry); 179 entries.
- Embedded V7 archive SHA-256: `53d5727b2cb1fa2f63c5cf15d442554badc368f1e52810658e6e6c91335a7443`.
- V3 `ParametricComponent.kt` and `ParametricComponentTest.kt` match the V3 Bootstrap overlay byte-for-byte.
- V7 and V3 preservation verified within this package; this does not certify all application features.

## Findings by requested check
1. **Four Room Entities and DAOs — PRESENT.** `ComponentDefinitionEntity` / `ComponentDefinitionDao`, `ComponentInstanceEntity` / `ComponentInstanceDao`, `ComponentProfileEntity` / `ComponentProfileDao`, `ComponentMaterialEntity` / `ComponentMaterialDao` exist. Primary keys are present. Definition `key` has a unique index.
2. **Migration 1→2 — PRESENT.** `AppDatabase.MIGRATION_1_2` creates four tables and indexes. SQLite execution of the 13 SQL statements succeeded against a reconstructed v1 fixture.
3. **Legacy records — PARTIALLY VERIFIED.** SQL simulation preserved one row in each legacy table (`projects`, `floors`, `building_elements`, `edit_history`). The included instrumentation test asserts only project and floor preservation, not element/history rows. No Room runtime execution occurred.
4. **BuildingModel save/load — SOURCE PATH PRESENT.** `BuildingModelStore.save()` writes component instances in the same transaction; `load()` reads them. No end-to-end Room repository test verifies this round-trip.
5. **Edit history — SOURCE PATH PRESENT.** `ModelJson.encode()` includes `componentInstances`; `decode()` uses nullable `optJSONArray`, allowing missing componentInstances to decode as empty. No explicit old snapshot fixture test or history DAO read/decode round-trip test was found.
6. **Custom Profile Points — SERIALIZATION PRESENT, ROUND-TRIP TEST MISSING.** Points are stored in `pointsJson` and reconstructed. No test persists a profile through Room and compares all points/metadata.
7. **Materials and Definitions — SERIALIZATION PRESENT, ROUND-TRIP TEST MISSING.** JSON conversion exists for definitions/materials. No database-backed round-trip tests were found for all fields.
8. **Backward compatibility — PARTIAL.** `BuildingModel.componentInstances` defaults to empty; snapshot decode tolerates absent `componentInstances`. The old snapshot compatibility test is missing. `ModelJson.decode()` still requires existing `floors`, each floor's `elements`, and each element's `openings`; compatibility depends on legacy snapshots containing those fields.
9. **Duplicate IDs / invalid references — INCOMPLETE.** Primary keys reject duplicate IDs at raw INSERT level, but DAOs use `OnConflictStrategy.REPLACE`, silently replacing existing rows. `replaceProjectInstances()` does not reject duplicate instance IDs in the input list. There are no SQL foreign keys. `saveInstance()` validates floor/definition/profile/material references, but `replaceProjectInstances()` validates floor/project/definition and does not validate `profileId` or `materialId`. Direct DAO writes can create dangling references. Unique definition key plus REPLACE can replace a different definition row sharing the key.
10. **Tests — SOURCE EXISTS, EXECUTION NOT PERFORMED.** Component-specific tests include snapshot codec round-trip, basic profile/material validation and a migration instrumentation test. Missing database-backed tests include profile/material/definition round-trip, BuildingModel save/load, history round-trip, old snapshot compatibility, duplicate IDs and invalid references.

## Test inventory (source annotations only)
- JVM: 19 Kotlin files, 62 `@Test` annotations.
- Instrumentation: 10 Kotlin files, 20 `@Test` annotations.
- These are source inventory counts, **not executed test results**.
- Android/JUnit execution: NOT RUN.

## SQLite simulation (not Room runtime)
- 13 migration SQL statements executed successfully using Python sqlite3.
- All 4 new tables and 9 component indexes created.
- One pre-existing row each in projects, floors, building_elements and edit_history remained after migration.
- This does not validate Room-generated schema identity, KAPT output, Android SQLite behavior or instrumentation test execution.

## Required fixes before Phase 1 acceptance
1. Add database-backed round-trip tests for definitions, instances, profiles (including ordered points), and materials.
2. Add BuildingModelStore save/load and EditHistory snapshot encode/decode tests, including a pre-component legacy snapshot fixture.
3. Add duplicate-ID and dangling-reference tests. Reject duplicate instance IDs before delete/insert.
4. Enforce referential integrity consistently in `replaceProjectInstances()` and at the persistence boundary; decide explicit delete policies for referenced profiles/materials/definitions.
5. Prefer Room foreign keys where compatible with existing project/floor schema, or implement transactional reference validation and document it.
6. Change destructive REPLACE semantics where overwriting a referenced definition by unique key could orphan component instances.
7. Extend migration instrumentation assertions to include building_elements and edit_history and verify all four new tables/indexes.
8. Run JVM and Android instrumentation tests later when the deferred Android environment is restored.

## Status
Phase 1 remains **PENDING**. Do not start Component Properties Inspector or Editing Commands until these audit findings are addressed and reviewed. Android build is intentionally out of scope per current project direction.
