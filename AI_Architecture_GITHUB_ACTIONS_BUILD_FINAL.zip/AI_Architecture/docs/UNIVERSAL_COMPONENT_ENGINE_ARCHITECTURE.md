# AI Architecture — Universal Parametric Component Engine

**Revision:** 2026-11-07  
**Decision:** Option C — Universal Architectural Component Builder  
**Status:** Architecture baseline approved for Phase 2 implementation. This document is a design contract, not a claim that the complete engine or Android build is finished.

## 1. Architectural decisions

1. Preserve the existing Kotlin/Compose application, Room project database, BuildingModel, unit conversion, history, 2D editor, OpenGL ES renderer, PDF and offline features. Extend rather than replace them.
2. Use one canonical building model and stable IDs. The canonical coordinate system is right-handed, in millimetres: X = plan length, Y = vertical, Z = plan depth. Display units never change stored values.
3. Use one universal parametric component definition + instance model. Built-in and user-created components use the same parameter, constraint, profile, material and geometry-recipe contracts.
4. Keep geometry generation deterministic and independent from Android UI. UI edits update domain state; validated model revisions trigger mesh regeneration and 2D annotation refresh.
5. Persist all project data locally in Room/SQLite. No cloud dependency is required for editing, geometry, rendering, backup or restore.
6. Treat geometry as derived/cacheable data. The parametric definition and instance parameters are authoritative; generated meshes can be rebuilt after restore or cache invalidation.
7. Use explicit provenance: USER_ENTERED, DERIVED, ESTIMATED. Never silently replace user-entered dimensions with inferred values.
8. Do not introduce a heavyweight renderer migration in Phase 2. First make the model/geometry contracts renderer-agnostic; evaluate Filament/SceneView only after feature and device benchmarks.

## 2. Layered architecture

- **Presentation:** Compose screens, property inspector, component library, 2D canvas and 3D viewport.
- **Application/use cases:** create component, place, transform, edit parameter, duplicate, delete, validate, undo/redo, regenerate and export.
- **Domain:** canonical dimensions, stable IDs, component definitions/instances, custom profiles, materials, constraints, geometry recipes and model transactions.
- **Geometry:** profile extrusion, sweep, lathe/revolve, box/plate/beam primitives, arch generation, stair generation, openings and mesh validation.
- **Synchronization:** one model revision feeds plan symbols, dimension annotations and 3D meshes. Edits are committed as atomic transactions.
- **Persistence:** Room entities/DAOs and explicit schema migrations. Keep existing project/floor/element/history data readable; migrate legacy elements into component instances incrementally, not destructively.
- **Export/backup:** versioned JSON package; scaled dimensioned PDF and live 3D view capture.

## 3. Canonical data model

### Project and building

`Project(id, name, units/displayPrecision, createdAt, updatedAt, schemaVersion)`  
`Floor(id, projectId, name, elevationMm, floorToFloorHeightMm, visibility, locked)`  
`BuildingElement(id, projectId, floorId, type, transform, dimensions, revision, provenance)`

### Component definition (reusable template)

`ComponentDefinition(id, key, name, category, schemaVersion, isBuiltIn, geometryRecipe, parameterSchema, defaultMaterialId, defaultProfileId, thumbnailRef, createdAt, updatedAt)`

A definition describes how an instance is generated. It is not a placed object. Built-in definitions are seeded and versioned; custom definitions are user-owned and exportable.

### Component instance (placed object)

`ComponentInstance(id, projectId, floorId, definitionId, name, transform, dimensions, profileId, materialId, parameterValues, constraints, revision, source/provenance, visible, locked)`

Transform stores position (x/y/z mm), rotation (Euler degrees initially; quaternion-capable representation reserved), and scale. Physical dimensions are separate from transform scale: resizing a gate changes its actual dimensions, not merely a visual scale factor. This avoids distorted thicknesses and incorrect measurements.

### Parameters and constraints

`ParameterDefinition(key, label, valueType, unit, defaultValue, min, max, step, required, affectsGeometry, affectsPlan, dependencyExpression)`  
`ParameterValue(instanceId, key, typedValue, provenance)`  
`Constraint(id, parameterKeys, ruleType, expression/typedRule, severity, message)`

Expressions must be parsed from a restricted, deterministic expression grammar; do not execute arbitrary Kotlin/JavaScript. Example constraints: panel thickness > 0; post spacing <= 1200 mm; railing height within configured limits; opening must fit host wall.

### Profiles and materials

`CustomProfile(id, projectId?, name, profileType, points2D, closed, thicknessMm, revision)`; points are stored in millimetres in the profile's local plane. Support polyline, closed polygon, arc segments and parametric primitives. Validate self-intersection, zero-length edges and closure before use.

`Material(id, projectId?, name, category, colorRGBA, roughness, metallic, opacity, textureRef?, physicalPropertiesJson)`; renderer-facing properties remain separate from optional construction/quantity properties.

### Geometry cache

`GeneratedGeometry(instanceId, sourceRevision, vertices, indices, normals, uv, materialSlots, bounds, generatorVersion)` is disposable. Cache is invalid whenever instance revision, definition schema, profile revision or geometry generator version changes.

### Edit history

Store reversible model commands or versioned snapshots. An edit transaction updates canonical data, increments revisions, validates constraints, appends history and emits a model-changed event. Undo/redo must restore parameters, transform, geometry revision and 2D annotations together.

## 4. Geometry recipe catalogue

- `BOX / PLATE / BEAM`: pillars, posts, clamps, brackets, slabs and basic frames.
- `PROFILE_EXTRUSION`: custom closed profile extruded along a path.
- `SWEEP`: rails, handrails, pipes and mouldings along straight/curved paths.
- `PANEL_WITH_OPENINGS`: glass panels, doors, windows and gate leaves.
- `ARCH`: semicircular, segmental, pointed and user-defined curve arch.
- `STAIR`: tread/riser/landing generator with configurable direction and count.
- `ASSEMBLY`: compound component composed of child instances with parent-child transforms.

A recipe must return validated mesh parts with stable sub-part IDs and material slots. Component selection can target the assembly or an editable child such as post, clamp, glass panel or top rail.

## 5. Initial component families

- Railings: glass, steel, balcony; posts, top/bottom rails, glass panels, clamps, brackets and handrails.
- Openings: hinged/sliding/folding gates, doors, windows, frames and glazing.
- Structural: pillars, columns, beams, slabs, boundary walls.
- Architectural: round/half/segmental/custom arches, decorative panels, ceiling parts.
- Circulation: straight/L/U/spiral staircases, landings and stair railings.
- Custom: user-defined profile, extrusion/sweep and assemblies.

Each family uses common parameters: length, height, width/depth, thickness, profile, material, position, rotation and family-specific values. Not every parameter is geometrically meaningful for every component; the schema declares applicable parameters rather than showing fake editable fields.

## 6. 2D/3D synchronization contract

- Stable element/instance IDs link plan symbols, dimensions, property inspector and 3D scene nodes.
- The canonical model is the sole source of truth. The 2D plan and 3D scene are projections of it.
- A committed 2D edit changes canonical endpoints/dimensions and triggers mesh regeneration.
- A committed 3D property/transform edit updates canonical parameters and plan annotations.
- Camera orbit/pan/zoom never changes geometry or dimensions.
- Regeneration is deterministic for the same definition version, parameters, profile, material slots and generator version.
- Use model revision tokens to discard stale asynchronous mesh results; only the latest valid revision is published.
- All units remain mm internally; GLES conversion to metres occurs only at the renderer boundary.

## 7. Interaction contract

Component workflow: choose definition → preview → place on plane/host → snap/align → select → move/rotate/resize → edit properties → validate → commit → save. Support duplicate, delete, lock, hide, group/ungroup and parent-child assemblies. Selection uses ray picking in 3D and geometric hit-testing in 2D. Transform handles must have numeric entry alternatives for precision.

## 8. Room persistence and migration plan

Keep existing `projects`, `floors`, `building_elements` and `edit_history` tables. Add normalized tables for component definitions, component instances, custom profiles, materials and parameter values, with foreign-key/index coverage. Use explicit Room migrations; never use destructive migration. First migration copies legacy compatible elements into the new instance representation while preserving the old rows as a recovery/compatibility source. Verify migration by row counts, dimensions, IDs and opening payload equivalence. Add schema export to version control.

## 9. Offline and backup contract

Built-in definitions and standard materials ship with the app. User profiles, definitions, instances, thumbnails and textures are stored in app-private local storage with database references. Versioned JSON backup includes all non-cache model data, definition/profile/material dependencies and media manifests. Restore validates file size, schema version, IDs, references and geometry constraints before a transaction commits. No internet permission is required for local editing or export.

## 10. Phase 2 acceptance criteria

- Domain types represent definitions, instances, all-axis transforms, dimensions including thickness, custom profiles, materials and typed parameters.
- Parameter validation rejects non-finite, negative, out-of-range and incompatible values.
- Built-in family catalogue covers glass/steel railing, bracket, clamp, post, gate, pillar, arch, staircase, door and window.
- Transform operations and physical resize are distinct and tested.
- Stable IDs and revisions are preserved through edits and serialization design.
- Unit tests cover validation, transforms, profile closure, parameter dependencies and revision changes.
- Existing source and data remain compatible; any Room schema change has a tested migration.
- Actual Android build, JVM tests, lint and emulator/device tests are separate release gates. Static scripts alone are never called a successful build or APK.

## 11. Current implementation boundary

Phase 2 begins with domain contracts and tests. Room migration, UI property inspector, selection/picking, geometry recipes and complete rendering are subsequent implementation increments. Gradle Wrapper is a release/build blocker: the repository must contain `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar` and `gradle-wrapper.properties` generated by a real Gradle wrapper task. Do not fabricate the wrapper JAR. This execution environment currently has no Gradle installation, Android SDK or network DNS access, so wrapper generation and Android build cannot honestly be marked complete here.
