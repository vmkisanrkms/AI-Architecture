#!/usr/bin/env python3
"""Token-based, conservative Kotlin source guard for Component DAO access.

This is deliberately not a Kotlin compiler/PSI plugin. It tokenizes Kotlin code,
ignores comments and literal text, resolves accessor import aliases, and flags
calls/references to the four RoomDatabase DAO accessors. Bare calls are also
flagged, which covers implicit receivers in with/run/apply and nested lambdas.
"""
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
import os
import shutil
import subprocess
import tempfile

DAO_ACCESSORS = {
    "componentDefinitions", "componentInstances",
    "componentProfiles", "componentMaterials",
}
REFLECTION_LOOKUP_CALLS = {"getMethod", "getDeclaredMethod", "getMethods", "getDeclaredMethods"}

@dataclass(frozen=True)
class Token:
    kind: str
    value: str
    line: int
    column: int


def tokenize_kotlin(source: str) -> list[Token]:
    """Lex identifiers (including backticks), punctuation and newlines.

    Comments, character literals, escaped strings and raw triple-quoted strings
    are skipped as literal text. Kotlin string-template expressions are lexed
    separately so executable `${ ... }` code is not a blind spot.
    """
    tokens: list[Token] = []
    n = len(source)

    def emit(kind: str, value: str, start: int, line: int, col: int):
        tokens.append(Token(kind, value, line, col))

    def scan_code(i: int, stop_at_brace: bool = False) -> int:
        line = source.count("\n", 0, i) + 1
        last_nl = source.rfind("\n", 0, i)
        col = i - last_nl
        brace_depth = 0
        while i < n:
            ch = source[i]
            if ch in " \t\r":
                i += 1; col += 1; continue
            if ch == "\n":
                emit("NL", "\n", i, line, col)
                i += 1; line += 1; col = 1; continue
            if source.startswith("//", i):
                end = source.find("\n", i + 2)
                if end < 0: return n
                col += end - i; i = end; continue
            if source.startswith("/*", i):
                start = i; start_line, start_col = line, col
                i += 2; col += 2; depth = 1
                while i < n and depth:
                    if source.startswith("/*", i): depth += 1; i += 2; col += 2
                    elif source.startswith("*/", i): depth -= 1; i += 2; col += 2
                    elif source[i] == "\n": i += 1; line += 1; col = 1
                    else: i += 1; col += 1
                continue
            if stop_at_brace and ch == "}" and brace_depth == 0:
                return i + 1
            if source.startswith('"""', i):
                # Raw string: scan template expressions only; literal text ignored.
                start = i; i += 3; col += 3
                while i < n and not source.startswith('"""', i):
                    if source.startswith("${", i):
                        expr_start = i + 2
                        expr_end = _find_template_end(source, expr_start)
                        if expr_end < 0: # malformed source; conservatively stop
                            i = n; break
                        scan_template_expr(expr_start, expr_end, line, col + 2)
                        consumed = source[i:expr_end + 1]
                        nl_count = consumed.count("\n")
                        if nl_count:
                            line += nl_count; col = len(consumed.rsplit("\n", 1)[-1]) + 1
                        else: col += len(consumed)
                        i = expr_end + 1
                    elif source[i] == "\\" and i + 1 < n:
                        i += 2; col += 2
                    else:
                        if source[i] == "\n": line += 1; col = 1
                        else: col += 1
                        i += 1
                if i < n: i += 3; col += 3
                continue
            if ch == '"':
                i += 1; col += 1
                while i < n and source[i] != '"':
                    if source.startswith("${", i):
                        expr_start = i + 2
                        expr_end = _find_template_end(source, expr_start)
                        if expr_end < 0: i = n; break
                        scan_template_expr(expr_start, expr_end, line, col + 2)
                        consumed = source[i:expr_end + 1]
                        nl_count = consumed.count("\n")
                        if nl_count: line += nl_count; col = len(consumed.rsplit("\n",1)[-1]) + 1
                        else: col += len(consumed)
                        i = expr_end + 1
                    elif source[i] == "\\" and i + 1 < n:
                        i += 2; col += 2
                    else:
                        if source[i] == "\n": line += 1; col = 1
                        else: col += 1
                        i += 1
                if i < n: i += 1; col += 1
                continue
            if ch == "'":
                i += 1; col += 1
                while i < n and source[i] != "'":
                    if source[i] == "\\" and i + 1 < n: i += 2; col += 2
                    else:
                        if source[i] == "\n": line += 1; col = 1
                        else: col += 1
                        i += 1
                if i < n: i += 1; col += 1
                continue
            if ch == '`':
                end = source.find('`', i + 1)
                if end < 0: end = n - 1
                value = source[i + 1:end]
                emit("ID", value, i, line, col)
                col += end + 1 - i; i = end + 1
                continue
            if ch == "_" or ch.isalpha():
                j = i + 1
                while j < n and (source[j] == "_" or source[j].isalnum()): j += 1
                emit("ID", source[i:j], i, line, col)
                col += j - i; i = j; continue
            if source.startswith("::", i):
                emit("SYM", "::", i, line, col); i += 2; col += 2; continue
            if ch == "{": brace_depth += 1
            elif ch == "}" and brace_depth > 0: brace_depth -= 1
            emit("SYM", ch, i, line, col)
            i += 1; col += 1
        return i

    def scan_template_expr(start: int, end: int, base_line: int, base_col: int):
        # A bounded expression is tokenized by the same scanner using a slice.
        # Token line/column are approximate for diagnostics; matching is exact.
        sub = source[start:end]
        nested = tokenize_kotlin(sub)
        tokens.extend(Token(t.kind, t.value, base_line + t.line - 1,
                            (base_col + t.column - 1) if t.line == 1 else t.column)
                      for t in nested)

    scan_code(0)
    return tokens


def _find_template_end(source: str, start: int) -> int:
    depth = 1; i = start; n = len(source)
    quote = None
    while i < n:
        if quote == '"""':
            if source.startswith('"""', i): quote = None; i += 3; continue
        elif quote == '"':
            if source[i] == "\\": i += 2; continue
            if source[i] == '"': quote = None
        elif quote == "'":
            if source[i] == "\\": i += 2; continue
            if source[i] == "'": quote = None
        else:
            if source.startswith('"""', i): quote = '"""'; i += 3; continue
            if source[i] == '"': quote = '"'
            elif source[i] == "'": quote = "'"
            elif source.startswith("//", i):
                e = source.find("\n", i + 2); i = n if e < 0 else e; continue
            elif source.startswith("/*", i):
                e = source.find("*/", i + 2); i = n if e < 0 else e + 2; continue
            elif source[i] == "{": depth += 1
            elif source[i] == "}":
                depth -= 1
                if depth == 0: return i
        i += 1
    return -1


def _significant(tokens: list[Token]) -> list[Token]:
    return [t for t in tokens if t.kind != "NL"]


def _reflection_aliases(tokens: list[Token]) -> set[str]:
    """Resolve aliases of java.lang.Class reflection lookup members."""
    aliases = set()
    i = 0
    while i < len(tokens):
        if tokens[i].kind == "ID" and tokens[i].value == "import":
            j = i + 1
            parts = []
            while j < len(tokens) and tokens[j].line == tokens[i].line and not (
                tokens[j].kind == "SYM" and tokens[j].value == ";"
            ):
                parts.append(tokens[j]); j += 1
            ids = [t.value for t in parts if t.kind == "ID"]
            if any(x in REFLECTION_LOOKUP_CALLS for x in ids) and "as" in ids:
                k = ids.index("as")
                if k + 1 < len(ids):
                    aliases.add(ids[k + 1])
            i = j
        else:
            i += 1
    return aliases


def _class_type_aliases(tokens: list[Token]) -> set[str]:
    """Collect aliases imported from java.lang.Class."""
    aliases = set()
    for i, token in enumerate(tokens):
        if token.kind == "ID" and token.value == "import":
            j = i + 1
            parts = []
            while j < len(tokens) and tokens[j].line == token.line and not (
                tokens[j].kind == "SYM" and tokens[j].value == ";"
            ):
                parts.append(tokens[j]); j += 1
            ids = [x.value for x in parts if x.kind == "ID"]
            if ids[:3] == ["java", "lang", "Class"] and "as" in ids:
                k = ids.index("as")
                if k + 1 < len(ids): aliases.add(ids[k+1])
    return aliases


def _class_typed_variables(tokens: list[Token], class_aliases: set[str]) -> set[str]:
    """Collect names explicitly typed as java.lang.Class / imported Class aliases."""
    result = set()
    for i, t in enumerate(tokens):
        if t.kind != "ID" or t.value in {"Class", "java", "lang"}:
            continue
        # variable/parameter : Class [<...>] ; allow qualified java.lang.Class
        if i + 2 < len(tokens) and tokens[i + 1].value == ":":
            j = i + 2
            if tokens[j].value == "java" and j + 4 < len(tokens) and tokens[j+1].value == "." and tokens[j+2].value == "lang" and tokens[j+3].value == "." and tokens[j+4].value == "Class":
                result.add(t.value)
            elif tokens[j].value == "Class" or tokens[j].value in class_aliases:
                result.add(t.value)
    return result


def _receiver_is_class_reflection(tokens: list[Token], separator_index: int,
                                  class_vars: set[str], class_aliases: set[str]) -> bool:
    """Determine whether tokens before :: denote java.lang.Class."""
    left = tokens[:separator_index]
    if not left:
        return False
    last = left[-1]
    if last.kind == "ID" and last.value == "javaClass":
        return True
    if last.kind == "ID" and (last.value == "Class" or last.value in class_vars or last.value in class_aliases):
        return True
    # Class<*>::method reference
    if last.value == ">" and len(left) >= 4:
        return left[-4].kind == "ID" and (left[-4].value == "Class" or left[-4].value in class_aliases)
    # Fully qualified java.lang.Class::method
    if len(left) >= 5 and [x.value for x in left[-5:]] == ["java", ".", "lang", ".", "Class"]:
        return True
    # Parenthesized receiver, e.g. (db.javaClass)::getMethod
    if last.value == ")" and len(left) >= 2:
        inner = left[:-1]
        depth = 0
        for k in range(len(inner)-1, -1, -1):
            if inner[k].value == ")": depth += 1
            elif inner[k].value == "(":
                depth -= 1
                if depth == 0:
                    return _receiver_is_class_reflection(inner[k+1:], len(inner[k+1:]), class_vars, class_aliases)
    return False


def forbidden_dao_access(source: str) -> list[str]:
    """Find forbidden DAO access and Class reflection callable references.

    The reflection rule is receiver-aware: it flags callable references only
    when the receiver is java.lang.Class (javaClass, Class, or a variable
    explicitly typed as Class). This catches references stored, passed, or
    nested in lambdas because the reference expression itself is forbidden.
    """
    ts = _significant(tokenize_kotlin(source))
    aliases: set[str] = set()
    direct_imports: set[str] = set()
    reflection_aliases = _reflection_aliases(ts)
    class_aliases = _class_type_aliases(ts)
    class_vars = _class_typed_variables(ts, class_aliases)
    i = 0
    while i < len(ts):
        if ts[i].kind == "ID" and ts[i].value == "import":
            j = i + 1; parts = []
            while j < len(ts) and not (ts[j].kind == "ID" and ts[j].value in {"import", "package"}):
                if ts[j].kind == "SYM" and ts[j].value == ";": break
                parts.append(ts[j]); j += 1
                if j < len(ts) and ts[j].line > ts[j-1].line: break
            ids = [x.value for x in parts if x.kind == "ID"]
            if ids:
                accessor = next((x for x in ids if x in DAO_ACCESSORS), None)
                if accessor:
                    direct_imports.add(accessor)
                    if "as" in ids:
                        k = ids.index("as")
                        if k + 1 < len(ids): aliases.add(ids[k+1])
            i = j
        else: i += 1
    names = DAO_ACCESSORS | aliases
    findings = []
    for idx, token in enumerate(ts):
        if token.kind != "ID":
            continue
        prev = ts[idx-1] if idx else None
        nxt = ts[idx+1] if idx+1 < len(ts) else None

        # Reflection callable references: db.javaClass::getMethod,
        # Class<*>::getDeclaredMethod, Class::getMethod, and typed Class vars.
        if token.value in REFLECTION_LOOKUP_CALLS | reflection_aliases and prev and prev.kind == "SYM" and prev.value == "::":
            if _receiver_is_class_reflection(ts, idx-1, class_vars, class_aliases):
                findings.append(f"Class reflection callable reference {token.value} at {token.line}:{token.column}")
                continue

        # Receiver-aware direct calls: do not ban an unrelated local function
        # merely because it happens to be named getMethod.
        if token.value in (REFLECTION_LOOKUP_CALLS | reflection_aliases) and nxt and nxt.kind == "SYM" and nxt.value == "(":
            if prev and prev.kind == "SYM" and prev.value == ".":
                receiver = ts[idx-2] if idx >= 2 else None
                if receiver and (receiver.value == "javaClass" or receiver.value == "Class" or receiver.value in class_vars):
                    findings.append(f"Class reflection lookup API {token.value} at {token.line}:{token.column}")
                    continue

        if token.value not in names:
            continue
        in_import = False
        k = idx - 1
        while k >= 0 and ts[k].line == token.line:
            if ts[k].kind == "ID" and ts[k].value == "import":
                in_import = True; break
            k -= 1
        if token.value in direct_imports and in_import:
            findings.append(f"import of DAO accessor {token.value} at {token.line}:{token.column}")
            continue
        if (prev and prev.kind == "SYM" and prev.value in {".", "::"}) or (nxt and nxt.kind == "SYM" and nxt.value == "("):
            findings.append(f"DAO accessor reference/call {token.value} at {token.line}:{token.column}")
    return findings


_PSI_TEMP = None
_PSI_CLASSES = None
_PSI_KOTLIN_HOME = None
GUARD_ENGINE = "tokenizer-fallback"

def _prepare_psi_guard():
    """Build the bundled Kotlin PSI scanner when a local Kotlin compiler exists."""
    global _PSI_TEMP, _PSI_CLASSES, _PSI_KOTLIN_HOME, GUARD_ENGINE
    if _PSI_CLASSES is not None:
        return _PSI_CLASSES, _PSI_KOTLIN_HOME
    compiler = shutil.which("kotlinc")
    if not compiler:
        return None
    kotlin_home = Path(compiler).resolve().parent.parent
    compiler_jar = kotlin_home / "lib/kotlin-compiler.jar"
    helper = Path(__file__).with_name("dao_access_guard_psi.kt")
    if not compiler_jar.is_file() or not helper.is_file():
        return None
    _PSI_TEMP = tempfile.TemporaryDirectory(prefix="ai-architecture-psi-guard-")
    classes = Path(_PSI_TEMP.name) / "classes"
    classes.mkdir()
    build = subprocess.run(
        [compiler, str(helper), "-cp", str(compiler_jar), "-d", str(classes)],
        text=True, capture_output=True, timeout=90
    )
    if build.returncode != 0:
        _PSI_TEMP.cleanup(); _PSI_TEMP = None
        return None
    _PSI_CLASSES, _PSI_KOTLIN_HOME = classes, kotlin_home
    GUARD_ENGINE = "Kotlin PSI (compiler 1.9.0)"
    return _PSI_CLASSES, _PSI_KOTLIN_HOME

def _scan_with_psi(root: Path):
    prepared = _prepare_psi_guard()
    if prepared is None:
        return None
    classes, kotlin_home = prepared
    java = shutil.which("java")
    if not java:
        return None
    classpath = str(classes) + os.pathsep + str(kotlin_home / "lib/*")
    result = subprocess.run(
        [java, "-cp", classpath, "Dao_access_guard_psiKt", str(root)],
        text=True, capture_output=True, timeout=90
    )
    if result.returncode != 0:
        return None
    return [line.removeprefix("VIOLATION ") for line in result.stdout.splitlines() if line.startswith("VIOLATION ")]


def scan_production_sources(source_root: Path, use_psi: bool = True) -> list[str]:
    """Scan src/main/java Kotlin files; only exact DB and repository paths allowed."""
    root = Path(source_root)
    psi_result = _scan_with_psi(root) if use_psi else None
    if psi_result is not None:
        return psi_result
    app = root / "app"
    src = app / "src/main/java"
    violations = []
    if not src.exists(): return ["missing production Kotlin source root: app/src/main/java"]
    for path in sorted(src.rglob("*.kt")):
        rel = path.relative_to(src).as_posix()
        allowed = (rel == "com/aiarchitecture/app/data/local/AppDatabase.kt" or
                   rel.startswith("com/aiarchitecture/app/data/repository/"))
        if allowed: continue
        for reason in forbidden_dao_access(path.read_text(encoding="utf-8")):
            violations.append(f"{path.relative_to(root).as_posix()}: {reason}")
    return violations


def fixture_scan(source: str, relative_path: str = "com/aiarchitecture/app/feature/fixture/Bad.kt") -> list[str]:
    """Run guard on an actual temporary production-source file fixture."""
    import tempfile
    with tempfile.TemporaryDirectory(prefix="kotlin-dao-guard-") as td:
        root = Path(td); target = root / "app/src/main/java" / relative_path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(source, encoding="utf-8")
        return scan_production_sources(root)
