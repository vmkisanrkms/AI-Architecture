@file:Suppress("DEPRECATION")

import com.intellij.openapi.util.Disposer
import org.jetbrains.kotlin.cli.jvm.compiler.KotlinCoreEnvironment
import org.jetbrains.kotlin.cli.jvm.compiler.EnvironmentConfigFiles
import org.jetbrains.kotlin.config.CompilerConfiguration
import org.jetbrains.kotlin.config.CommonConfigurationKeys
import org.jetbrains.kotlin.psi.KtCallExpression
import org.jetbrains.kotlin.psi.KtCallableReferenceExpression
import org.jetbrains.kotlin.psi.KtDotQualifiedExpression
import org.jetbrains.kotlin.psi.KtNameReferenceExpression
import org.jetbrains.kotlin.psi.KtParameter
import org.jetbrains.kotlin.psi.KtProperty
import org.jetbrains.kotlin.psi.KtPsiFactory
import org.jetbrains.kotlin.psi.KtTreeVisitorVoid
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths

private val DAO_ACCESSORS = setOf(
    "componentDefinitions", "componentInstances", "componentProfiles", "componentMaterials"
)
private val REFLECTION_LOOKUP_CALLS = setOf("getMethod", "getDeclaredMethod", "getMethods", "getDeclaredMethods")

private fun normalizedIdentifier(text: String): String = text.removeSurrounding("`")

fun main(args: Array<String>) {
    require(args.size == 1) { "Usage: DaoAccessGuardPsiKt <project-root>" }
    val root = Paths.get(args[0]).toAbsolutePath().normalize()
    val sourceRoot = root.resolve("app/src/main/java")
    if (!Files.isDirectory(sourceRoot)) {
        System.err.println("MISSING_SOURCE_ROOT app/src/main/java")
        kotlin.system.exitProcess(2)
    }
    val disposable = Disposer.newDisposable("DAO guard PSI environment")
    try {
        val configuration = CompilerConfiguration().apply {
            put(CommonConfigurationKeys.MODULE_NAME, "ai_architecture_dao_guard")
        }
        val environment = KotlinCoreEnvironment.createForProduction(
            disposable, configuration, EnvironmentConfigFiles.JVM_CONFIG_FILES
        )
        val factory = KtPsiFactory(environment.project, false)
        Files.walk(sourceRoot).use { paths ->
            paths.filter { Files.isRegularFile(it) && it.fileName.toString().endsWith(".kt") }
                .sorted().forEach { path ->
                    val relative = sourceRoot.relativize(path).toString().replace('\\', '/')
                    val allowed = relative == "com/aiarchitecture/app/data/local/AppDatabase.kt" ||
                        relative.startsWith("com/aiarchitecture/app/data/repository/")
                    if (!allowed) {
                        val source = Files.readString(path)
                        val psiFile = factory.createFile(path.fileName.toString(), source)
                        val aliases = psiFile.importDirectives.mapNotNull { directive ->
                            val fq = directive.importedFqName?.shortName()?.asString()
                            val alias = directive.aliasName?.let(::normalizedIdentifier)
                            if (fq in DAO_ACCESSORS && alias != null) alias else null
                        }.toSet()
                        val reflectionAliases = psiFile.importDirectives.mapNotNull { directive ->
                            val fq = directive.importedFqName?.shortName()?.asString()
                            val alias = directive.aliasName?.let(::normalizedIdentifier)
                            if (fq in REFLECTION_LOOKUP_CALLS && alias != null) alias else null
                        }.toSet()
                        val classTypeAliases = psiFile.importDirectives.mapNotNull { directive ->
                            val fq = directive.importedFqName?.asString()
                            val alias = directive.aliasName?.let(::normalizedIdentifier)
                            if (fq == "java.lang.Class" && alias != null) alias else null
                        }.toSet()
                        val findings = mutableListOf<String>()
                        psiFile.importDirectives.forEach { directive ->
                            val imported = directive.importedFqName?.shortName()?.asString()
                            if (imported in DAO_ACCESSORS) {
                                findings += "import of DAO accessor $imported"
                            }
                        }
                        val forbiddenNames = DAO_ACCESSORS + aliases
                        val classTypedNames = mutableSetOf<String>()
                        psiFile.accept(object : KtTreeVisitorVoid() {
                            override fun visitParameter(parameter: KtParameter) {
                                val typeText = parameter.typeReference?.text.orEmpty()
                                if (typeText.contains("Class") || classTypeAliases.any { typeText.contains(it) }) parameter.name?.let(classTypedNames::add)
                                super.visitParameter(parameter)
                            }
                            override fun visitProperty(property: KtProperty) {
                                val typeText = property.typeReference?.text.orEmpty()
                                if (typeText.contains("Class") || classTypeAliases.any { typeText.contains(it) }) property.name?.let(classTypedNames::add)
                                super.visitProperty(property)
                            }
                        })
                        fun isClassReflectionReceiver(text: String?): Boolean {
                            val receiver = text?.replace("`", "")?.trim().orEmpty()
                            return receiver.endsWith("javaClass") ||
                                receiver == "Class" || receiver.startsWith("Class<") ||
                                receiver in classTypeAliases || classTypeAliases.any { receiver.startsWith("$it<") } ||
                                receiver in classTypedNames ||
                                receiver.endsWith(".Class") || receiver.startsWith("java.lang.Class")
                        }
                        psiFile.accept(object : KtTreeVisitorVoid() {
                            override fun visitCallExpression(expression: KtCallExpression) {
                                val callee = expression.calleeExpression
                                val name = callee?.let { normalizedIdentifier(it.text.substringAfterLast('.')) }
                                if (name in forbiddenNames) findings += "DAO call/reference $name"
                                if (name in REFLECTION_LOOKUP_CALLS || name in reflectionAliases) {
                                    val qualified = expression.parent as? KtDotQualifiedExpression
                                    val receiverText = qualified?.receiverExpression?.text
                                    if (isClassReflectionReceiver(receiverText)) {
                                        findings += "Class reflection lookup API $name"
                                    }
                                }
                                super.visitCallExpression(expression)
                            }

                            override fun visitCallableReferenceExpression(expression: KtCallableReferenceExpression) {
                                val name = normalizedIdentifier(expression.callableReference.text)
                                if (name in forbiddenNames) findings += "DAO callable reference $name"
                                if ((name in REFLECTION_LOOKUP_CALLS || name in reflectionAliases) &&
                                    isClassReflectionReceiver(expression.receiverExpression?.text)) {
                                    findings += "Class reflection callable reference $name"
                                }
                                super.visitCallableReferenceExpression(expression)
                            }

                            override fun visitDotQualifiedExpression(expression: KtDotQualifiedExpression) {
                                val selector = expression.selectorExpression
                                if (selector is KtNameReferenceExpression) {
                                    val name = normalizedIdentifier(selector.text)
                                    if (name in forbiddenNames) findings += "DAO member selector $name"
                                }
                                super.visitDotQualifiedExpression(expression)
                            }
                        })
                        findings.distinct().forEach { println("VIOLATION $relative: $it") }
                    }
                }
        }
    } finally {
        Disposer.dispose(disposable)
    }
}
