#!/usr/bin/env python3
"""Executable V7 DAO reflection guard fixtures; tests real .kt files through both engines."""
from pathlib import Path
import sys, tempfile, shutil, subprocess, re
import dao_access_guard as guard

NEGATIVE = {
    "db.javaClass getMethod reference": "fun bad(db: Any) { val ref = db.javaClass::getMethod }",
    "db.javaClass getDeclaredMethod reference": "fun bad(db: Any) { val ref = db.javaClass::getDeclaredMethod }",
    "Class star-projection getMethod reference": "val ref = Class<*>::getMethod",
    "Class star-projection getDeclaredMethod reference": "val ref = Class<*>::getDeclaredMethod",
    "imported reflection alias": "import java.lang.Class.getMethod as reflected\\nfun bad(clazz: Class<*>) { val ref = clazz::reflected }",
    "variable assignment": "fun bad(db: Any) { val lookup = db.javaClass::getMethod }",
    "function argument": "fun bad(db: Any) { consume(db.javaClass::getMethod) }",
    "lambda reference": "fun bad(db: Any) = { db.javaClass::getMethod }",
    "nested lambda reference": "fun bad(db: Any) = listOf(1).map { { db.javaClass::getDeclaredMethod } }",
    "literal DAO method lookup": 'fun bad(db: Any) { db.javaClass.getMethod("componentDefinitions") }',
    "computed DAO method lookup": 'fun bad(db: Any, methodName: String) { db.javaClass.getMethod(methodName) }',
    "backtick and formatting": "fun bad(db: Any) { db.javaClass /*gap*/ ::\\n `getDeclaredMethod` }",
    "Class::getMethod reference": "val ref = Class::getMethod",
    "Class::getDeclaredMethod reference": "val ref = Class::getDeclaredMethod",
    "typed Class variable reference": "fun bad(clazz: Class<*>) { val ref = clazz::getMethod }",
    "nested reflection callable references": "fun bad(clazz: Class<*>) { consume(listOf(clazz::getMethod).map { it }) }",
    "imported Class type alias": "import java.lang.Class as JavaClass\\nfun bad(clazz: JavaClass<*>) { val ref = clazz::getMethod }",
}
POSITIVE = {
    "ordinary Kotlin callable reference": "val ref = String::length",
    "ordinary function reference": "fun f() {}\\nval ref = ::f",
    "escaped string": 'val s = "db.javaClass::getMethod componentDefinitions"',
    "raw triple string": 'val s = """db.javaClass::getDeclaredMethod componentProfiles"""',
    "comments": "// db.javaClass::getMethod\\n/* Class<*>::getDeclaredMethod */ val x = 1",
    "character literal": "val c = ':'",
    "unrelated local getMethod": 'fun getMethod(x: String) = x.length\\nval x = getMethod("safe")',
    "unrelated object member getMethod": 'class NotJavaClass { fun getMethod(x: String) = x }\\nval x = NotJavaClass().getMethod("safe")',
    "ordinary method reference on unrelated receiver": "val ref = String::getBytes",
}

def main():
    failures = []
    with tempfile.TemporaryDirectory(prefix="v7-dao-reflection-") as td:
        root = Path(td)
        src = root / "app/src/main/java/com/aiarchitecture/app/feature/guardfixtures"
        src.mkdir(parents=True)
        for i, (name, code) in enumerate(NEGATIVE.items()):
            # Strings use escaped newlines in the fixture table for readability.
            code = code.replace("\\n", "\n")
            f = src / f"negative_{i:02d}.kt"; f.write_text(code)
            findings = guard.forbidden_dao_access(code)
            if not findings:
                failures.append(f"tokenizer negative failed: {name}")
        for i, (name, code) in enumerate(POSITIVE.items()):
            code = code.replace("\\n", "\n")
            f = src / f"positive_{i:02d}.kt"; f.write_text(code)
            findings = guard.forbidden_dao_access(code)
            if findings:
                failures.append(f"tokenizer positive false-positive: {name}: {findings}")
        # Run the exact production-source guard against the fixture tree.
        violations = guard.scan_production_sources(root, use_psi=False)
        for i, name in enumerate(NEGATIVE):
            if not any(f"negative_{i:02d}.kt" in v for v in violations):
                failures.append(f"real-source negative fixture missed: {name}")
        for i, name in enumerate(POSITIVE):
            if any(f"positive_{i:02d}.kt" in v for v in violations):
                failures.append(f"real-source positive fixture flagged: {name}")
        tokenizer_negative_passed = sum(
            bool(guard.forbidden_dao_access(code.replace("\\n", "\n")))
            for code in NEGATIVE.values()
        )
        tokenizer_positive_passed = sum(
            not bool(guard.forbidden_dao_access(code.replace("\\n", "\n")))
            for code in POSITIVE.values()
        )
        print(f"TOKENIZER_NEGATIVE={tokenizer_negative_passed}/{len(NEGATIVE)}")
        print(f"TOKENIZER_POSITIVE={tokenizer_positive_passed}/{len(POSITIVE)}")
        print(f"REAL_SOURCE_SCAN=EXECUTED ({len(NEGATIVE)} negative, {len(POSITIVE)} positive .kt fixtures)")
        print("TOKENIZER_FIXTURES=EXECUTED")
        compiler = shutil.which("kotlinc")
        compiler_version = "UNAVAILABLE"
        if compiler:
            version_result = subprocess.run([compiler, "-version"], text=True, capture_output=True, timeout=30)
            version_text = version_result.stdout + version_result.stderr
            match = re.search(r"kotlinc-jvm\s+([^\s]+)", version_text)
            if version_result.returncode == 0 and match:
                compiler_version = match.group(1)
        psi = guard._prepare_psi_guard()
        if psi is None:
            print(f"PSI_COMPILER={compiler_version}")
            print("PSI_RUNTIME=UNAVAILABLE")
            print("PSI_COMPILATION=NOT EXECUTED")
            print("PSI_FIXTURES=NOT EXECUTED")
            failures.append("PSI runtime/compiler unavailable; PSI-required suite cannot pass")
        else:
            print(f"PSI_COMPILER={compiler_version}")
            print("PSI_RUNTIME=AVAILABLE")
            print("PSI_COMPILATION=SUCCESS")
            # The same real fixture files are analyzed by the PSI source scanner.
            psi_violations = guard.scan_production_sources(root, use_psi=True)
            psi_negative_passed = sum(
                any(f"negative_{i:02d}.kt" in v for v in psi_violations)
                for i in range(len(NEGATIVE))
            )
            psi_positive_passed = sum(
                not any(f"positive_{i:02d}.kt" in v for v in psi_violations)
                for i in range(len(POSITIVE))
            )
            for i, name in enumerate(NEGATIVE):
                if not any(f"negative_{i:02d}.kt" in v for v in psi_violations):
                    failures.append(f"PSI negative fixture missed: {name}")
            for i, name in enumerate(POSITIVE):
                if any(f"positive_{i:02d}.kt" in v for v in psi_violations):
                    failures.append(f"PSI positive fixture flagged: {name}")
            print(f"PSI_NEGATIVE={psi_negative_passed}/{len(NEGATIVE)}")
            print(f"PSI_POSITIVE={psi_positive_passed}/{len(POSITIVE)}")
            print("PSI_FIXTURES=EXECUTED")
    if failures:
        print("FAILURES:")
        for f in failures: print("FAIL —", f)
        return 1
    print("RESULT=TOKENIZER_AND_PSI_FIXTURES_PASS")
    return 0

if __name__ == "__main__":
    sys.exit(main())
