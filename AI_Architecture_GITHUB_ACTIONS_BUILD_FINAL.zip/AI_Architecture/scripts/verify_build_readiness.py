#!/usr/bin/env python3
"""Static Android build-readiness checks; does not claim to compile or execute tests."""
from pathlib import Path
import re
import sys
import tempfile
import subprocess

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
ROOT_BUILD = (ROOT / "build.gradle.kts").read_text(encoding="utf-8")
APP_BUILD = (APP / "build.gradle.kts").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-ci.yml").read_text(encoding="utf-8")
BOOTSTRAP = (ROOT / "MOBILE_GITHUB_BOOTSTRAP_WORKFLOW.yml").read_text(encoding="utf-8")
MANIFEST = (APP / "src/main/AndroidManifest.xml").read_text(encoding="utf-8")

checks = []
def check(label, condition):
    checks.append((label, bool(condition)))

agp = re.search(r'com\.android\.application"\) version "([^"]+)', ROOT_BUILD)
kotlin = re.search(r'org\.jetbrains\.kotlin\.android"\) version "([^"]+)', ROOT_BUILD)
compose = re.search(r'org\.jetbrains\.kotlin\.plugin\.compose"\) version "([^"]+)', ROOT_BUILD)
kapt = re.search(r'org\.jetbrains\.kotlin\.kapt"\) version "([^"]+)', ROOT_BUILD)
check("AGP 8.10.0 / API 36 compatible target", bool(agp and agp.group(1) == "8.10.0" and "compileSdk = 36" in APP_BUILD))
check("Kotlin Android, KAPT and Compose compiler plugin versions aligned", bool(kotlin and kapt and compose and kotlin.group(1) == kapt.group(1) == compose.group(1) == "2.0.21"))
check("Java/Kotlin bytecode target is 17", "sourceCompatibility = JavaVersion.VERSION_17" in APP_BUILD and "targetCompatibility = JavaVersion.VERSION_17" in APP_BUILD and 'jvmTarget = "17"' in APP_BUILD)
check("Room runtime, KTX and KAPT compiler versions aligned at 2.7.2", all(x in APP_BUILD for x in ["room-runtime:2.7.2", "room-ktx:2.7.2", "room-compiler:2.7.2"]) and "room-runtime:2.6.1" not in APP_BUILD)
check("Compose compiler Gradle plugin is applied to app module", 'id("org.jetbrains.kotlin.plugin.compose")' in APP_BUILD)
check("Room KAPT configured with correctErrorTypes and schema output", "correctErrorTypes = true" in APP_BUILD and "room.schemaLocation" in APP_BUILD)
check("AndroidX Test runner/rules dependencies use published stable versions", 'androidTestImplementation("androidx.test:runner:1.6.2")' in APP_BUILD and 'androidTestImplementation("androidx.test:rules:1.6.1")' in APP_BUILD)
check("No INTERNET permission in manifest", "android.permission.INTERNET" not in MANIFEST)
unit_files = list((APP / "src/test/java").rglob("*Test.kt"))
instrumentation_files = list((APP / "src/androidTest/java").rglob("*Test.kt"))
check("Phase 1+2 JVM test source inventory is present", len(unit_files) >= 19)
check("Phase 1+2 instrumentation test source inventory is present", len(instrumentation_files) >= 11)
# Kotlin PSI DAO boundary guard when kotlinc is available; the bundled lexer is
# the portable fallback on CI agents without a Kotlin compiler installation.
import dao_access_guard

NON_REPOSITORY_ACCESS = dao_access_guard.scan_production_sources(ROOT)
check(f"{dao_access_guard.GUARD_ENGINE} rejects forbidden production DAO access", not NON_REPOSITORY_ACCESS)
reflection_suite = subprocess.run(
    [sys.executable, str(ROOT / "scripts/test_dao_reflection_guard.py")],
    cwd=ROOT, text=True, capture_output=True
)
import re as _reflection_re
_reflection_output = reflection_suite.stdout
_reflection_counts = {
    key: _reflection_re.search(rf"^{key}=(\d+)/(\d+)$", _reflection_output, _reflection_re.MULTILINE)
    for key in ("PSI_NEGATIVE", "PSI_POSITIVE", "TOKENIZER_NEGATIVE", "TOKENIZER_POSITIVE")
}
_reflection_exact_counts = all(
    match is not None and match.group(1) == match.group(2) == expected
    for (key, match), expected in zip(_reflection_counts.items(), ("17", "9", "17", "9"))
)
check("V7 reflection guard real PSI and Tokenizer fixtures execute with exact passing counts",
      reflection_suite.returncode == 0
      and "PSI_COMPILER=1.9.0" in _reflection_output
      and "PSI_RUNTIME=AVAILABLE" in _reflection_output
      and "PSI_COMPILATION=SUCCESS" in _reflection_output
      and "PSI_FIXTURES=EXECUTED" in _reflection_output
      and "TOKENIZER_FIXTURES=EXECUTED" in _reflection_output
      and "RESULT=TOKENIZER_AND_PSI_FIXTURES_PASS" in _reflection_output
      and _reflection_exact_counts)
check("V7 reflection guard reports PSI runtime and Tokenizer availability explicitly",
      all(marker in _reflection_output for marker in
          ("PSI_COMPILER=", "PSI_RUNTIME=", "PSI_COMPILATION=", "PSI_FIXTURES=", "TOKENIZER_FIXTURES="))
      and "PSI_RUNTIME=AVAILABLE" in _reflection_output)

# All negative/positive fixtures are real Kotlin files in a temporary
# src/main/java tree and are scanned together by the same guard entry point.
negative_dao_fixtures = {
    "direct member call": "fun bad(db: AppDatabase) { db.componentDefinitions() }",
    "with receiver lambda implicit call": "fun bad(db: AppDatabase) { with(db) { componentDefinitions() } }",
    "run receiver lambda implicit call": "fun bad(db: AppDatabase) { db.run { componentDefinitions() } }",
    "apply receiver lambda implicit call": "fun bad(db: AppDatabase) { db.apply { componentProfiles() } }",
    "let lambda explicit it receiver": "fun bad(db: AppDatabase) { db.let { it.componentMaterials() } }",
    "also lambda explicit it receiver": "fun bad(db: AppDatabase) { db.also { it.componentInstances() } }",
    "nested receiver lambda": "fun bad(db: AppDatabase) { db.run { with(this) { componentDefinitions() } } }",
    "callable reference": "val getter = db::componentDefinitions",
    "unqualified callable reference": "val getter = ::componentInstances",
    "import alias and alias invocation": "import example.AppDatabase.componentDefinitions as componentDao\nfun bad(db: AppDatabase) { db.componentDao() }",
    "import alias callable reference": "import example.AppDatabase.componentMaterials as materialDao\nval getter = db::materialDao",
    "star-import bare invocation": "import example.AppDatabase.*\nfun bad(db: AppDatabase) { componentProfiles() }",
    "backtick identifier": "fun bad(db: AppDatabase) { db.`componentDefinitions`() }",
    "whitespace comments and newlines": "fun bad(db: AppDatabase) { db /*a*/ . /*b*/ componentDefinitions /*c*/ (\n) }",
    "backtick callable reference": "val getter = db::`componentMaterials`",
    "raw string template executable code": 'val text = """${db.componentDefinitions()}"""',
    "reflection lookup literal bypass": 'fun bad(db: AppDatabase) { db.javaClass.getDeclaredMethod("componentDefinitions") }',
    "reflection lookup computed-name bypass": 'fun bad(db: AppDatabase, accessor: String) { db.javaClass.getMethod(accessor) }',
}
positive_dao_fixtures = {
    "escaped regular string": 'val text = "db.componentDefinitions()"',
    "escaped quote string contents": r'val text = "escaped \" db.componentDefinitions() \" text"',
    "raw triple-quoted string": 'val text = """db.componentInstances() componentProfiles()"""',
    "line and nested block comments": "// db.componentDefinitions()\n/* outer /* db.componentMaterials() */ end */ val ok = 1",
    "character literal": "val c = 'x'",
}
with tempfile.TemporaryDirectory(prefix="dao-guard-fixtures-") as td:
    fixture_root = Path(td)
    feature_root = fixture_root / "app/src/main/java/com/aiarchitecture/app/feature/fixtures"
    feature_root.mkdir(parents=True, exist_ok=True)
    negative_paths = {}
    for index, (fixture_name, fixture_source) in enumerate(negative_dao_fixtures.items()):
        filename = f"negative_{index:02d}.kt"
        (feature_root / filename).write_text(fixture_source, encoding="utf-8")
        negative_paths[fixture_name] = filename
    positive_root = feature_root / "positive"
    positive_root.mkdir(parents=True, exist_ok=True)
    positive_paths = {}
    for index, (fixture_name, fixture_source) in enumerate(positive_dao_fixtures.items()):
        filename = f"positive_{index:02d}.kt"
        (positive_root / filename).write_text(fixture_source, encoding="utf-8")
        positive_paths[fixture_name] = filename
    permitted_db = fixture_root / "app/src/main/java/com/aiarchitecture/app/data/local/AppDatabase.kt"
    permitted_db.parent.mkdir(parents=True, exist_ok=True)
    permitted_db.write_text("abstract class AppDatabase { internal abstract fun componentDefinitions(): ComponentDefinitionDao }", encoding="utf-8")
    permitted_repo = fixture_root / "app/src/main/java/com/aiarchitecture/app/data/repository/Store.kt"
    permitted_repo.parent.mkdir(parents=True, exist_ok=True)
    permitted_repo.write_text("class Store(val db: AppDatabase) { fun x() = db.componentDefinitions() }", encoding="utf-8")
    misplaced = fixture_root / "app/src/main/java/com/aiarchitecture/app/feature/AppDatabase.kt"
    misplaced.write_text("class Feature { fun x(db: AppDatabase) = db.componentDefinitions() }", encoding="utf-8")
    fixture_violations = dao_access_guard.scan_production_sources(fixture_root)
    for fixture_name, filename in negative_paths.items():
        check(f"DAO guard negative fixture: {fixture_name}", any(filename in finding for finding in fixture_violations))
    alias_file = negative_paths["import alias and alias invocation"]
    check("DAO guard resolves imported alias invocation itself", any(alias_file in finding and "componentDao" in finding for finding in fixture_violations))
    for fixture_name, filename in positive_paths.items():
        check(f"DAO guard positive fixture: {fixture_name}", not any(filename in finding for finding in fixture_violations))
    check("DAO guard positive fixture: exact Database and Repository paths allowed", not any("data/local/AppDatabase.kt" in finding or "data/repository/Store.kt" in finding for finding in fixture_violations))
    check("DAO guard negative fixture: differently located AppDatabase.kt is not exempt", any("feature/AppDatabase.kt" in finding for finding in fixture_violations))
    fallback_violations = dao_access_guard.scan_production_sources(fixture_root, use_psi=False)
    check("Tokenizer fallback rejects all Kotlin bypass fixtures", all(any(filename in finding for finding in fallback_violations) for filename in negative_paths.values()))
    check("Tokenizer fallback ignores string, raw-string and comment literals", all(not any(filename in finding for finding in fallback_violations) for filename in positive_paths.values()))
    psi_negative_passed = sum(any(filename in finding for finding in fixture_violations) for filename in negative_paths.values())
    psi_positive_passed = sum(not any(filename in finding for finding in fixture_violations) for filename in positive_paths.values())
    tokenizer_negative_passed = sum(any(filename in finding for finding in fallback_violations) for filename in negative_paths.values())
    tokenizer_positive_passed = sum(not any(filename in finding for finding in fallback_violations) for filename in positive_paths.values())
    print(f"V6_PSI_NEGATIVE={psi_negative_passed}/{len(negative_paths)}")
    print(f"V6_PSI_POSITIVE={psi_positive_passed}/{len(positive_paths)}")
    print(f"V6_TOKENIZER_NEGATIVE={tokenizer_negative_passed}/{len(negative_paths)}")
    print(f"V6_TOKENIZER_POSITIVE={tokenizer_positive_passed}/{len(positive_paths)}")

DB_SOURCE = (APP / "src/main/java/com/aiarchitecture/app/data/local/AppDatabase.kt").read_text(encoding="utf-8")
check("Component DAO accessors are Kotlin module-internal", all(f"internal abstract fun {name}" in DB_SOURCE for name in ("componentDefinitions()", "componentInstances()", "componentProfiles()", "componentMaterials()")))
check("Main CI pins Gradle 8.11.1 and JDK 17", "gradle-version: '8.11.1'" in WORKFLOW and "java-version: '17'" in WORKFLOW)
check("Main CI installs API 36 and Build Tools 36.0.0", "platforms;android-36" in WORKFLOW and "build-tools;36.0.0" in WORKFLOW)
steps = [":app:kaptDebugKotlin", ":app:compileDebugKotlin", ":app:testDebugUnitTest", ":app:lintDebug", ":app:connectedDebugAndroidTest", ":app:assembleDebug"]
positions = [WORKFLOW.find(s) for s in steps]
check("Main CI orders Room KAPT -> Kotlin compile -> JVM tests -> lint -> emulator instrumentation -> debug APK", all(p >= 0 for p in positions) and positions == sorted(positions))
check("Main CI runs all Phase 2 static verifiers", all(f"scripts/{n}" in WORKFLOW for n in ["verify_project.py", "verify_phase2.py", "verify_phase2_closeout.py", "verify_build_readiness.py"]))
EXPECTED_BOOTSTRAP_ZIP = "AI_Architecture_Phase2_INSTRUMENTATION_FIX_V2_NOT_FINAL.zip"
LEGACY_BOOTSTRAP_ZIPS = [
    "AI_Architecture_Phase2_KOTLIN_COMPILE_FIX_V1_NOT_FINAL.zip",
    "AI_Architecture_Phase2_ANDROID_BUILD_READY_NOT_FINAL.zip",
    "AI_Architecture_Phase2_CLOSED_NOT_FINAL.zip",
]
check("Bootstrap workflow requires the exact current Phase 2 ZIP filename", f"test -f {EXPECTED_BOOTSTRAP_ZIP}" in BOOTSTRAP and f"unzip -q {EXPECTED_BOOTSTRAP_ZIP}" in BOOTSTRAP)
check("Bootstrap workflow rejects prior Phase 2 ZIP filenames", all(name not in BOOTSTRAP for name in LEGACY_BOOTSTRAP_ZIPS))
check("Bootstrap extraction and project root paths are consistent", all(x in BOOTSTRAP for x in ["$RUNNER_TEMP/ai-architecture-source", "PROJECT_ROOT=$RUNNER_TEMP/ai-architecture-source/AI_Architecture", "unzip -q "+EXPECTED_BOOTSTRAP_ZIP+" -d \"$RUNNER_TEMP/ai-architecture-source\""]))
check("Bootstrap artifact paths point to extracted project build outputs", all(x in BOOTSTRAP for x in ["ai-architecture-source/AI_Architecture/app/build/outputs/apk/debug/*.apk", "ai-architecture-source/AI_Architecture/app/build/reports/**", "ai-architecture-source/AI_Architecture/app/build/test-results/**"]))
GUIDE = (ROOT / "docs/MOBILE_GITHUB_UPLOAD_HI.md").read_text(encoding="utf-8")
SECURITY = (ROOT / "docs/SECURITY_AUDIT.md").read_text(encoding="utf-8")
check("Mobile upload guide names the Unit Test fix ZIP and exact bootstrap upload filename", "AI_Architecture_Phase2_INSTRUMENTATION_FIX_V2_NOT_FINAL.zip" in GUIDE and GUIDE.count(EXPECTED_BOOTSTRAP_ZIP) >= 3 and "repository-root" in GUIDE)
check("Security audit matches manifest: no INTERNET; online AI/model downloads unavailable", "android.permission.INTERNET" not in MANIFEST and "disabled/unavailable" in SECURITY and "disabled/unavailable" in SECURITY)
positions2 = [BOOTSTRAP.find(s) for s in steps]
check("Bootstrap workflow follows same build/test/lint/emulator order", all(p >= 0 for p in positions2) and positions2 == sorted(positions2))
check("No release/signing task is part of CI workflow", all(x not in WORKFLOW for x in [":app:assembleRelease", "signingConfig", "upload-keystore"]))
EDITOR = (APP / "src/main/java/com/aiarchitecture/app/feature/editor/BlueprintEditorScreen.kt").read_text(encoding="utf-8")
PLAN_TRANSFORM = (ROOT / "app/src/main/java/com/aiarchitecture/app/core/geometry/PlanCanvasCoordinates.kt").read_text(encoding="utf-8")
GEOMETRY_TEST = (ROOT / "app/src/test/java/com/aiarchitecture/app/core/GeometryTest.kt").read_text(encoding="utf-8")
check("Canvas pointer conversion uses explicit Float-to-Double geometry boundary", "PlanCanvasTransform(scale).toModelPoint(point.x,point.y)" in EDITOR and "Vec2(x,z)" not in EDITOR)
check("Compose drawing element color does not shadow Android Paint color", "val elementColor=when(e.type)" in EDITOR and "drawRect(elementColor" in EDITOR and "val color=when(e.type)" not in EDITOR)
check("Android Paint color assignments explicitly target Paint receiver", EDITOR.count("this.color=android.graphics.Color.DKGRAY") == 2)
check("Plan canvas transform validates scale and converts to Double geometry", "scale.isFinite() && scale > 0f" in PLAN_TRANSFORM and "scale.toDouble()" in PLAN_TRANSFORM)
check("Plan canvas coordinate and selection regression tests are present", all(x in GEOMETRY_TEST for x in ["planCanvasFloatCoordinatesConvertToCanonicalDoubleMillimetres", "planCanvasTransformPreservesElementSelectionHitTesting"]))
APP_BUILD_FOR_BACKUP = (APP / "build.gradle.kts").read_text(encoding="utf-8")
BACKUP_TEST = (APP / "src/test/java/com/aiarchitecture/app/core/BackupTest.kt").read_text(encoding="utf-8")
DIMENSION_TEST = (APP / "src/test/java/com/aiarchitecture/app/core/DimensionEngineTest.kt").read_text(encoding="utf-8")
GEOMETRY_TEST_SOURCE = (APP / "src/test/java/com/aiarchitecture/app/core/GeometryTest.kt").read_text(encoding="utf-8")
MODEL_SOURCE = (APP / "src/main/java/com/aiarchitecture/app/core/geometry/BuildingModel.kt").read_text(encoding="utf-8")
check("JVM unit tests include a real org.json implementation", 'testImplementation("org.json:json:20240303")' in APP_BUILD_FOR_BACKUP)
check("Backup tests cover model geometry/opening round-trip and checksum tampering", all(x in BACKUP_TEST for x in ["backupRoundTripPreservesProjectFloorsGeometryAndOpenings", "rejectsTamperedBackup", "Backup payload marker must exist"]))
check("DimensionEngine fixture adds element to the same model that owns its floor", "val base=BuildingModel.starter()" in DIMENSION_TEST and "val floor=base.floors.first()" in DIMENSION_TEST and "val model=base.addElement(wall)" in DIMENSION_TEST)
check("Geometry opening fixture reuses its floor-owning model", "val base=BuildingModel.starter()" in GEOMETRY_TEST_SOURCE and "val mesh=MeshBuilder.build(base.addElement(w))" in GEOMETRY_TEST_SOURCE)
check("BuildingModel.addElement keeps unknown-floor validation", "require(floors.any { it.id == element.floorId })" in MODEL_SOURCE)
check("Geometry regression test preserves unknown-floor rejection", "addElementRejectsUnknownFloorId" in GEOMETRY_TEST_SOURCE)
UNIT_TEST_METHODS = sum(len(re.findall(r"@Test\b", p.read_text(encoding="utf-8"))) for p in unit_files)
check("JVM unit-test source inventory has at least 62 test methods", UNIT_TEST_METHODS >= 62)
INSTRUMENTATION_TEST_METHODS = sum(len(re.findall(r"@Test\b", p.read_text(encoding="utf-8"))) for p in instrumentation_files)
check("Instrumentation source inventory has at least 36 test methods", INSTRUMENTATION_TEST_METHODS >= 36)
trace = (ROOT / "docs/TRACEABILITY_MATRIX.md").read_text(encoding="utf-8")
first_table, second_table = trace.split("| # | Original section |", 1)
screen_rows = len(re.findall(r"^\|\s*\d+\s*\|", first_table, re.M)) 
section_rows = len(re.findall(r"^\|\s*\d+\s*\|", "| # | Original section |" + second_table, re.M)) 
check("21-screen and 22-section traceability rows preserved", screen_rows == 21 and section_rows == 22)

for label, passed in checks:
    print(f"{'PASS' if passed else 'FAIL'} — {label}")
failed = [label for label, passed in checks if not passed]
print(f"Static build-readiness checks: {len(checks)-len(failed)}/{len(checks)} passed")
if failed:
    print("Failed checks:", "; ".join(failed))
    sys.exit(1)
