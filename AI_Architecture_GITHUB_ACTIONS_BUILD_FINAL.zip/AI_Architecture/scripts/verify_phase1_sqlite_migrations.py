#!/usr/bin/env python3
"""SQLite-only simulation of AppDatabase v1->v2->v3 migration SQL.
Not a substitute for Room/KAPT or Android instrumentation execution.
"""
from pathlib import Path
import re
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "app/src/main/java/com/aiarchitecture/app/data/local/AppDatabase.kt"
source = SOURCE.read_text(encoding="utf-8")


def statements(block: str) -> list[str]:
    literals = re.findall(r'db\.execSQL\("((?:\\.|[^"\\])*)"\)', block)
    return [bytes(value, "utf-8").decode("unicode_escape") for value in literals]

block12 = source.split("val MIGRATION_1_2", 1)[1].split("val MIGRATION_2_3", 1)[0]
block23 = source.split("val MIGRATION_2_3", 1)[1].split("fun open(context", 1)[0]
sql12, sql23 = statements(block12), statements(block23)

connection = sqlite3.connect(":memory:")
connection.execute("PRAGMA foreign_keys=ON")
connection.executescript("""
CREATE TABLE projects(id TEXT NOT NULL PRIMARY KEY,name TEXT NOT NULL,createdAt INTEGER NOT NULL,updatedAt INTEGER NOT NULL);
CREATE TABLE floors(id TEXT NOT NULL PRIMARY KEY,projectId TEXT NOT NULL,name TEXT NOT NULL,elevationMm REAL NOT NULL);
CREATE INDEX index_floors_projectId ON floors(projectId);
CREATE TABLE building_elements(id TEXT NOT NULL PRIMARY KEY,projectId TEXT NOT NULL,floorId TEXT NOT NULL,type TEXT NOT NULL,xMm REAL NOT NULL,yMm REAL NOT NULL,zMm REAL NOT NULL,lengthMm REAL NOT NULL,widthMm REAL NOT NULL,heightMm REAL NOT NULL,material TEXT NOT NULL,openingsJson TEXT NOT NULL,revision INTEGER NOT NULL,lengthProvenance TEXT NOT NULL,widthProvenance TEXT NOT NULL,heightProvenance TEXT NOT NULL,yawDegrees REAL NOT NULL);
CREATE INDEX index_building_elements_floorId ON building_elements(floorId);
CREATE INDEX index_building_elements_projectId ON building_elements(projectId);
CREATE TABLE edit_history(sequence INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,projectId TEXT NOT NULL,snapshotJson TEXT NOT NULL,createdAt INTEGER NOT NULL);
CREATE INDEX index_edit_history_projectId ON edit_history(projectId);
""")
connection.execute("INSERT INTO projects VALUES('p','Legacy',1,2)")
connection.execute("INSERT INTO floors VALUES('f','p','Ground',0)")
connection.execute("INSERT INTO building_elements VALUES('e','p','f','WALL',0,0,0,4000,200,2800,'brick','[]',3,'USER_ENTERED','USER_ENTERED','USER_ENTERED',0)")
connection.execute("INSERT INTO edit_history(projectId,snapshotJson,createdAt) VALUES('p','{}',3)")
for statement in sql12 + sql23:
    connection.execute(statement)

legacy_counts = {table: connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                 for table in ("projects", "floors", "building_elements", "edit_history")}
assert all(count == 1 for count in legacy_counts.values()), legacy_counts
component_tables = {row[0] for row in connection.execute(
    "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'component_%'")}
assert component_tables == {"component_definitions", "component_instances", "component_profiles", "component_materials"}
indexes = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='index'")}
component_indexes = {name for name in indexes if name.startswith("index_component_")}
original_indexes = {
    "index_component_definitions_key",
    "index_component_instances_projectId", "index_component_instances_floorId",
    "index_component_instances_definitionId", "index_component_instances_materialId", "index_component_instances_profileId",
    "index_component_profiles_name", "index_component_materials_name", "index_component_materials_category",
}
assert original_indexes <= component_indexes, component_indexes
assert len(component_indexes) == 11, component_indexes  # original nine + two FK-support indexes
assert "index_floors_projectId_id" in indexes
foreign_key_rows = list(connection.execute("PRAGMA foreign_key_list(component_instances)"))
assert len(foreign_key_rows) == 6, foreign_key_rows  # 5 logical constraints; composite floor FK has two rows.
definition_foreign_key_rows = list(connection.execute("PRAGMA foreign_key_list(component_definitions)"))
assert len(definition_foreign_key_rows) == 2, definition_foreign_key_rows

connection.execute("INSERT INTO component_definitions VALUES('d','dk','D','CUSTOM',1,'{}','[]','[]',NULL,NULL,0,1)")
connection.execute("INSERT INTO component_profiles VALUES('pr','Profile','POLYLINE','[]',0,0,0,1)")
connection.execute("INSERT INTO component_materials VALUES('m','Metal','STEEL',0,0,0,1,.5,0,NULL,1)")
connection.execute("UPDATE component_definitions SET defaultProfileId='pr', defaultMaterialId='m' WHERE id='d'")
connection.execute("INSERT INTO component_instances VALUES('i','p','f','d','I','{}','{}','{}','{}','pr','m',0,1,0,1)")
connection.execute("INSERT INTO projects VALUES('other','Other',1,1)")
connection.execute("INSERT INTO floors VALUES('other-floor','other','Other floor',0)")
negative_cases = [
    "DELETE FROM component_profiles WHERE id='pr'",
    "DELETE FROM component_materials WHERE id='m'",
    "INSERT INTO component_instances VALUES('bad-floor','p','missing','d','I','{}','{}','{}','{}',NULL,NULL,0,1,0,1)",
    "INSERT INTO component_instances VALUES('bad-cross-project-floor','p','other-floor','d','I','{}','{}','{}','{}',NULL,NULL,0,1,0,1)",
    "INSERT INTO component_instances VALUES('bad-definition','p','f','missing-def','I','{}','{}','{}','{}',NULL,NULL,0,1,0,1)",
]
for statement in negative_cases:
    try:
        connection.execute(statement)
    except sqlite3.IntegrityError:
        continue
    raise AssertionError(f"Expected foreign-key enforcement: {statement}")

print(f"MIGRATION_SQL_V1_V2={len(sql12)}")
print(f"MIGRATION_SQL_V2_V3={len(sql23)}")
print(f"LEGACY_ROWS_PRESERVED={legacy_counts}")
print(f"COMPONENT_TABLES={len(component_tables)}")
print("ORIGINAL_COMPONENT_INDEXES=9 preserved")
print("ADDITIONAL_COMPONENT_FK_INDEXES=2")
print("SUPPORTING_FLOOR_PROJECT_INDEX=present")
print("LOGICAL_FOREIGN_KEYS=7 (2 definition defaults + 5 instance refs)")
print(f"FK_NEGATIVE_CASES_REJECTED={len(negative_cases)}")
print("RESULT=SQLITE_SIMULATION_OK (NOT ROOM OR ANDROID TEST EXECUTION)")
