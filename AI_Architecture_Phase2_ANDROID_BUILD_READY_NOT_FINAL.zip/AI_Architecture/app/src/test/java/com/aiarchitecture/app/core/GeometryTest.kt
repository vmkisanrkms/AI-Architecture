package com.aiarchitecture.app.core

import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.DimensionMm
import org.junit.Assert.*
import org.junit.Test

class GeometryTest {
    private fun wall(floor:String)=BuildingElement(floorId=floor,type=ElementType.WALL,origin=Vec3(0.0,0.0,0.0),size=Size3(DimensionMm(4000.0),DimensionMm(150.0),DimensionMm(2800.0)))
    @Test fun addResizeAndDeleteElements(){val m=BuildingModel.starter();val f=m.floors.first();val w=wall(f.id);val added=m.addElement(w);assertEquals(1,added.floors.first().elements.size);val resized=w.resized(Size3(DimensionMm(5000.0),DimensionMm(150.0),DimensionMm(2800.0)));assertEquals(5000.0,resized.size.length.value,0.0);assertEquals(0,added.removeElement(w.id).floors.first().elements.size)}
    @Test fun meshContainsTrianglesForEditableWall(){val m=BuildingModel.starter().let{it.addElement(wall(it.floors.first().id))};val mesh=MeshBuilder.build(m);assertTrue(mesh.vertexCount>0);assertEquals(mesh.vertices.size/3,mesh.vertexCount);assertEquals(mesh.vertexCount*4,mesh.colors.size)}
    @Test fun rotatedElementKeepsPlanHitTestingAndMesh(){val f=BuildingModel.starter().floors.first();val w=wall(f.id).copy(yawDegrees=90.0);assertTrue(w.containsPlanPoint(Vec2(2000.0,2000.0)));assertTrue(MeshBuilder.build(BuildingModel.starter().addElement(w)).vertexCount>0)}
    @Test fun doorOpeningSegmentsWall(){val f=BuildingModel.starter().floors.first();val w=wall(f.id).copy(openings=listOf(Opening(type=ElementType.DOOR,offsetMm=900.0,widthMm=900.0,heightMm=2100.0)));val mesh=MeshBuilder.build(BuildingModel.starter().addElement(w));assertTrue(mesh.vertexCount>36)}
}
