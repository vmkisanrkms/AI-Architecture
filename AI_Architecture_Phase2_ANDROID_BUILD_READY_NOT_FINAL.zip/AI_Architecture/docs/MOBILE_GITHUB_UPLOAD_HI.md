# Android Mobile से GitHub पर Phase 2 Source ZIP Upload और CI चलाना

यह guide वर्तमान V2 Phase 2 Android Build Readiness ZIP के लिए है। डाउनलोड की जाने वाली deliverable file का नाम `AI_Architecture_Phase2_ANDROID_BUILD_READY_V2_NOT_FINAL.zip` है। GitHub repository में upload करते समय उसकी repository-root filename `AI_Architecture_Phase2_ANDROID_BUILD_READY_NOT_FINAL.zip` रखें, क्योंकि bootstrap workflow इसी exact input filename को पढ़ता है। यह केवल Debug build और automated checks चलाने हेतु है; Final Release/APK signing नहीं।

## सही ZIP

`AI_Architecture_Phase2_ANDROID_BUILD_READY_NOT_FINAL.zip`

## मोबाइल से upload steps

1. `AI_Architecture_Phase2_ANDROID_BUILD_READY_V2_NOT_FINAL.zip` डाउनलोड करें।
2. GitHub app या browser में अपना repository खोलें। यदि repository अभी नहीं है, तो नया खाली repository बनाएं।
3. Repository के root में **Add file → Upload files** चुनें।
4. डाउनलोड की गई V2 ZIP को फोन के File Manager में rename करके `AI_Architecture_Phase2_ANDROID_BUILD_READY_NOT_FINAL.zip` करें। फिर यही renamed ZIP upload करें। GitHub में repository-root पर filename बिल्कुल यही होना चाहिए; पुराना `AI_Architecture_Phase2_CLOSED_NOT_FINAL.zip` नाम इस्तेमाल न करें।
5. Commit changes करें। ZIP repository के root में होना चाहिए, किसी subfolder में नहीं।
6. Repository में **Add file → Create new file** खोलें। Filename/path में `.github/workflows/android-ci.yml` लिखें।
7. ZIP में मौजूद `MOBILE_GITHUB_BOOTSTRAP_WORKFLOW.yml` खोलें और उसका पूरा content copy करके नई GitHub workflow file में paste करें। Commit करें।
8. **Actions** tab खोलें। `AI Architecture Phase 2 Android CI (ZIP upload)` workflow चुनें और **Run workflow** दबाएं (या main/master पर push से trigger होने दें)।
9. Workflow पहले ZIP filename check करके `$RUNNER_TEMP/ai-architecture-source/` में extract करेगा। Project root `.../ai-architecture-source/AI_Architecture` होगा। इसके बाद चार static verifiers, Debug build, Unit Tests, Lint और Emulator Instrumentation Tests क्रम से चलेंगे।
10. Run पूरा होने पर workflow Artifacts से `ai-architecture-phase2-debug-build-and-reports` डाउनलोड करें। Fail होने पर पूरा failing step/log साझा करें।

## महत्वपूर्ण

- ZIP को repository root में upload करना अनिवार्य है; bootstrap workflow उसी exact root filename को पढ़ता है।
- ZIP के अंदर का `.github/workflows/android-ci.yml` ZIP-only upload से GitHub पर सक्रिय नहीं होता; इसलिए bootstrap workflow को अलग से `.github/workflows/android-ci.yml` में बनाना आवश्यक है।
- Workflow में Debug build और tests हैं; Release build, signing या Final Release नहीं है।
- Android SDK/Emulator वाले GitHub Actions run के सफल होने तक वास्तविक Android compilation और tests **Pending** हैं। इस guide या static verifiers को Android build success न समझें।
- Current manifest में INTERNET permission नहीं है; Online AI और remote model downloads अभी disabled/unavailable हैं।
