package com.aiarchitecture.app

import androidx.compose.ui.test.assertExists
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import com.aiarchitecture.app.feature.shell.AppStrings
import com.aiarchitecture.app.navigation.AppNavHost
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.runner.RunWith
import org.junit.Rule
import org.junit.Test

@RunWith(AndroidJUnit4::class)
class ColdStartLanguageNavigationTest {
    @get:Rule val composeRule = createAndroidComposeRule<MainActivity>()

    @Test fun savedLanguageSkipsLanguageSelectionOnColdStart() {
        AppStrings.setLanguage(composeRule.activity, "en")
        composeRule.setContent { AppNavHost() }
        composeRule.onNodeWithTag("destination-home", useUnmergedTree = true).assertExists()
        composeRule.onNodeWithText("Native architectural design workspace").assertExists()
    }

    @Test fun firstLaunchWithoutSavedLanguageShowsSplash() {
        composeRule.activity.getSharedPreferences("ai_architecture_preferences", 0).edit().clear().commit()
        composeRule.setContent { AppNavHost() }
        composeRule.onNodeWithTag("destination-splash", useUnmergedTree = true).assertExists()
    }
}
