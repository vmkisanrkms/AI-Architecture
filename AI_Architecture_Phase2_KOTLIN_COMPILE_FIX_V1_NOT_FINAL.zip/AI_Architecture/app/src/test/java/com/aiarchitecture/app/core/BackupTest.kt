package com.aiarchitecture.app.core

import com.aiarchitecture.app.core.geometry.BuildingModel
import com.aiarchitecture.app.feature.backup.BackupRestoreManager
import com.aiarchitecture.app.feature.backup.readBounded
import java.io.ByteArrayInputStream
import org.junit.Assert.assertEquals
import org.junit.Test

class BackupTest{@Test fun backupRoundTrip(){val m=BuildingModel.starter();assertEquals(m.id,BackupRestoreManager.restore(BackupRestoreManager.createBackup(m)).id)}
@Test fun boundedReadAcceptsWithinLimit(){val data=byteArrayOf(1,2,3);assertEquals(3,ByteArrayInputStream(data).readBounded(3).size)}
@Test(expected=IllegalArgumentException::class) fun rejectsTamperedBackup(){val bytes=BackupRestoreManager.createBackup(BuildingModel.starter());val raw=bytes.toString(Charsets.UTF_8);val marker=raw.indexOf("\"payload\":\"")+11;bytes[marker]=(if(bytes[marker].toInt()==65)66 else 65).toByte();BackupRestoreManager.restore(bytes)}}
