package com.aiarchitecture.app.core

import com.aiarchitecture.app.core.geometry.*
import com.aiarchitecture.app.core.units.*
import org.junit.Assert.*
import org.junit.Test

class DimensionEngineTest {
    @Test fun annotationsCarryDimensionValuesAndEstimatedFlag(){val floor=BuildingModel.starter().floors.first();val wall=BuildingElement(floorId=floor.id,type=ElementType.WALL,origin=Vec3(0.0,0.0,0.0),size=Size3(DimensionMm(4000.0,DimensionProvenance.USER_ENTERED),DimensionMm(150.0),DimensionMm(2800.0,DimensionProvenance.ESTIMATED)));val model=BuildingModel.starter().addElement(wall);val labels=DimensionEngine.annotations(model);assertEquals(3,labels.size);assertTrue(DimensionEngine.visibleLabel(labels.last()).contains("Estimated"))}
    @Test fun gridSnapsToNearestGridOrEndpoint(){val result=GridSnapEngine.snap(Vec2(492.0,501.0),500.0);assertEquals(Vec2(500.0,500.0),result.point);assertEquals("grid",result.snappedTo)}
    @Test fun proportionalResizePreservesOpeningRatio(){val floor=BuildingModel.starter().floors.first();val wall=BuildingElement(floorId=floor.id,type=ElementType.WALL,origin=Vec3(0.0,0.0,0.0),size=Size3(DimensionMm(4000.0),DimensionMm(200.0),DimensionMm(3000.0)),openings=listOf(Opening(type=ElementType.DOOR,offsetMm=1000.0,widthMm=1000.0,heightMm=2100.0)));val resized=GeometryConstraints.resizeProportionally(wall,8000.0);assertEquals(2000.0,resized.openings.first().offsetMm,0.0);assertEquals(2000.0,resized.openings.first().widthMm,0.0)}
}
