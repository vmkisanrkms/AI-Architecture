# Android Mobile से GitHub पर Phase 2 Kotlin Compile-Fix ZIP Upload और CI चलाना

यह guide Phase 2 के Kotlin compile-fix source ZIP के लिए है। डाउनलोड की जाने वाली deliverable और repository-root upload file का exact नाम `AI_Architecture_Phase2_KOTLIN_COMPILE_FIX_V1_NOT_FINAL.zip` है। Bootstrap workflow इसी exact filename को पढ़ता है। यह केवल Debug build और automated checks चलाने हेतु है; APK signing, Final Release या Phase 3 शामिल नहीं हैं।

## सही ZIP

`AI_Architecture_Phase2_KOTLIN_COMPILE_FIX_V1_NOT_FINAL.zip`

## मोबाइल से upload steps

1. ऊपर दिए गए exact नाम वाली ZIP डाउनलोड करें।
2. GitHub app या browser में अपनी Phase 2 repository खोलें।
3. Repository के root में **Add file → Upload files** चुनें।
4. डाउनलोड की गई ZIP को बिना rename किए upload करें। GitHub repository-root पर filename बिल्कुल `AI_Architecture_Phase2_KOTLIN_COMPILE_FIX_V1_NOT_FINAL.zip` होना चाहिए।
5. **Commit changes** करें। ZIP repository के root में होनी चाहिए, किसी subfolder में नहीं।
6. Repository में **Add file → Create new file** खोलें। Filename/path में `.github/workflows/android-ci.yml` लिखें।
7. ZIP में मौजूद `MOBILE_GITHUB_BOOTSTRAP_WORKFLOW.yml` खोलें और उसका पूरा content copy करके नई GitHub workflow file में paste करें। Commit करें।
8. **Actions** tab खोलें। `AI Architecture Phase 2 Android CI (ZIP upload)` workflow चुनें और **Run workflow** दबाएं (या main/master पर push से trigger होने दें)।
9. Workflow पहले exact ZIP filename check करेगा, फिर `$RUNNER_TEMP/ai-architecture-source/` में extract करेगा। Project root `.../ai-architecture-source/AI_Architecture` होगा। इसके बाद चार static verifiers, Debug build, Unit Tests, Lint और Emulator Instrumentation Tests क्रम से चलेंगे।
10. Run पूरा होने पर workflow Artifacts से `ai-architecture-phase2-debug-build-and-reports` डाउनलोड करें। Fail होने पर पूरा failing step/log साझा करें।

## महत्वपूर्ण

- ZIP को repository root में upload करना अनिवार्य है; Bootstrap workflow केवल exact current filename स्वीकार करता है।
- ZIP के अंदर का `.github/workflows/android-ci.yml` ZIP-only upload से GitHub पर सक्रिय नहीं होता; इसलिए Bootstrap workflow को अलग से `.github/workflows/android-ci.yml` में बनाना आवश्यक है।
- Workflow में Debug build और tests हैं; Release build, signing या Final Release नहीं है।
- Android SDK/Emulator वाले GitHub Actions run के सफल होने तक वास्तविक Android compilation और tests **Pending** हैं। Static verifiers को Android build success न समझें।
- Current manifest में INTERNET permission नहीं है; Online AI और remote model downloads अभी disabled/unavailable हैं।
