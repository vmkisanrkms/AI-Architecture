# Android Mobile से GitHub पर Phase 2 Unit Test Fix ZIP Upload और CI चलाना

डाउनलोड की जाने वाली deliverable और repository-root upload file का exact नाम `AI_Architecture_Phase2_UNIT_TEST_FIX_V1_NOT_FINAL.zip` है। Bootstrap workflow इसी exact filename को पढ़ता है। यह केवल Debug build, JVM Unit Tests, Android Lint और Emulator Instrumentation Tests चलाने हेतु है; APK signing, Final Release या Phase 3 शामिल नहीं हैं।

## मोबाइल से upload steps

1. `AI_Architecture_Phase2_UNIT_TEST_FIX_V1_NOT_FINAL.zip` डाउनलोड करें।
2. GitHub app या browser में अपनी `AI-Architecture` repository खोलें।
3. Repository के root में **Add file → Upload files** चुनें।
4. ZIP को बिना rename किए upload करें। Repository-root पर filename बिल्कुल `AI_Architecture_Phase2_UNIT_TEST_FIX_V1_NOT_FINAL.zip` होना चाहिए।
5. **Commit changes** करें। ZIP किसी subfolder में नहीं होनी चाहिए।
6. **Add file → Create new file** चुनें और path `.github/workflows/android-ci.yml` लिखें।
7. ZIP में मौजूद `MOBILE_GITHUB_BOOTSTRAP_WORKFLOW.yml` का पूरा content copy करके नई workflow file में paste करें और commit करें।
8. **Actions** tab में `AI Architecture Phase 2 Android CI (ZIP upload)` चुनकर **Run workflow** दबाएँ।
9. Workflow exact ZIP filename verify करके `$RUNNER_TEMP/ai-architecture-source/` में extract करेगा। इसके बाद चार static verifiers, Debug Build, पूरे JVM Unit Test suite, Android Lint और Emulator Instrumentation Tests क्रम से चलेंगे।
10. Run के बाद `ai-architecture-phase2-debug-build-and-reports` artifact डाउनलोड करें। यदि कोई task fail हो तो पूरा failing log और XML test report साझा करें।

## महत्वपूर्ण

- पुराने ZIP filenames स्वीकार नहीं होंगे; केवल ऊपर दिया गया exact filename उपयोग करें।
- Workflow में Debug build और tests हैं; Release build, signing या Final Release नहीं है।
- Android SDK/Emulator वाले GitHub Actions run सफल होने तक वास्तविक Kotlin compilation, Unit Tests, Lint और Instrumentation Tests **Pending** हैं।
- Current manifest में INTERNET permission नहीं है; Online AI और remote model downloads अभी disabled/unavailable हैं।
