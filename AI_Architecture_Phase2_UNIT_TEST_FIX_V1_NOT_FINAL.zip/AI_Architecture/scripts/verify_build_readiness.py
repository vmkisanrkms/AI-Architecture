#!/usr/bin/env python3
"""Static Android build-readiness checks; does not claim to compile or execute tests."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
ROOT_BUILD = (ROOT / "build.gradle.kts").read_text(encoding="utf-8")
APP_BUILD = (APP / "build.gradle.kts").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-ci.yml").read_text(encoding="utf-8")
BOOTSTRAP = (ROOT / "MOBILE_GITHUB_BOOTSTRAP_WORKFLOW.yml").read_text(encoding="utf-8")
MANIFEST = (APP / "src/main/AndroidManifest.xml").read_text(encoding="utf-8")

checks = []
def check(label, condition):
    checks.append((label, bool(condition)))

agp = re.search(r'com\.android\.application"\) version "([^"]+)', ROOT_BUILD)
kotlin = re.search(r'org\.jetbrains\.kotlin\.android"\) version "([^"]+)', ROOT_BUILD)
compose = re.search(r'org\.jetbrains\.kotlin\.plugin\.compose"\) version "([^"]+)', ROOT_BUILD)
kapt = re.search(r'org\.jetbrains\.kotlin\.kapt"\) version "([^"]+)', ROOT_BUILD)
check("AGP 8.10.0 / API 36 compatible target", bool(agp and agp.group(1) == "8.10.0" and "compileSdk = 36" in APP_BUILD))
check("Kotlin Android, KAPT and Compose compiler plugin versions aligned", bool(kotlin and kapt and compose and kotlin.group(1) == kapt.group(1) == compose.group(1) == "2.0.21"))
check("Java/Kotlin bytecode target is 17", "sourceCompatibility = JavaVersion.VERSION_17" in APP_BUILD and "targetCompatibility = JavaVersion.VERSION_17" in APP_BUILD and 'jvmTarget = "17"' in APP_BUILD)
check("Room runtime, KTX and KAPT compiler versions aligned at 2.7.2", all(x in APP_BUILD for x in ["room-runtime:2.7.2", "room-ktx:2.7.2", "room-compiler:2.7.2"]) and "room-runtime:2.6.1" not in APP_BUILD)
check("Compose compiler Gradle plugin is applied to app module", 'id("org.jetbrains.kotlin.plugin.compose")' in APP_BUILD)
check("Room KAPT configured with correctErrorTypes and schema output", "correctErrorTypes = true" in APP_BUILD and "room.schemaLocation" in APP_BUILD)
check("AndroidX Test runner/rules dependencies use published stable versions", 'androidTestImplementation("androidx.test:runner:1.6.2")' in APP_BUILD and 'androidTestImplementation("androidx.test:rules:1.6.1")' in APP_BUILD)
check("No INTERNET permission in manifest", "android.permission.INTERNET" not in MANIFEST)
unit_files = list((APP / "src/test/java").rglob("*Test.kt"))
instrumentation_files = list((APP / "src/androidTest/java").rglob("*Test.kt"))
check("All 17 unit-test source files present", len(unit_files) == 17)
check("All 9 instrumentation-test source files present", len(instrumentation_files) == 9)
check("Main CI pins Gradle 8.11.1 and JDK 17", "gradle-version: '8.11.1'" in WORKFLOW and "java-version: '17'" in WORKFLOW)
check("Main CI installs API 36 and Build Tools 36.0.0", "platforms;android-36" in WORKFLOW and "build-tools;36.0.0" in WORKFLOW)
steps = [":app:assembleDebug", ":app:testDebugUnitTest", ":app:lintDebug", ":app:connectedDebugAndroidTest"]
positions = [WORKFLOW.find(s) for s in steps]
check("Main CI orders debug build -> unit tests -> lint -> emulator instrumentation", all(p >= 0 for p in positions) and positions == sorted(positions))
check("Main CI runs all Phase 2 static verifiers", all(f"scripts/{n}" in WORKFLOW for n in ["verify_project.py", "verify_phase2.py", "verify_phase2_closeout.py", "verify_build_readiness.py"]))
EXPECTED_BOOTSTRAP_ZIP = "AI_Architecture_Phase2_UNIT_TEST_FIX_V1_NOT_FINAL.zip"
LEGACY_BOOTSTRAP_ZIPS = [
    "AI_Architecture_Phase2_KOTLIN_COMPILE_FIX_V1_NOT_FINAL.zip",
    "AI_Architecture_Phase2_ANDROID_BUILD_READY_NOT_FINAL.zip",
    "AI_Architecture_Phase2_CLOSED_NOT_FINAL.zip",
]
check("Bootstrap workflow requires the exact current Phase 2 ZIP filename", f"test -f {EXPECTED_BOOTSTRAP_ZIP}" in BOOTSTRAP and f"unzip -q {EXPECTED_BOOTSTRAP_ZIP}" in BOOTSTRAP)
check("Bootstrap workflow rejects prior Phase 2 ZIP filenames", all(name not in BOOTSTRAP for name in LEGACY_BOOTSTRAP_ZIPS))
check("Bootstrap extraction and project root paths are consistent", all(x in BOOTSTRAP for x in ["$RUNNER_TEMP/ai-architecture-source", "PROJECT_ROOT=$RUNNER_TEMP/ai-architecture-source/AI_Architecture", "unzip -q "+EXPECTED_BOOTSTRAP_ZIP+" -d \"$RUNNER_TEMP/ai-architecture-source\""]))
check("Bootstrap artifact paths point to extracted project build outputs", all(x in BOOTSTRAP for x in ["ai-architecture-source/AI_Architecture/app/build/outputs/apk/debug/*.apk", "ai-architecture-source/AI_Architecture/app/build/reports/**", "ai-architecture-source/AI_Architecture/app/build/test-results/**"]))
GUIDE = (ROOT / "docs/MOBILE_GITHUB_UPLOAD_HI.md").read_text(encoding="utf-8")
SECURITY = (ROOT / "docs/SECURITY_AUDIT.md").read_text(encoding="utf-8")
check("Mobile upload guide names the Unit Test fix ZIP and exact bootstrap upload filename", "AI_Architecture_Phase2_UNIT_TEST_FIX_V1_NOT_FINAL.zip" in GUIDE and GUIDE.count(EXPECTED_BOOTSTRAP_ZIP) >= 3 and "repository-root" in GUIDE)
check("Security audit matches manifest: no INTERNET; online AI/model downloads unavailable", "android.permission.INTERNET" not in MANIFEST and "disabled/unavailable" in SECURITY and "disabled/unavailable" in SECURITY)
positions2 = [BOOTSTRAP.find(s) for s in steps]
check("Bootstrap workflow follows same build/test/lint/emulator order", all(p >= 0 for p in positions2) and positions2 == sorted(positions2))
check("No release/signing task is part of CI workflow", all(x not in WORKFLOW for x in [":app:assembleRelease", "signingConfig", "upload-keystore"]))
EDITOR = (APP / "src/main/java/com/aiarchitecture/app/feature/editor/BlueprintEditorScreen.kt").read_text(encoding="utf-8")
PLAN_TRANSFORM = (ROOT / "app/src/main/java/com/aiarchitecture/app/core/geometry/PlanCanvasCoordinates.kt").read_text(encoding="utf-8")
GEOMETRY_TEST = (ROOT / "app/src/test/java/com/aiarchitecture/app/core/GeometryTest.kt").read_text(encoding="utf-8")
check("Canvas pointer conversion uses explicit Float-to-Double geometry boundary", "PlanCanvasTransform(scale).toModelPoint(point.x,point.y)" in EDITOR and "Vec2(x,z)" not in EDITOR)
check("Compose drawing element color does not shadow Android Paint color", "val elementColor=when(e.type)" in EDITOR and "drawRect(elementColor" in EDITOR and "val color=when(e.type)" not in EDITOR)
check("Android Paint color assignments explicitly target Paint receiver", EDITOR.count("this.color=android.graphics.Color.DKGRAY") == 2)
check("Plan canvas transform validates scale and converts to Double geometry", "scale.isFinite() && scale > 0f" in PLAN_TRANSFORM and "scale.toDouble()" in PLAN_TRANSFORM)
check("Plan canvas coordinate and selection regression tests are present", all(x in GEOMETRY_TEST for x in ["planCanvasFloatCoordinatesConvertToCanonicalDoubleMillimetres", "planCanvasTransformPreservesElementSelectionHitTesting"]))
APP_BUILD_FOR_BACKUP = (APP / "build.gradle.kts").read_text(encoding="utf-8")
BACKUP_TEST = (APP / "src/test/java/com/aiarchitecture/app/core/BackupTest.kt").read_text(encoding="utf-8")
DIMENSION_TEST = (APP / "src/test/java/com/aiarchitecture/app/core/DimensionEngineTest.kt").read_text(encoding="utf-8")
GEOMETRY_TEST_SOURCE = (APP / "src/test/java/com/aiarchitecture/app/core/GeometryTest.kt").read_text(encoding="utf-8")
MODEL_SOURCE = (APP / "src/main/java/com/aiarchitecture/app/core/geometry/BuildingModel.kt").read_text(encoding="utf-8")
check("JVM unit tests include a real org.json implementation", 'testImplementation("org.json:json:20240303")' in APP_BUILD_FOR_BACKUP)
check("Backup tests cover model geometry/opening round-trip and checksum tampering", all(x in BACKUP_TEST for x in ["backupRoundTripPreservesProjectFloorsGeometryAndOpenings", "rejectsTamperedBackup", "Backup payload marker must exist"]))
check("DimensionEngine fixture adds element to the same model that owns its floor", "val base=BuildingModel.starter()" in DIMENSION_TEST and "val floor=base.floors.first()" in DIMENSION_TEST and "val model=base.addElement(wall)" in DIMENSION_TEST)
check("Geometry opening fixture reuses its floor-owning model", "val base=BuildingModel.starter()" in GEOMETRY_TEST_SOURCE and "val mesh=MeshBuilder.build(base.addElement(w))" in GEOMETRY_TEST_SOURCE)
check("BuildingModel.addElement keeps unknown-floor validation", "require(floors.any { it.id == element.floorId })" in MODEL_SOURCE)
check("Geometry regression test preserves unknown-floor rejection", "addElementRejectsUnknownFloorId" in GEOMETRY_TEST_SOURCE)
UNIT_TEST_METHODS = sum(len(re.findall(r"@Test\b", p.read_text(encoding="utf-8"))) for p in unit_files)
check("37 JVM unit test methods are retained after adding the floor-ID invariant regression", UNIT_TEST_METHODS == 37)
trace = (ROOT / "docs/TRACEABILITY_MATRIX.md").read_text(encoding="utf-8")
first_table, second_table = trace.split("| # | Original section |", 1)
screen_rows = len(re.findall(r"^\|\s*\d+\s*\|", first_table, re.M)) 
section_rows = len(re.findall(r"^\|\s*\d+\s*\|", "| # | Original section |" + second_table, re.M)) 
check("21-screen and 22-section traceability rows preserved", screen_rows == 21 and section_rows == 22)

for label, passed in checks:
    print(f"{'PASS' if passed else 'FAIL'} — {label}")
failed = [label for label, passed in checks if not passed]
print(f"Static build-readiness checks: {len(checks)-len(failed)}/{len(checks)} passed")
if failed:
    print("Failed checks:", "; ".join(failed))
    sys.exit(1)
